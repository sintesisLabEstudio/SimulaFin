package com.simulafin.clases

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BaseDatosHelper(private val context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    /**
     * Verifica e inicializa la base de datos 'simulafin.db' y sus tablas.
     * Vacía explícitamente la tabla Usuarios en el archivo simulafin.db del dispositivo
     * para garantizar que comience con 0 registros (simulando el celular nuevo).
     * @return true si la base fue creada por primera vez, false si ya existía.
     */
    fun generaBaseDatos(): Boolean {
        val dbFile: File = context.getDatabasePath(DATABASE_NAME)
        val esNueva = !dbFile.exists()
        val db = this.writableDatabase
        CreacionBaseDatosSimula(db)
        /*
        // COMENTADO PARA PERMITIR PERSISTENCIA DE USUARIOS REGISTRADOS EN DISCO:
        if (esNueva) {
            vaciarTablaUsuarios(db)
            //BORRAR hasta entender el concepto
        }
        */
        db.close()
        return esNueva
    }

    override fun onCreate(db: SQLiteDatabase?) {
        if (db != null) {
            CreacionBaseDatosSimula(db)
            // vaciarTablaUsuarios(db) // COMENTADO PARA PERMITIR PERSISTENCIA
        }
    }

    /**
     * Crea todas las tablas en la base de datos basándose en las clases del sistema:
     * Usuarios, Cuentas, Items, Simulaciones, DetallesSimulaciones.
     * La tabla Usuarios inicia completamente vacía.
     */
    fun CreacionBaseDatosSimula(db: SQLiteDatabase? = null) {
        val database = db ?: this.writableDatabase

        // Eliminar tablas antiguas en singular de versiones anteriores si existen
        try { database.execSQL("DROP TABLE IF EXISTS DetalleSimulacion;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Simulacion;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Cuenta;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Item;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Usuario;") } catch (e: Exception) { e.printStackTrace() }

        // Tabla Usuarios (Totalmente vacía al inicio con soporte para fechaHoraUsuario, saltUsuario, esAdmin y preferenciaTema)
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Usuarios (
                idUsuario INTEGER PRIMARY KEY AUTOINCREMENT,
                nombreUsuario TEXT NOT NULL UNIQUE,
                claveUsuario TEXT NOT NULL,
                saltUsuario TEXT NOT NULL DEFAULT '',
                fechaHoraUsuario TEXT NOT NULL DEFAULT '',
                esAdmin INTEGER DEFAULT 0,
                preferenciaTema TEXT DEFAULT ''
            )
            """.trimIndent()
        )

        // Tabla Cuentas
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Cuentas (
                idCuenta INTEGER PRIMARY KEY AUTOINCREMENT,
                idUsuario INTEGER NOT NULL,
                nombreCuenta TEXT NOT NULL,
                totalCuenta INTEGER NOT NULL,
                fechaHoraCuenta TEXT NOT NULL DEFAULT '',
                UNIQUE(idUsuario, nombreCuenta),
                FOREIGN KEY (idUsuario) REFERENCES Usuarios(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // Tabla Items
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Items (
                idItem INTEGER PRIMARY KEY AUTOINCREMENT,
                idUsuario INTEGER NOT NULL,
                nombreItem TEXT NOT NULL,
                valorItem INTEGER NOT NULL,
                UNIQUE(idUsuario, nombreItem),
                FOREIGN KEY (idUsuario) REFERENCES Usuarios(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // Tabla Simulaciones
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Simulaciones (
                idSim INTEGER PRIMARY KEY AUTOINCREMENT,
                idCuenta INTEGER NOT NULL,
                idUsuario INTEGER NOT NULL,
                nombreSim TEXT NOT NULL,
                fechaHoraSim TEXT NOT NULL,
                totalDisponible INTEGER NOT NULL,
                totalEgresos INTEGER NOT NULL,
                meses INTEGER NOT NULL,
                excedente INTEGER NOT NULL,
                UNIQUE(idUsuario, nombreSim),
                FOREIGN KEY (idCuenta) REFERENCES Cuentas(idCuenta) ON DELETE CASCADE,
                FOREIGN KEY (idUsuario) REFERENCES Usuarios(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // Tabla DetallesSimulaciones
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS DetallesSimulaciones (
                idDetalle INTEGER PRIMARY KEY AUTOINCREMENT,
                idSim INTEGER NOT NULL,
                idItem INTEGER,
                nombreItem TEXT NOT NULL,
                valorItem INTEGER NOT NULL,
                FOREIGN KEY (idSim) REFERENCES Simulaciones(idSim) ON DELETE CASCADE,
                FOREIGN KEY (idItem) REFERENCES Items(idItem) ON DELETE SET NULL
            )
            """.trimIndent()
        )
    }

    // Vacía completamente la tabla Usuarios y reinicia la secuencia de forma segura usando transacciones.
    fun vaciarTablaUsuarios(db: SQLiteDatabase? = null) {
        val database = db ?: this.writableDatabase
        val isInternalDb = (db == null)
        try {
            if (isInternalDb) database.beginTransaction()
            database.delete("Usuarios", null, null)
            try {
                database.delete("sqlite_sequence", "name=?", arrayOf("Usuarios"))
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (isInternalDb) database.setTransactionSuccessful()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (isInternalDb) {
                try {
                    database.endTransaction()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                database.close()
            }
        }
    }

    /**
     * Vacía completamente la base de datos eliminando todas las tablas y registros, pero preservando
     * ÚNICAMENTE al usuario activo (SesionUsuario.usuarioActivo) como administrador (esAdmin = 1)
     * con su contraseña correspondiente y sal criptográfica para permitirle volver a ingresar.
     */
    fun vaciarTodaLaBaseDatos() {
        try {
            val usuarioActual = SesionUsuario.usuarioActivo.ifBlank { "admin" }
            var claveActual = "admin123"
            var saltActual = ""
            var prefTema = ""

            // 1. Obtener la clave, sal y preferencias del usuario activo antes de borrar la base de datos
            try {
                val dbLectura = this.readableDatabase
                val cursor = dbLectura.query(
                    "Usuarios",
                    arrayOf("claveUsuario", "saltUsuario", "preferenciaTema"),
                    "nombreUsuario = ?",
                    arrayOf(usuarioActual),
                    null, null, null
                )
                if (cursor.moveToFirst()) {
                    val cIdx = cursor.getColumnIndex("claveUsuario")
                    val sIdx = cursor.getColumnIndex("saltUsuario")
                    val tIdx = cursor.getColumnIndex("preferenciaTema")
                    if (cIdx >= 0) {
                        val clv = cursor.getString(cIdx)
                        if (!clv.isNullOrBlank()) claveActual = clv
                    }
                    if (sIdx >= 0) {
                        val slt = cursor.getString(sIdx)
                        if (!slt.isNullOrBlank()) saltActual = slt
                    }
                    if (tIdx >= 0) {
                        prefTema = cursor.getString(tIdx) ?: ""
                    }
                }
                cursor.close()
                dbLectura.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // 2. Eliminar el archivo del dispositivo y recrear las tablas del sistema
            context.deleteDatabase(DATABASE_NAME)
            val db = this.writableDatabase
            CreacionBaseDatosSimula(db)

            // 3. Insertar ÚNICAMENTE al usuario activo como administrador (esAdmin = 1)
            val saltFinal = if (saltActual.isNotBlank()) saltActual else HashUtils.generarSalt()
            val claveFinalHashed = if (claveActual.length == 64) claveActual else HashUtils.hashPassword(claveActual, saltFinal)
            val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

            val values = ContentValues().apply {
                put("nombreUsuario", usuarioActual)
                put("claveUsuario", claveFinalHashed)
                put("saltUsuario", saltFinal)
                put("fechaHoraUsuario", fechaHoraActual)
                put("esAdmin", 1)
                put("preferenciaTema", prefTema)
            }
            db.insert("Usuarios", null, values)
            db.close()

            // 4. Mantener la variable global de sesión en memoria
            SesionUsuario.usuarioActivo = usuarioActual
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    //Devuelve la cantidad de usuarios guardados en la tabla Usuarios.
    fun obtenerCantidadUsuarios(): Int {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM Usuarios", null)
        val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        db.close()
        return count
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Migración segura preservando los datos existentes de los usuarios
        if (oldVersion < 2) {
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN esAdmin INTEGER DEFAULT 0;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN preferenciaTema TEXT DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 3) {
            try { db?.execSQL("ALTER TABLE Simulaciones ADD COLUMN idUsuario INTEGER NOT NULL DEFAULT 0;") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 4) {
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN fechaHoraUsuario TEXT NOT NULL DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("ALTER TABLE Cuentas ADD COLUMN fechaHoraCuenta TEXT NOT NULL DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 5) {
            try { db?.execSQL("DROP TABLE IF EXISTS DetalleSimulacion;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Simulacion;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Cuenta;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Item;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Usuario;") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 6) {
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN saltUsuario TEXT DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
        }
    }

    // MÉTODOS DE BASE DE DATOS PARA USUARIOS
    // Registra un nuevo usuario en la tabla Usuarios procesando su clave con HashUtils.
    // @return true si el usuario se guardó correctamente en la BD, false si ya existía o falló.
    fun registrarUsuario(nombre: String, clave: String): Boolean {
        if (existeUsuario(nombre)) return false

        val db = this.writableDatabase
        try {
            try { db.execSQL("ALTER TABLE Usuarios ADD COLUMN saltUsuario TEXT DEFAULT '';") } catch (e: Exception) { }

            val cursor = db.rawQuery("SELECT COUNT(*) FROM Usuarios", null)
            val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
            cursor.close()

            val esAdminVal = if (count == 0) 1 else 0
            val salt = HashUtils.generarSalt()
            val claveHashed = HashUtils.hashPassword(clave, salt)
            val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

            val values = ContentValues().apply {
                put("nombreUsuario", nombre)
                put("claveUsuario", claveHashed)
                put("saltUsuario", salt)
                put("fechaHoraUsuario", fechaHoraActual)
                put("esAdmin", esAdminVal)
            }
            val id = db.insert("Usuarios", null, values)
            db.close()
            return id != -1L
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                db.close()
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
            return false
        }
    }

    /**
     * Valida si el nombre de usuario y la clave ingresados coinciden con un registro en la tabla Usuarios.
     * Soporta validación con hash + salt y compatibilidad con claves antiguas.
     * @return true si las credenciales son válidas.
     */
    fun validarUsuario(nombre: String, clave: String): Boolean {
        val db = this.readableDatabase
        var esValido = false
        try {
            try { db.execSQL("ALTER TABLE Usuarios ADD COLUMN saltUsuario TEXT DEFAULT '';") } catch (e: Exception) { }

            val cursor = db.query(
                "Usuarios",
                null,
                "nombreUsuario = ?",
                arrayOf(nombre),
                null, null, null
            )
            if (cursor.moveToFirst()) {
                val idxHash = cursor.getColumnIndex("claveUsuario")
                val idxSalt = cursor.getColumnIndex("saltUsuario")
                if (idxHash >= 0) {
                    val hashGuardado = cursor.getString(idxHash) ?: ""
                    val saltGuardado = if (idxSalt >= 0) cursor.getString(idxSalt) ?: "" else ""

                    val hashCalculado = HashUtils.hashPassword(clave, saltGuardado)
                    val hashSinSalt = HashUtils.hashPassword(clave, "")

                    if (hashGuardado == hashCalculado || hashGuardado == hashSinSalt || hashGuardado == clave) {
                        esValido = true
                    }
                }
            }
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { db.close() } catch (e: Exception) { e.printStackTrace() }
        }
        return esValido
    }

    // Verifica si la contraseña ingresada corresponde a un usuario administrador (esAdmin = 1).
    fun verificarPasswordAdmin(password: String): Boolean {
        val db = this.readableDatabase
        var esValido = false
        try {
            try { db.execSQL("ALTER TABLE Usuarios ADD COLUMN saltUsuario TEXT DEFAULT '';") } catch (e: Exception) { }

            val cursor = db.query(
                "Usuarios",
                null,
                "esAdmin = 1",
                null, null, null, null
            )
            while (cursor.moveToNext()) {
                val idxHash = cursor.getColumnIndex("claveUsuario")
                val idxSalt = cursor.getColumnIndex("saltUsuario")
                if (idxHash >= 0) {
                    val hashGuardado = cursor.getString(idxHash) ?: ""
                    val saltGuardado = if (idxSalt >= 0) cursor.getString(idxSalt) ?: "" else ""

                    val hashCalculado = HashUtils.hashPassword(password, saltGuardado)
                    val hashSinSalt = HashUtils.hashPassword(password, "")

                    if (hashGuardado == hashCalculado || hashGuardado == hashSinSalt || hashGuardado == password) {
                        esValido = true
                        break
                    }
                }
            }
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { db.close() } catch (e: Exception) { e.printStackTrace() }
        }
        return esValido
    }

    /**
     * Actualiza el nombreUsuario y la claveUsuario (aplicando HashUtils) de un usuario en la tabla Usuarios.
     */
    fun actualizarUsuario(nombreAnterior: String, nombreNuevo: String, claveNueva: String): Boolean {
        val db = this.writableDatabase
        try { db.execSQL("ALTER TABLE Usuarios ADD COLUMN saltUsuario TEXT DEFAULT '';") } catch (e: Exception) { }
        val salt = HashUtils.generarSalt()
        val claveHashed = HashUtils.hashPassword(claveNueva, salt)
        val values = ContentValues().apply {
            put("nombreUsuario", nombreNuevo)
            put("claveUsuario", claveHashed)
            put("saltUsuario", salt)
        }
        val filas = db.update("Usuarios", values, "nombreUsuario = ?", arrayOf(nombreAnterior))
        db.close()
        return filas > 0
    }

    /**
     * Verifica si un nombre de usuario ya existe en la tabla Usuarios.
     */
    fun existeUsuario(nombre: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(
            "Usuarios",
            arrayOf("idUsuario"),
            "nombreUsuario = ?",
            arrayOf(nombre),
            null, null, null
        )
        val existe = cursor.moveToFirst()
        cursor.close()
        db.close()
        return existe
    }

    // Obtiene el idUsuario asociado a un nombreUsuario.
    fun obtenerIdUsuarioActivo(nombreUsuario: String): Int {
        val db = this.readableDatabase
        val cursor = db.query(
            "Usuarios",
            arrayOf("idUsuario"),
            "nombreUsuario = ?",
            arrayOf(nombreUsuario),
            null, null, null
        )
        val id = if (cursor.moveToFirst()) cursor.getInt(cursor.getColumnIndexOrThrow("idUsuario")) else 1
        cursor.close()
        db.close()
        return id
    }

    /**
     * Obtiene y asegura el nombre del usuario activo. Si el nombre suministrado es indeterminado o vacío,
     * obtiene el primer usuario registrado en la base de datos y sincroniza SesionUsuario.usuarioActivo.
     */
    fun obtenerNombreUsuarioActivo(nombreActual: String = SesionUsuario.usuarioActivo): String {
        if (nombreActual.isNotBlank() && nombreActual != "Usuario Activo") {
            return nombreActual
        }
        var nombreEncontrado = "admin"
        try {
            val db = this.readableDatabase
            val cursor = db.query("Usuarios", arrayOf("nombreUsuario"), null, null, null, null, "idUsuario ASC", "1")
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex("nombreUsuario")
                if (idx >= 0) {
                    val nom = cursor.getString(idx)
                    if (!nom.isNullOrBlank()) {
                        nombreEncontrado = nom
                    }
                }
            }
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        SesionUsuario.usuarioActivo = nombreEncontrado
        return nombreEncontrado
    }

    // MÉTODOS DE BASE DE DATOS PARA CUENTAS
    // Devuelve la lista de cuentas guardadas en la tabla Cuentas de la base de datos.
    fun obtenerCuentas(idUsuario: Int = 0): List<Cuenta> {
        val lista = mutableListOf<Cuenta>()
        val db = this.readableDatabase
        val cursor = if (idUsuario > 0) {
            db.query("Cuentas", null, "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, "nombreCuenta ASC")
        } else {
            db.query("Cuentas", null, null, null, null, null, "nombreCuenta ASC")
        }
        if (cursor.moveToFirst()) {
            val idCIndex = cursor.getColumnIndex("idCuenta")
            val idUIndex = cursor.getColumnIndex("idUsuario")
            val nomIndex = cursor.getColumnIndex("nombreCuenta")
            val totIndex = cursor.getColumnIndex("totalCuenta")
            val fecIndex = cursor.getColumnIndex("fechaHoraCuenta")
            do {
                val idC = if (idCIndex >= 0) cursor.getInt(idCIndex) else 0
                val idU = if (idUIndex >= 0) cursor.getInt(idUIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val tot = if (totIndex >= 0) cursor.getInt(totIndex) else 0
                val fec = if (fecIndex >= 0) cursor.getString(fecIndex) ?: "" else ""
                lista.add(Cuenta(idC, idU, nom, tot, fec))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

     // Inserta una nueva cuenta en la tabla Cuentas con la fecha/hora actual.
    fun insertarCuenta(idUsuario: Int, nombre: String, total: Int): Boolean {
        val db = this.writableDatabase
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val values = ContentValues().apply {
            put("idUsuario", idUsuario)
            put("nombreCuenta", nombre)
            put("totalCuenta", total)
            put("fechaHoraCuenta", fechaHoraActual)
        }
        val id = db.insertWithOnConflict("Cuentas", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        db.close()
        return id != -1L
    }

    // Devuelve el nombre de una cuenta a partir de su idCuenta.
    fun obtenerNombreCuentaPorId(idCuenta: Int): String {
        var nombre = ""
        try {
            val db = this.readableDatabase
            val cursor = db.query("Cuentas", arrayOf("nombreCuenta"), "idCuenta = ?", arrayOf(idCuenta.toString()), null, null, null)
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex("nombreCuenta")
                if (idx >= 0) {
                    nombre = cursor.getString(idx) ?: ""
                }
            }
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return nombre
    }

    // Actualiza el nombre y el valor/monto de una cuenta existente por su idCuenta.
    fun actualizarCuenta(idCuenta: Int, nombre: String, total: Int): Boolean {
        val db = this.writableDatabase
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val values = ContentValues().apply {
            put("nombreCuenta", nombre)
            put("totalCuenta", total)
            put("fechaHoraCuenta", fechaHoraActual)
        }
        val filas = db.update("Cuentas", values, "idCuenta = ?", arrayOf(idCuenta.toString()))
        db.close()
        return filas > 0
    }

     // Elimina una cuenta de la tabla Cuentas por su idCuenta, junto con sus simulaciones
     // y registros en la tabla DetallesSimulaciones correspondientes.
    fun eliminarCuenta(idCuenta: Int): Boolean {
        val db = this.writableDatabase
        db.beginTransaction()
        var filas = 0
        try {
            db.execSQL(
                "DELETE FROM DetallesSimulaciones WHERE idSim IN (SELECT idSim FROM Simulaciones WHERE idCuenta = ?)",
                arrayOf(idCuenta.toString())
            )
            db.delete("Simulaciones", "idCuenta = ?", arrayOf(idCuenta.toString()))
            filas = db.delete("Cuentas", "idCuenta = ?", arrayOf(idCuenta.toString()))
            db.setTransactionSuccessful()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { db.endTransaction() } catch (e: Exception) { e.printStackTrace() }
            db.close()
        }
        return filas > 0
    }

    fun cuentaOcupada(idCuenta: Int): String {
        var nombreSim = ""
        try {
            val db = this.readableDatabase
            val cursor = db.query(
                "Simulaciones",
                arrayOf("nombreSim"),
                "idCuenta = ?",
                arrayOf(idCuenta.toString()),
                null, null, null, "1"
            )
            if (cursor.moveToFirst()) {
                val colIndex = cursor.getColumnIndex("nombreSim")
                if (colIndex >= 0) {
                    nombreSim = cursor.getString(colIndex) ?: ""
                }
            }
            cursor.close()

            if (nombreSim.isEmpty()) {
                val cursorCta = db.query("Cuentas", arrayOf("nombreCuenta"), "idCuenta = ?", arrayOf(idCuenta.toString()), null, null, null)
                if (cursorCta.moveToFirst()) {
                    val nomIdx = cursorCta.getColumnIndex("nombreCuenta")
                    if (nomIdx >= 0) {
                        val nomCta = cursorCta.getString(nomIdx) ?: ""
                        if (nomCta.isNotEmpty()) {
                            val cursorSim = db.rawQuery(
                                "SELECT nombreSim FROM Simulaciones WHERE idCuenta = ? OR idCuenta IN (SELECT idCuenta FROM Cuentas WHERE nombreCuenta = ?) LIMIT 1",
                                arrayOf(idCuenta.toString(), nomCta)
                            )
                            if (cursorSim.moveToFirst()) {
                                val sIdx = cursorSim.getColumnIndex("nombreSim")
                                if (sIdx >= 0) {
                                    nombreSim = cursorSim.getString(sIdx) ?: ""
                                }
                            }
                            cursorSim.close()
                        }
                    }
                }
                cursorCta.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return nombreSim
    }

    // MÉTODOS DE BASE DE DATOS PARA ITEMS
    fun obtenerItems(idUsuario: Int = 0): List<Item> {
        val lista = mutableListOf<Item>()
        val db = this.readableDatabase
        val cursor = if (idUsuario > 0) {
            db.query("Items", null, "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, "nombreItem ASC")
        } else {
            db.query("Items", null, null, null, null, null, "nombreItem ASC")
        }
        if (cursor.moveToFirst()) {
            val idIIndex = cursor.getColumnIndex("idItem")
            val idUIndex = cursor.getColumnIndex("idUsuario")
            val nomIndex = cursor.getColumnIndex("nombreItem")
            val valIndex = cursor.getColumnIndex("valorItem")
            do {
                val idI = if (idIIndex >= 0) cursor.getInt(idIIndex) else 0
                val idU = if (idUIndex >= 0) cursor.getInt(idUIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val vItem = if (valIndex >= 0) cursor.getInt(valIndex) else 0
                lista.add(Item(idI, idU, nom, vItem))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    //Inserta un nuevo ítem en la tabla Items de la base de datos.
    fun insertarItem(idUsuario: Int, nombre: String, valor: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("idUsuario", idUsuario)
            put("nombreItem", nombre)
            put("valorItem", valor)
        }
        val id = db.insertWithOnConflict("Items", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        db.close()
        return id != -1L
    }

    /**
     * Actualiza el nombre y valor de un ítem en la tabla Items por su idItem.
     */
    fun actualizarItem(idItem: Int, nombre: String, valor: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("nombreItem", nombre)
            put("valorItem", valor)
        }
        val filas = db.update("Items", values, "idItem = ?", arrayOf(idItem.toString()))
        db.close()
        return filas > 0
    }

    /**
     * Elimina un ítem de la tabla Items por su idItem.
     */
    fun eliminarItem(idItem: Int): Boolean {
        val db = this.writableDatabase
        val filas = db.delete("Items", "idItem = ?", arrayOf(idItem.toString()))
        db.close()
        return filas > 0
    }

    /**
     * Verifica si un ítem está ocupado por alguna simulación en la tabla DetallesSimulaciones.
     * Retorna el nombre de la simulación que lo utiliza, o una cadena vacía "" si no está ocupado.
     */
    fun itemOcupado(idItem: Int): String {
        var nombreSim = ""
        try {
            val db = this.readableDatabase
            val query = """
                SELECT s.nombreSim 
                FROM DetallesSimulaciones d
                INNER JOIN Simulaciones s ON d.idSim = s.idSim
                WHERE d.idItem = ?
                LIMIT 1
            """.trimIndent()

            val cursor = db.rawQuery(query, arrayOf(idItem.toString()))
            if (cursor.moveToFirst()) {
                val colIndex = cursor.getColumnIndex("nombreSim")
                if (colIndex >= 0) {
                    nombreSim = cursor.getString(colIndex) ?: ""
                }
            }
            cursor.close()

            if (nombreSim.isEmpty()) {
                val cursorItem = db.query("Items", arrayOf("nombreItem"), "idItem = ?", arrayOf(idItem.toString()), null, null, null)
                if (cursorItem.moveToFirst()) {
                    val nomIdx = cursorItem.getColumnIndex("nombreItem")
                    if (nomIdx >= 0) {
                        val nom = cursorItem.getString(nomIdx) ?: ""
                        if (nom.isNotEmpty()) {
                            val cursorDet = db.rawQuery(
                                "SELECT s.nombreSim FROM DetallesSimulaciones d INNER JOIN Simulaciones s ON d.idSim = s.idSim WHERE d.nombreItem = ? LIMIT 1",
                                arrayOf(nom)
                            )
                            if (cursorDet.moveToFirst()) {
                                val colIdx = cursorDet.getColumnIndex("nombreSim")
                                if (colIdx >= 0) {
                                    nombreSim = cursorDet.getString(colIdx) ?: ""
                                }
                            }
                            cursorDet.close()
                        }
                    }
                }
                cursorItem.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return nombreSim
    }

    // =========================================================================
    // MÉTODOS DE BASE DE DATOS PARA SIMULACIONES
    // =========================================================================
    // Devuelve la lista de simulaciones guardadas en la tabla Simulaciones de la base de datos.
    fun obtenerSimulaciones(idUsuario: Int = 0): List<Simulacion> {
        val lista = mutableListOf<Simulacion>()
        val db = this.readableDatabase
        val cursor = if (idUsuario > 0) {
            db.query("Simulaciones", null, "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, "idSim DESC")
        } else {
            db.query("Simulaciones", null, null, null, null, null, "idSim DESC")
        }
        if (cursor.moveToFirst()) {
            val idSIndex = cursor.getColumnIndex("idSim")
            val idCIndex = cursor.getColumnIndex("idCuenta")
            val idUIndex = cursor.getColumnIndex("idUsuario")
            val nomIndex = cursor.getColumnIndex("nombreSim")
            val fecIndex = cursor.getColumnIndex("fechaHoraSim")
            val dispIndex = cursor.getColumnIndex("totalDisponible")
            val egrIndex = cursor.getColumnIndex("totalEgresos")
            val mesIndex = cursor.getColumnIndex("meses")
            val excIndex = cursor.getColumnIndex("excedente")
            do {
                val idS = if (idSIndex >= 0) cursor.getInt(idSIndex) else 0
                val idC = if (idCIndex >= 0) cursor.getInt(idCIndex) else 0
                val idU = if (idUIndex >= 0) cursor.getInt(idUIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val fec = if (fecIndex >= 0) cursor.getString(fecIndex) ?: "" else ""
                val disp = if (dispIndex >= 0) cursor.getInt(dispIndex) else 0
                val egr = if (egrIndex >= 0) cursor.getInt(egrIndex) else 0
                val mes = if (mesIndex >= 0) cursor.getInt(mesIndex) else 0
                val exc = if (excIndex >= 0) cursor.getInt(excIndex) else 0
                lista.add(Simulacion(idS, idC, idU, nom, fec, disp, egr, mes, exc))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

     //Inserta o actualiza una simulación (alias de guardarOActualizarSimulacion).
    fun insertarSimulacion(idCuenta: Int, idUsuario: Int, nombreSim: String, totalDisponible: Int, totalEgresos: Int, meses: Int, excedente: Int): Long {
        return guardarOActualizarSimulacion(idCuenta, idUsuario, nombreSim, totalDisponible, totalEgresos, meses, excedente)
    }

    /**
     * Guarda o actualiza una simulación: si ya existe una simulación con el mismo nombre para el usuario,
     * actualiza sus valores manteniendo su idSim original; si no existe, la inserta como nueva.
     * Devuelve el idSim (existente o nuevo), o -1L si falla.
     */
    fun guardarOActualizarSimulacion(idCuenta: Int, idUsuario: Int, nombreSim: String, totalDisponible: Int, totalEgresos: Int, meses: Int, excedente: Int): Long {
        val db = this.writableDatabase
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        val cursor = db.query(
            "Simulaciones",
            arrayOf("idSim"),
            "idUsuario = ? AND nombreSim = ?",
            arrayOf(idUsuario.toString(), nombreSim),
            null, null, null
        )
        val existingIdSim = if (cursor.moveToFirst()) {
            val idx = cursor.getColumnIndex("idSim")
            if (idx >= 0) cursor.getInt(idx) else -1
        } else {
            -1
        }
        cursor.close()

        val values = ContentValues().apply {
            put("idCuenta", idCuenta)
            put("idUsuario", idUsuario)
            put("nombreSim", nombreSim)
            put("fechaHoraSim", fechaHoraActual)
            put("totalDisponible", totalDisponible)
            put("totalEgresos", totalEgresos)
            put("meses", meses)
            put("excedente", excedente)
        }
        val resultId = if (existingIdSim != -1) {
            val filas = db.update("Simulaciones", values, "idSim = ?", arrayOf(existingIdSim.toString()))
            if (filas > 0) existingIdSim.toLong() else -1L
        } else {
            db.insert("Simulaciones", null, values)
        }
        db.close()
        return resultId
    }
    //Inserta un registro de detalle en la tabla DetallesSimulaciones.
    fun insertarDetalleSimulacion(idSim: Long, idItem: Int, nombreItem: String, valorItem: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("idSim", idSim)
            if (idItem > 0) put("idItem", idItem)
            put("nombreItem", nombreItem)
            put("valorItem", valorItem)
        }
        val id = db.insert("DetallesSimulaciones", null, values)
        db.close()
        return id != -1L
    }

    /**
     * Reemplaza de forma atómica todos los registros de detalle de una simulación (idSim),
     * eliminando primero los anteriores de la tabla DetallesSimulaciones e insertando
     * únicamente la lista actual enviada, de forma segura y sin cerrar la conexión del pool.
     */
    fun reemplazarDetallesSimulacion(idSim: Long, listaDetalles: List<Pair<String, Int>>, idUsuario: Int): Boolean {
        var exito = false
        val db = this.writableDatabase
        try {
            db.beginTransaction()

            // 1. Borrar de inmediato todos los detalles antiguos de esta simulación
            db.delete("DetallesSimulaciones", "idSim = ?", arrayOf(idSim.toString()))

            // 2. Obtener mapa de ítems existentes usando la misma conexión db abierta
            val mapaItemsBD = mutableMapOf<String, Int>()
            val cursorItems = if (idUsuario > 0) {
                db.query("Items", arrayOf("idItem", "nombreItem"), "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, null)
            } else {
                db.query("Items", arrayOf("idItem", "nombreItem"), null, null, null, null, null)
            }
            if (cursorItems.moveToFirst()) {
                val idxId = cursorItems.getColumnIndex("idItem")
                val idxNom = cursorItems.getColumnIndex("nombreItem")
                do {
                    val idI = if (idxId >= 0) cursorItems.getInt(idxId) else 0
                    val nomI = if (idxNom >= 0) cursorItems.getString(idxNom) ?: "" else ""
                    if (nomI.isNotEmpty()) {
                        mapaItemsBD[nomI.lowercase(Locale.ROOT)] = idI
                    }
                } while (cursorItems.moveToNext())
            }
            cursorItems.close()

            // 3. Insertar los nuevos registros actuales
            for (det in listaDetalles) {
                val nombreItem = det.first
                val valorItem = det.second
                val idItem = mapaItemsBD[nombreItem.lowercase(Locale.ROOT)] ?: 0

                val values = ContentValues().apply {
                    put("idSim", idSim)
                    if (idItem > 0) put("idItem", idItem)
                    put("nombreItem", nombreItem)
                    put("valorItem", valorItem)
                }
                db.insert("DetallesSimulaciones", null, values)
            }

            db.setTransactionSuccessful()
            exito = true
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try {
                if (db.inTransaction()) {
                    db.endTransaction()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                db.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return exito
    }

     //Devuelve la lista de registros de detalle asociados a una simulación (idSim).
    fun obtenerDetallesSimulacion(idSim: Int): List<DetalleSimulacion> {
        val lista = mutableListOf<DetalleSimulacion>()
        val db = this.readableDatabase
        val cursor = db.query("DetallesSimulaciones", null, "idSim = ?", arrayOf(idSim.toString()), null, null, null)
        if (cursor.moveToFirst()) {
            val idDIndex = cursor.getColumnIndex("idDetalle")
            val idSIndex = cursor.getColumnIndex("idSim")
            val idIIndex = cursor.getColumnIndex("idItem")
            val nomIndex = cursor.getColumnIndex("nombreItem")
            val valIndex = cursor.getColumnIndex("valorItem")
            do {
                val idD = if (idDIndex >= 0) cursor.getInt(idDIndex) else 0
                val idS = if (idSIndex >= 0) cursor.getInt(idSIndex) else 0
                val idI = if (idIIndex >= 0) cursor.getInt(idIIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val vItem = if (valIndex >= 0) cursor.getInt(valIndex) else 0
                lista.add(DetalleSimulacion(idD, idS, idI, nom, vItem))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    /**
     * Verifica si una simulación (idSim) posee detalles de ítems registrados en la tabla DetallesSimulaciones.
     */
    fun simulacionConDetalle(idSim: Int): Boolean {
        var tieneDetalles = false
        try {
            val db = this.readableDatabase
            val cursor = db.query("DetallesSimulaciones", arrayOf("idDetalle"), "idSim = ?", arrayOf(idSim.toString()), null, null, null, "1")
            tieneDetalles = cursor.moveToFirst()
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return tieneDetalles
    }

    /**
     * Elimina una simulación de la tabla Simulaciones y todos sus registros asociados
     * de la tabla DetallesSimulaciones por su idsimulacion.
     */
    fun eliminarSimulacion(idsimulacion: Int): Boolean {
        val db = this.writableDatabase
        db.delete("DetallesSimulaciones", "idSim = ?", arrayOf(idsimulacion.toString()))
        val filas = db.delete("Simulaciones", "idSim = ?", arrayOf(idsimulacion.toString()))
        db.close()
        return filas > 0
    }

    /**
     * Genera y puebla automáticamente la base de datos 'baseDatosTest1.db' con los 5 casos de prueba
     * de la matriz (Sercotec, Corfo, Inversión, Microempresa y Contingencia) con sus cuentas,
     * simulaciones y detalles de ítems correspondientes, exportando una copia a Descargas.
     */
    fun generaBaseDatosTest1(): Boolean {
        return try {
            val dbFile = context.getDatabasePath("baseDatosTest1.db")
            dbFile.parentFile?.mkdirs()

            val db = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
            CreacionBaseDatosSimula(db)

            val idUsuario = 1
            val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

            val saltTest = HashUtils.generarSalt()
            val claveTestHashed = HashUtils.hashPassword("admin123", saltTest)
            val cvUser = ContentValues().apply {
                put("nombreUsuario", "admin")
                put("claveUsuario", claveTestHashed)
                put("saltUsuario", saltTest)
                put("fechaHoraUsuario", fechaHoraActual)
                put("esAdmin", 1)
            }
            db.insertWithOnConflict("Usuarios", null, cvUser, SQLiteDatabase.CONFLICT_IGNORE)

            // Caso 1: Sercotec
            insertarCasoEnDb(db, idUsuario, "Cuenta Sercotec Fondo Fijo", 3500000, "Sercotec Capital Emprende 2026", 3500000, 700000, 5, 0, listOf(
                Pair("Arriendo Taller", 400000),
                Pair("Insumos y Materia Prima", 150000),
                Pair("Servicios Básicos (Luz/Agua/Net)", 80000),
                Pair("Telefonía y Marketing", 70000)
            ))

            // Caso 2: Corfo
            insertarCasoEnDb(db, idUsuario, "Cuenta Subsidio Corfo", 15000000, "Corfo Semilla Inicia 2026", 15000000, 3100000, 4, 2600000, listOf(
                Pair("Honorarios Desarrollador Senior", 1800000),
                Pair("Servicios Cloud y Servidores", 250000),
                Pair("Asesoría Legal y Patentes", 350000),
                Pair("Marketing y Adquisición", 500000),
                Pair("Espacio Cowork", 200000)
            ))

            // Caso 3: Inversión
            insertarCasoEnDb(db, idUsuario, "Cuenta Inversión Expansión", 25000000, "Ronda Inversionista Ángel V1", 25000000, 7500000, 3, 2500000, listOf(
                Pair("Sueldos Equipo Comercial", 3600000),
                Pair("Arriendo Oficina Central", 1200000),
                Pair("Campañas Difusión Masiva", 1500000),
                Pair("Licencias Software y SaaS", 800000),
                Pair("Auditoría y Contabilidad", 400000)
            ))

            // Caso 4: Microempresa
            insertarCasoEnDb(db, idUsuario, "Cuenta Ahorro Personal", 1800000, "Apertura Local Comercial", 1800000, 750000, 2, 300000, listOf(
                Pair("Arriendo Local Comercial", 350000),
                Pair("Mercadería e Insumos", 280000),
                Pair("Luz y Agua Comercial", 65000),
                Pair("Patente y Gastos Varios", 55000)
            ))

            // Caso 5: Contingencia
            insertarCasoEnDb(db, idUsuario, "Cuenta Ahorro Emergencia", 500000, "Evaluación de Riesgo Inicial", 500000, 650000, 0, 500000, listOf(
                Pair("Arriendo", 450000),
                Pair("Mercadería", 200000)
            ))

            db.close()

            // Copiar a simulafin.db activa para uso inmediato en la app
            val dbActiva = context.getDatabasePath(DATABASE_NAME)
            dbFile.copyTo(dbActiva, overwrite = true)

            // Exportar copia a Descargas (Downloads)
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                ?: context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            if (downloadsDir != null) {
                downloadsDir.mkdirs()
                val copiaDescargas = File(downloadsDir, "baseDatosTest1.db")
                dbFile.copyTo(copiaDescargas, overwrite = true)
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun insertarCasoEnDb(
        db: SQLiteDatabase,
        idUsuario: Int,
        nombreCuenta: String,
        montoCuenta: Int,
        nombreSim: String,
        disp: Int,
        egr: Int,
        meses: Int,
        excedente: Int,
        items: List<Pair<String, Int>>
    ) {
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        val cvCta = ContentValues().apply {
            put("idUsuario", idUsuario)
            put("nombreCuenta", nombreCuenta)
            put("totalCuenta", montoCuenta)
            put("fechaHoraCuenta", fechaHoraActual)
        }
        val idCuenta = db.insertWithOnConflict("Cuentas", null, cvCta, SQLiteDatabase.CONFLICT_REPLACE)

        val cvSim = ContentValues().apply {
            put("idCuenta", idCuenta)
            put("idUsuario", idUsuario)
            put("nombreSim", nombreSim)
            put("fechaHoraSim", fechaHoraActual)
            put("totalDisponible", disp)
            put("totalEgresos", egr)
            put("meses", meses)
            put("excedente", excedente)
        }
        val idSim = db.insertWithOnConflict("Simulaciones", null, cvSim, SQLiteDatabase.CONFLICT_REPLACE)

        for (pair in items) {
            val cvItem = ContentValues().apply {
                put("idUsuario", idUsuario)
                put("nombreItem", pair.first)
                put("valorItem", pair.second)
            }
            val idItem = db.insertWithOnConflict("Items", null, cvItem, SQLiteDatabase.CONFLICT_REPLACE)

            val cvDet = ContentValues().apply {
                put("idSim", idSim)
                if (idItem > 0) put("idItem", idItem)
                put("nombreItem", pair.first)
                put("valorItem", pair.second)
            }
            db.insert("DetallesSimulaciones", null, cvDet)
        }
    }

    companion object {
        const val DATABASE_NAME = "simulafin.db"
        private const val DATABASE_VERSION = 6
    }
}
