package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaClave
import com.simulafin.clases.presentaPie

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //EN PIE DE PAG detalle
        presentaPie("Ingrese sus credenciales para acceder al sistema de simulaciones financieras SimulaFin.")

        // Verificar e inicializar la base de datos y sus tablas al arrancar la app
        val dbHelper = BaseDatosHelper(this)
        dbHelper.generaBaseDatos()

        //componentes valido activos
        val etUsuario = findViewById<EditText>(R.id.etUsuario)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        etPassword.presentaClave()
        val btnIngresar = findViewById<Button>(R.id.btnIngresar)
        val tvRegistrarseLink = findViewById<TextView>(R.id.tvRegistrarseLink)

        //BOTON ingresar
        btnIngresar.setOnClickListener {
            val usuario = etUsuario.text.toString().trim()
            val password = etPassword.text.toString().trim()

            //valida err in
            if (usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese usuario y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // Consultar cuántos usuarios existen en la tabla Usuario de la base de datos
            val cantidadUsuarios = dbHelper.obtenerCantidadUsuarios()
            // sin usuarios reg
            if (cantidadUsuarios == 0) {
                Toast.makeText(this, "No hay usuarios registrados. Por favor regístrese primero.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // Validación estricta de credenciales contra la BD. Si la tabla está vacía o no coincide, no permite el acceso.
            val esValido = dbHelper.validarUsuario(usuario, password)
            //VUELVE DE UN RETORNO validado
            if (esValido) {
                SesionUsuario.usuarioActivo = usuario
                Toast.makeText(this, "Bienvenido $usuario", Toast.LENGTH_SHORT).show()
                //carga main activity
                val intentMain = Intent(this, MainActivity::class.java)
                startActivity(intentMain)
                finish()
            } else {
                Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
        //TEXTO interactivo para registarse
        tvRegistrarseLink?.setOnClickListener {
            val intent = Intent(this, registroUsuarioNuevo::class.java)
            startActivity(intent)
        }
    }
}
