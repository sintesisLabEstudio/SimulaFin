package com.simulafin.clases

import android.content.Context
import java.io.File

class GestorRespaldo {
    //respalda la base en un archivo .db de sqlite
    fun respaldar(context: Context, ruta: String = ""): Boolean {
        return try {
            val dbFile = context.getDatabasePath(BaseDatosHelper.DATABASE_NAME)
            if (!dbFile.exists()) {
                val helper = BaseDatosHelper(context)
                helper.writableDatabase.close()
            }
            val destFile = if (ruta.isNotEmpty()) File(ruta) else File(context.getExternalFilesDir(null), "simulafin_backup.db")
            destFile.parentFile?.mkdirs()
            dbFile.copyTo(destFile, overwrite = true)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    //carga la bas de datps del archivo externo (peligra borrar local
    fun importar(context: Context, archivo: String): Boolean {
        return try {
            val srcFile = File(archivo)
            if (!srcFile.exists()) return false
            val dbFile = context.getDatabasePath(BaseDatosHelper.DATABASE_NAME)
            dbFile.parentFile?.mkdirs()
            srcFile.copyTo(dbFile, overwrite = true)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    //si existe el archivo
    fun validarArchivo(archivo: String): Boolean {
        val file = File(archivo)
        return file.exists() && file.length() > 0
    }
}
