package com.simulafin.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.simulafin.R

class SimulacionInputFragment : Fragment() {

    private val listaItemsAgregados = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_simulacion_input, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val spnItems = view.findViewById<Spinner>(R.id.spnItems)
        val txtValorItem = view.findViewById<EditText>(R.id.txtValorItem)
        val btnAgregaItem = view.findViewById<Button>(R.id.btnAgregaItem)
        val lstItemsSeleccionados = view.findViewById<ListView>(R.id.lstItemsSeleccionados)

        // Configurar el adaptador para el ListView
        adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            listaItemsAgregados
        )

        // SE COMENTA LA SIGUIENTE LINEA PARA QUE PREVALEZCA EL FORMATO POR DEFECTO DEL XML (android:entries="@array/items_por_defecto")
        // DESCOMENTAR EN EL FUTURO CUANDO SE QUIERA MANEJAR LA LISTA DINAMICAMENTE DESDE KOTLIN:
        // lstItemsSeleccionados.adapter = adapter

        // Listener para agregar un elemento a la lista al presionar 'Agregar'
        btnAgregaItem.setOnClickListener {
            val itemSeleccionado = spnItems.selectedItem?.toString() ?: ""
            val monto = txtValorItem.text.toString()

            if (itemSeleccionado.isNotEmpty() && monto.isNotEmpty()) {
                val registro = "$itemSeleccionado - $$monto"
                listaItemsAgregados.add(registro)
                
                // SI SE DESCOMENTA EL ADAPTADOR SUPERIOR, DESCOMENTAR TAMBIEN ESTA LINEA PARA REFLEJAR CAMBIOS DINAMICOS:
                // lstItemsSeleccionados.adapter = adapter
                adapter.notifyDataSetChanged()
                txtValorItem.text.clear()
            } else {
                Toast.makeText(requireContext(), "Seleccione un ítem e ingrese el monto", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
