package com.simulafin.interfaces

interface OnSimulacionDatosListener {
    fun onDatosSimulacionIngresados()
}
