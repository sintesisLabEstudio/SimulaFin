package com.simulafin.interfaces

interface OnItemClickListener {
    fun onItemClick(position: Int)
}
