package com.simulafin

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class SimulacionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simulacion)
    }
}
