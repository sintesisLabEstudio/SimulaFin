package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Verificar e inicializar la base de datos al arrancar la app
        val dbHelper = BaseDatosHelper(this)
        dbHelper.generaBaseDatos()

        val etUsuario = findViewById<EditText>(R.id.etUsuario)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnIngresar = findViewById<Button>(R.id.btnIngresar)

        btnIngresar.setOnClickListener {
            val usuario = etUsuario.text.toString()
            val password = etPassword.text.toString()

            if (usuario.isNotEmpty() && password.isNotEmpty()) {
                Toast.makeText(this, "Bienvenido $usuario", Toast.LENGTH_SHORT).show()

                // Navegar al menú principal (MainActivity)
                val intentMain = Intent(this, MainActivity::class.java)
                startActivity(intentMain)
                finish() // Cierra LoginActivity para que no quede en el historial de navegación
            } else {
                Toast.makeText(this, "Por favor ingrese usuario y contraseña", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
