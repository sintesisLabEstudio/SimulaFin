package com.simulafin.clases

data class Item(
    val idItem: Int = 0,
    val idUsuario: Int = 0,
    val nombreItem: String = "",
    val valorItem: Int = 0
)
