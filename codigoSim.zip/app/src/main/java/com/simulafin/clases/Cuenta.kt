package com.simulafin.clases

data class Cuenta(
    val idCuenta: Int = 0,
    val idUsuario: Int = 0,
    val nombreCuenta: String = "",
    val totalCuenta: Int = 0
)
