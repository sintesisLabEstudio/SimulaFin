package com.simulafin.clases

data class Simulacion(
    val idSim: Int = 0,
    val idCuenta: Int = 0,
    val nombreSim: String = "",
    val fechaHoraSim: String = "",
    val totalDisponible: Int = 0,
    val totalEgresos: Int = 0,
    val meses: Int = 0,
    val excedente: Int = 0
)
