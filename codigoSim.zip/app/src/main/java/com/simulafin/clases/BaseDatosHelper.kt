package com.simulafin.clases

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

class BaseDatosHelper(private val context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    /**
     * Verifica si la base de datos 'simulafin.db' existe.
     * Si no existe, la crea llamando a writableDatabase (que desencadena onCreate).
     * @return true si la base fue creada por primera vez, false si ya existía.
     */
    fun generaBaseDatos(): Boolean {
        val dbFile: File = context.getDatabasePath(DATABASE_NAME)
        return if (!dbFile.exists()) {
            val db = this.writableDatabase
            db.close()
            true
        } else {
            false
        }
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            """
            CREATE TABLE Usuario (
                idUsuario INTEGER PRIMARY KEY AUTOINCREMENT,
                nombreUsuario TEXT NOT NULL,
                claveUsuario TEXT NOT NULL
            )
            """.trimIndent()
        )

        db?.execSQL(
            """
            CREATE TABLE Cuenta (
                idCuenta INTEGER PRIMARY KEY AUTOINCREMENT,
                idUsuario INTEGER NOT NULL,
                nombreCuenta TEXT NOT NULL,
                totalCuenta INTEGER NOT NULL,
                FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        db?.execSQL(
            """
            CREATE TABLE Item (
                idItem INTEGER PRIMARY KEY AUTOINCREMENT,
                idUsuario INTEGER NOT NULL,
                nombreItem TEXT NOT NULL,
                valorItem INTEGER NOT NULL,
                FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        db?.execSQL(
            """
            CREATE TABLE Simulacion (
                idSim INTEGER PRIMARY KEY AUTOINCREMENT,
                idCuenta INTEGER NOT NULL,
                nombreSim TEXT NOT NULL,
                fechaHoraSim TEXT NOT NULL,
                totalDisponible INTEGER NOT NULL,
                totalEgresos INTEGER NOT NULL,
                meses INTEGER NOT NULL,
                excedente INTEGER NOT NULL,
                FOREIGN KEY (idCuenta) REFERENCES Cuenta(idCuenta) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        db?.execSQL(
            """
            CREATE TABLE DetalleSimulacion (
                idDetalle INTEGER PRIMARY KEY AUTOINCREMENT,
                idSim INTEGER NOT NULL,
                idItem INTEGER,
                nombreItem TEXT NOT NULL,
                valorItem INTEGER NOT NULL,
                FOREIGN KEY (idSim) REFERENCES Simulacion(idSim) ON DELETE CASCADE,
                FOREIGN KEY (idItem) REFERENCES Item(idItem) ON DELETE SET NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS DetalleSimulacion")
        db?.execSQL("DROP TABLE IF EXISTS Simulacion")
        db?.execSQL("DROP TABLE IF EXISTS Item")
        db?.execSQL("DROP TABLE IF EXISTS Cuenta")
        db?.execSQL("DROP TABLE IF EXISTS Usuario")
        onCreate(db)
    }

    companion object {
        const val DATABASE_NAME = "simulafin.db"
        private const val DATABASE_VERSION = 1
    }
}
