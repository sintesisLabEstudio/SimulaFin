package com.simulafin.clases

class GestorRespaldo {

    fun respaldar(ruta: String): Boolean {
        return true
    }

    fun importar(archivo: String): Boolean {
        return true
    }

    fun validarArchivo(archivo: String): Boolean {
        return true
    }
}
