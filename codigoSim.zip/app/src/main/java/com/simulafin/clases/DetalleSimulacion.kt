package com.simulafin.clases

data class DetalleSimulacion(
    val idDetalle: Int = 0,
    val idSim: Int = 0,
    val idItem: Int? = null,
    val nombreItem: String = "",
    val valorItem: Int = 0
)
