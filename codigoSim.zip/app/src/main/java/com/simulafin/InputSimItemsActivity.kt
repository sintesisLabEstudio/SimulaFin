package com.simulafin

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class InputSimItemsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_sim_items)
    }
}
