package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnSimulaciones = findViewById<Button>(R.id.btnSimulaciones)
        btnSimulaciones.setOnClickListener {
            val intentSimulaciones = Intent(this, SimulacionActivity::class.java)
            startActivity(intentSimulaciones)
        }
    }
}
