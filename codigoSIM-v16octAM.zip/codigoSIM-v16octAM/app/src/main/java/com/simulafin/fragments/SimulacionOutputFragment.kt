package com.simulafin.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.simulafin.R
import com.simulafin.interfaces.OnSimulacionDatosListener

class SimulacionOutputFragment : Fragment() {

    private var txtTotalItems: EditText? = null
    private var txtTotalMeses: EditText? = null
    private var txtExcedente: EditText? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_simulacion_output, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        txtTotalItems = view.findViewById(R.id.txtTotalItems)
        txtTotalMeses = view.findViewById(R.id.txtTotalMeses)
        txtExcedente = view.findViewById(R.id.txtExcedente)

        val btnGuardaSim = view.findViewById<Button>(R.id.btnGuardaSim)
        val btnLimpiar = view.findViewById<Button>(R.id.btnLimpiar)
        val btnEliminaSim = view.findViewById<Button>(R.id.btnEliminaSim)
        val btnImprime = view.findViewById<Button>(R.id.btnImprime)

        btnGuardaSim?.setOnClickListener {
            val listener = activity as? OnSimulacionDatosListener
            listener?.onSolicitarGuardarSimulacion()
        }

        btnLimpiar?.setOnClickListener {
            limpiaSimulacion()
        }

        btnEliminaSim?.setOnClickListener {
            mostrarDialogConfirmarEliminar()
        }

        btnImprime?.setOnClickListener {
            printSimulacion()
        }
    }

    /**
     * Vacía todos los campos de resultados de la simulación en pantalla y
     * solicita limpiar también los componentes de entrada en SimulacionInputFragment.
     */
    fun limpiaSimulacion() {
        limpiaCamposOutput()
        val listener = activity as? OnSimulacionDatosListener
        listener?.onSolicitarLimpiarSimulacion()
    }

    fun limpiaCamposOutput() {
        txtTotalItems?.setText("")
        txtTotalMeses?.setText("")
        txtExcedente?.setText("")
    }

    fun printSimulacion() {
        val listener = activity as? OnSimulacionDatosListener
        listener?.onSolicitarImprimirSimulacion()
    }

    fun getTotalItemsValue(): Long = txtTotalItems?.text?.toString()?.replace("[^0-9]".toRegex(), "")?.toLongOrNull() ?: 0L
    fun getTotalMesesValue(): Long = txtTotalMeses?.text?.toString()?.replace("[^0-9]".toRegex(), "")?.toLongOrNull() ?: 0L
    fun getExcedenteValue(): Long = txtExcedente?.text?.toString()?.replace("[^0-9]".toRegex(), "")?.toLongOrNull() ?: 0L

    private fun mostrarDialogConfirmarEliminar() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Alerta de Eliminación")
        builder.setMessage("¿Está seguro de que desea eliminar la simulación actual? Esta acción eliminará la simulación de la base de datos.")

        builder.setPositiveButton("Eliminar") { dialog, _ ->
            val listener = activity as? OnSimulacionDatosListener
            listener?.onSolicitarEliminarSimulacion()
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    fun actualizarResultados(totalGastos: Long, totalCuenta: Long = 0L) {
        if (txtTotalItems == null) return

        txtTotalItems?.setText("$totalGastos")

        if (totalGastos > 0 && totalCuenta > 0) {
            val meses = totalCuenta / totalGastos
            val costoTotal = meses * totalGastos
            val excedente = totalCuenta - costoTotal

            txtTotalMeses?.setText("$meses")
            txtExcedente?.setText("$excedente")
        } else if (totalGastos > 0) {
            txtTotalMeses?.setText("0")
            txtExcedente?.setText("0")
        } else {
            txtTotalItems?.setText("")
            txtTotalMeses?.setText("")
            txtExcedente?.setText("")
        }
    }
}
