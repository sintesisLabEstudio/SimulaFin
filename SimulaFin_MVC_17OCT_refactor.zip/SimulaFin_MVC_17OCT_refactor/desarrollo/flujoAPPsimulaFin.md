# Flujo completo de SimulaFin

Documento de navegación y procesos funcionales de la aplicación Android, elaborado a partir de las Activities, Fragments, controlador, repositorio y persistencia existentes en el proyecto.

## 1. Arquitectura y alcance

SimulaFin presenta un inicio de sesión local y cinco opciones en el menú principal. La simulación puede realizarse con dos recorridos alternativos:

- **Paso a paso:** `InputSimCuentaActivity` -> `InputSimItemsActivity` -> `OutSimResumenActivity`. El estado temporal se comparte mediante extras de `Intent` y `SesionSimulacion`; las operaciones de persistencia de este recorrido usan `BaseDatosHelper`.
- **Síntesis MVC:** `SimulacionActivity` contiene `SimulacionInputFragment` y `SimulacionOutputFragment`. Los fragments notifican cambios a la Activity con `OnSimulacionDatosListener`; la Activity delega persistencia y validaciones en `SimulacionController` y `SQLiteSimulacionRepository`.

La base local es SQLite (`simulafin.db`). `SesionUsuario.usuarioActivo` identifica al usuario activo. El catálogo de cuentas, ítems y simulaciones se consulta por usuario. Las contraseñas se guardan con hash y salt.

## 2. Flujo global de navegación

```mermaid
flowchart TD
    Inicio([Inicio de la app]) --> Login[LoginActivity]
    Login --> Inicializa[Inicializa o abre SQLite y crea tablas]
    Inicializa --> Credenciales{¿Datos completos y hay usuarios registrados?}
    Credenciales -->|No hay usuarios| Alta[registroUsuarioNuevo]
    Credenciales -->|Campos incompletos| Login
    Credenciales -->|Sí| Valida{¿Credenciales válidas?}
    Valida -->|No| Login
    Valida -->|Sí| Activa[Establece SesionUsuario.usuarioActivo]
    Activa --> Principal[MainActivity]
    Alta --> ValidarAlta{¿Campos completos, claves iguales y nombre libre?}
    ValidarAlta -->|No| Alta
    ValidarAlta -->|Sí| GuardaUsuario[Guarda usuario con hash y salt]
    GuardaUsuario --> Activa
    Alta -->|Home o atrás| Login

    Principal -->|Simulaciones| MenuSim[MenuSimActivity]
    Principal -->|Cuentas| Cuentas[CuentasActivity]
    Principal -->|Ítems| Items[ItemsActivity]
    Principal -->|Registro de usuario| Registro[RegistroActivity]
    Principal -->|Respaldo| Respaldo[RespaldoActivity]
    Cuentas -->|Home| Principal
    Items -->|Home| Principal
    Registro -->|Guardar cambios o Home| Principal
    Respaldo -->|Home| Principal

    MenuSim -->|Paso a paso| Paso1[InputSimCuentaActivity]
    MenuSim -->|Síntesis MVC| MVC[SimulacionActivity]
    MenuSim -->|Consultar guardadas| Consulta[ConsultaSimulacionesActivity]
    MenuSim -->|Home| Principal

    Paso1 -->|Selección válida| Paso2[InputSimItemsActivity]
    Paso1 -->|Home| Principal
    Paso2 -->|Uno o más ítems| Resumen[OutSimResumenActivity]
    Paso2 -->|Home| Principal
    Resumen -->|Volver a editar ítems| Paso2
    Resumen -->|Iniciar otra simulación| Paso1
    Resumen -->|Grabar o imprimir| Resumen
    Resumen -->|Menú| MenuSim
    Resumen -->|Home| Principal

    MVC -->|Guardar, eliminar, limpiar o imprimir| MVC
    MVC -->|Home| Principal
    Consulta -->|Seleccionar, exportar o imprimir| Consulta
    Consulta -->|Home| Principal
    Respaldo -->|Respaldar, restaurar o vaciar| Respaldo
```

## 3. Inicio de sesión y registro

```mermaid
sequenceDiagram
    autonumber
    actor Usuario
    participant Login as LoginActivity
    participant Alta as registroUsuarioNuevo
    participant BD as BaseDatosHelper / SQLite
    participant Main as MainActivity

    Usuario->>Login: Abre la aplicación
    Login->>BD: generaBaseDatos() y asegura las tablas
    Usuario->>Login: Ingresa usuario y contraseña
    Login->>Login: Valida que los campos no estén vacíos
    alt Campos incompletos
        Login-->>Usuario: Solicita completar los campos
    else Campos completos
        Login->>BD: obtenerCantidadUsuarios()
        alt No hay usuarios registrados
            Login-->>Usuario: Solicita registrarse
        else Hay usuarios
            Login->>BD: validarUsuario(usuario, contraseña)
            alt Credenciales correctas
                BD-->>Login: Usuario válido
                Login->>Login: Establece SesionUsuario.usuarioActivo
                Login->>Main: Abre MainActivity y cierra el login
            else Credenciales incorrectas
                BD-->>Login: Usuario o clave no coinciden
                Login-->>Usuario: Informa el error y permanece en LoginActivity
            end
        end
    end
    Usuario->>Login: Selecciona Registrarse
    Login->>Alta: Abre registroUsuarioNuevo
    Usuario->>Alta: Informa nombre, clave y confirmación
    Alta->>Alta: Valida campos y coincidencia de claves
    Alta->>BD: Comprueba nombre y registra clave con hash y salt
    alt Validación fallida o usuario existente
        Alta-->>Usuario: Informa el error y permite corregir
    else Registro correcto
        Alta->>Alta: Activa SesionUsuario.usuarioActivo
        Alta->>Main: Abre MainActivity y cierra el registro
    end
    Usuario->>Alta: Pulsa Home o atrás
    Alta-->>Login: Cierra el formulario sin registrar
```

El registro inicial exitoso inicia sesión directamente y abre el menú principal. `RegistroActivity`, accesible desde el menú principal, actualiza los datos del usuario activo; valida campos y confirmación de contraseña, actualiza la sesión y cierra el formulario al guardar.

## 4. Menú principal y mantenimiento de datos

### Cuentas (`CuentasActivity`)

```mermaid
flowchart TD
    Inicio[Abre CuentasActivity] --> Carga[Consulta cuentas del usuario en SQLite]
    Carga --> Lista[Actualiza Spinner y lista de cuentas]
    Lista --> Accion{Acción del usuario}
    Accion -->|Selecciona fila o cuenta| Editar[Carga nombre y saldo en campos]
    Accion -->|Agregar| Nuevo[Diálogo para nombre y monto]
    Nuevo --> ValidaNuevo{¿Datos completos?}
    ValidaNuevo -->|Sí| Inserta[Inserta cuenta en SQLite]
    Inserta --> Carga
    ValidaNuevo -->|No| Lista
    Accion -->|Grabar| ValidaEditar{¿Cuenta seleccionada y datos completos?}
    ValidaEditar -->|Sí| Actualiza[Actualiza cuenta]
    Actualiza --> Carga
    ValidaEditar -->|No| Lista
    Accion -->|Eliminar| Uso{¿Cuenta asociada a una simulación?}
    Uso -->|Sí| Bloqueo[Deniega eliminación]
    Uso -->|No| Confirma{¿Confirma eliminación?}
    Confirma -->|Sí| Borra[Elimina cuenta]
    Borra --> Carga
    Confirma -->|No| Lista
    Lista -->|Home| Principal[MainActivity]
```

### Ítems (`ItemsActivity`)

```mermaid
flowchart TD
    Inicio[Abre ItemsActivity] --> Carga[Consulta ítems del usuario en SQLite]
    Carga --> Lista[Actualiza Spinner y lista de ítems]
    Lista --> Accion{Acción del usuario}
    Accion -->|Selecciona fila o ítem| Editar[Carga nombre y monto en campos]
    Accion -->|Agregar| Nuevo[Diálogo para nombre y monto]
    Nuevo --> ValidaNuevo{¿Datos completos?}
    ValidaNuevo -->|Sí| Inserta[Inserta ítem en SQLite]
    Inserta --> Carga
    ValidaNuevo -->|No| Lista
    Accion -->|Grabar| ValidaEditar{¿Ítem seleccionado y datos completos?}
    ValidaEditar -->|Sí| Actualiza[Actualiza ítem]
    Actualiza --> Carga
    ValidaEditar -->|No| Lista
    Accion -->|Eliminar| Uso{¿Ítem asociado a detalles guardados?}
    Uso -->|Sí| Bloqueo[Deniega eliminación e informa la simulación asociada]
    Uso -->|No| Confirma{¿Confirma eliminación?}
    Confirma -->|Sí| Borra[Elimina ítem]
    Borra --> Carga
    Confirma -->|No| Lista
    Lista -->|Home| Principal[MainActivity]
```

Ambos mantenimientos operan sobre datos del usuario activo. Los formularios ofrecen selección, creación, edición y eliminación, con confirmación antes de borrar. Las cuentas y los ítems vinculados a simulaciones no se pueden eliminar desde sus pantallas de mantenimiento.

## 5. Simulación paso a paso

```mermaid
sequenceDiagram
    autonumber
    actor Usuario
    participant Paso1 as InputSimCuentaActivity
    participant Paso2 as InputSimItemsActivity
    participant Resumen as OutSimResumenActivity
    participant Sesion as SesionSimulacion
    participant BD as BaseDatosHelper / SQLite
    participant Visor as Visor PDF del sistema

    Usuario->>Paso1: Abre Paso a paso desde MenuSimActivity
    Paso1->>BD: Carga simulaciones y cuentas del usuario
    Usuario->>Paso1: Selecciona o crea simulación y cuenta
    Usuario->>Paso1: Ajusta saldo (opcional) y pulsa Siguiente
    alt Falta simulación, cuenta o saldo
        Paso1-->>Usuario: Muestra validación y no avanza
    else Selección válida
        opt La simulación tiene detalles guardados
            Paso1->>BD: Comprueba si existen detalles
            alt Confirma sobrescritura
                Paso1->>Sesion: Guarda selección temporal
            else Rechaza sobrescritura
                Paso1-->>Usuario: Ofrece crear otra simulación
            end
        end
        Paso1->>Sesion: Guarda nombre, cuenta y saldo
        Paso1->>Paso2: Envía datos mediante extras del Intent
    end
    Paso2->>BD: Carga catálogo de ítems
    opt Se reabre una simulación existente
        Paso2->>BD: Carga sus detalles guardados
        Paso2->>Sesion: Restaura lista temporal de ítems
    end
    Usuario->>Paso2: Selecciona ítem y monto; pulsa Agregar
    Paso2->>Sesion: Añade el ítem a la lista
    Paso2->>Paso2: Recalcula el total mensual
    opt El usuario elimina una fila seleccionada
        Usuario->>Paso2: Pulsa Eliminar
        Paso2->>Sesion: Quita el ítem y recalcula el total
    end
    Usuario->>Paso2: Pulsa Aceptar / Siguiente
    alt No hay ítems
        Paso2-->>Usuario: Solicita agregar al menos un ítem
    else Hay ítems
        opt La simulación ya existe
            Paso2->>BD: Reemplaza sus detalles con la lista actual
        end
        Paso2->>Resumen: Envía simulación, cuenta, saldo, lista y egresos
    end
    Resumen->>Resumen: Calcula meses enteros y excedente
    Resumen-->>Usuario: Muestra detalle y resultados
    alt Grabar simulación
        Usuario->>Resumen: Pulsa Grabar
        Resumen->>BD: Inserta cabecera y reemplaza detalles
        BD-->>Resumen: Informa éxito o error
    else Imprimir
        Usuario->>Resumen: Pulsa Imprimir
        Resumen->>Resumen: Genera el PDF en Descargas
        Resumen->>Visor: Abre el PDF con permiso de lectura
    else Volver a ítems
        Usuario->>Resumen: Pulsa Ítems
        Resumen-->>Paso2: Cierra resumen y conserva la pantalla anterior
    else Iniciar otra simulación
        Usuario->>Resumen: Pulsa Simulación
        Resumen->>Paso1: Abre la selección de simulación y cuenta
    else Ir al menú o Inicio
        Usuario->>Resumen: Pulsa Menú o Home
        Resumen-->>Usuario: Navega al menú de simulación o al principal
    end
```

El total de egresos es la suma de los montos agregados. Si el total es mayor que cero, los meses son la división entera del saldo por los egresos y el excedente es el resto. Si el total de egresos es cero, el resumen muestra duración indefinida y conserva el saldo como excedente.

## 6. Síntesis interactiva MVC

```mermaid
flowchart TD
    Menu[MenuSimActivity] -->|Síntesis MVC| Activity[SimulacionActivity]
    Activity --> Crear[Construye SimulacionController y SQLiteSimulacionRepository]
    Crear --> Entrada[SimulacionInputFragment carga simulaciones, cuentas e ítems]
    Crear --> Salida[SimulacionOutputFragment presenta resultados]
    Entrada --> Seleccion{Selecciona simulación y cuenta}
    Seleccion -->|Simulación existente| Detalles[Carga cuenta y detalles guardados]
    Seleccion -->|Nuevos datos| Edicion[Agrega o quita ítems y modifica montos]
    Detalles --> Edicion
    Edicion --> Listener[OnSimulacionDatosListener notifica cambios]
    Listener --> Activity
    Activity --> Calcula[Solicita actualización de resultados]
    Calcula --> Salida
    Entrada -->|Crear cuenta o ítem| CRUD[Controller / Repository / SQLite]
    Entrada -->|Eliminar cuenta o ítem| Uso{¿Está asociado?}
    Uso -->|Sí| Bloqueo[Deniega eliminación]
    Uso -->|No| Confirmacion[Confirma y elimina]
    Salida --> Accion{Acción}
    Accion -->|Guardar| Validar[Controller valida selección, montos y detalles]
    Validar -->|Inválido| Rechazo[Muestra rechazo o error]
    Validar -->|Válido| Existe{¿Simulación con detalles existentes?}
    Existe -->|Sí| SobreEscribe{¿Confirma sobrescritura?}
    SobreEscribe -->|No| Nueva[Ofrece crear otra simulación]
    SobreEscribe -->|Sí| Persistir[Repository guarda cabecera y detalles en transacción]
    Existe -->|No| Persistir
    Persistir --> Exito[Muestra confirmación]
    Accion -->|Eliminar simulación| Eliminar[Confirma y elimina simulación]
    Accion -->|Limpiar| Limpiar[Limpia entradas y resultados]
    Accion -->|Imprimir| PDF[Genera PDF y solicita visor externo]
    Activity -->|Home| Principal[MainActivity]
```

En este recorrido los cambios en el saldo o en la lista de ítems notifican el total al fragment de salida, que actualiza egresos, meses y excedente. El guardado verifica el usuario, los nombres, los montos, la cuenta, el desbordamiento numérico y la confirmación si se reemplazan detalles existentes.

## 7. Consulta, exportación e impresión

```mermaid
flowchart TD
    Inicio[Abre ConsultaSimulacionesActivity] --> Carga[Carga simulaciones del usuario activo]
    Carga --> Hay{¿Hay simulaciones guardadas?}
    Hay -->|No| SinDatos[Muestra estado sin datos]
    Hay -->|Sí| Seleccion[Selecciona una simulación]
    Seleccion --> Presenta[Consulta cuenta, fecha, importes y detalles]
    Presenta --> Accion{Acción}
    Accion -->|JSON| JsonValido{¿Selección válida?}
    JsonValido -->|No| Seleccion
    JsonValido -->|Sí| Json[Solicita ruta y genera archivo JSON]
    Accion -->|CSV| CsvValido{¿Selección válida?}
    CsvValido -->|No| Seleccion
    CsvValido -->|Sí| Csv[Solicita ruta y genera archivo CSV]
    Accion -->|PDF| PdfValido{¿Selección válida?}
    PdfValido -->|No| Seleccion
    PdfValido -->|Sí| PDF[Genera PDF y solicita abrir visor externo]
    Accion -->|Enviar| EnvioValido{¿Selección válida?}
    EnvioValido -->|No| Seleccion
    EnvioValido -->|Sí| Aviso[Muestra aviso; no hay envío externo implementado]
    Accion -->|Home| Principal[MainActivity]
    SinDatos -->|Home| Principal
```

JSON y CSV permiten editar la ruta propuesta antes de escribir el archivo. La acción **Enviar** solo muestra un mensaje informativo en la implementación actual; no inicia un envío por red ni un selector de aplicaciones.

## 8. Respaldo, restauración y vaciado

```mermaid
flowchart TD
    Inicio[Abre RespaldoActivity] --> Accion{Operación}
    Accion -->|Respaldar| Tipo{Destino / modalidad}
    Tipo -->|Descargas, normal| Copia[Copiar simulafin.db a simulafin_backup.db]
    Tipo -->|Ubicación personalizada| Create[SAF CreateDocument y copia de la base actual]
    Tipo -->|Respaldo limpio| Auth1[Solicita contraseña de administrador]
    Auth1 -->|Incorrecta o cancelar| Accion
    Auth1 -->|Correcta| VaciarAntes[Vacia la base de datos activa]
    VaciarAntes --> CopiaVacia[Copia la base vaciada a Descargas]
    Accion -->|Restaurar / cargar| Origen{Origen del archivo}
    Origen -->|Descargas| Existe{¿Existe simulafin_backup.db?}
    Existe -->|Sí| Restaurar[Reemplaza simulafin.db con el archivo]
    Existe -->|No| Error[Informa que no se encontró el respaldo]
    Origen -->|Archivo elegido| Open[SAF OpenDocument y copia URI a simulafin.db]
    Origen -->|Casos de prueba| Test[Genera y carga baseDatosTest1.db]
    Accion -->|Vaciar base| Auth2[Solicita contraseña de administrador]
    Auth2 -->|Incorrecta o cancelar| Accion
    Auth2 -->|Correcta| Reset[Recrea tablas y conserva usuario activo como administrador]
    Copia --> Accion
    Create --> Accion
    CopiaVacia --> Accion
    Restaurar --> Accion
    Open --> Accion
    Test --> Accion
    Reset --> Accion
    Accion -->|Home| Principal[MainActivity]
```

**Advertencia:** la opción **Respaldo limpio** verifica la contraseña y luego vacía la base activa antes de crear el archivo. El archivo resultante no contiene los datos previos; conserva únicamente el usuario activo como administrador. La restauración reemplaza el archivo SQLite actual por el archivo elegido.

## 9. Modelo de datos SQLite

```mermaid
erDiagram
    Usuarios ||--o{ Cuentas : posee
    Usuarios ||--o{ Items : posee
    Usuarios ||--o{ Simulaciones : crea
    Cuentas ||--o{ Simulaciones : financia
    Simulaciones ||--o{ DetallesSimulaciones : contiene
    Items o|--o{ DetallesSimulaciones : referencia

    Usuarios {
        int idUsuario PK
        string nombreUsuario UK
        string claveUsuario
        string saltUsuario
        string fechaHoraUsuario
        int esAdmin
        string preferenciaTema
    }
    Cuentas {
        int idCuenta PK
        int idUsuario FK
        string nombreCuenta
        int totalCuenta
        string fechaHoraCuenta
    }
    Items {
        int idItem PK
        int idUsuario FK
        string nombreItem
        int valorItem
    }
    Simulaciones {
        int idSim PK
        int idCuenta FK
        int idUsuario FK
        string nombreSim
        string fechaHoraSim
        int totalDisponible
        int totalEgresos
        int meses
        int excedente
    }
    DetallesSimulaciones {
        int idDetalle PK
        int idSim FK
        int idItem FK "nullable"
        string nombreItem
        int valorItem
    }
```

`claveUsuario` almacena la clave procesada, acompañada por `saltUsuario`; los detalles conservan el nombre y el monto del ítem para representar la simulación guardada. La referencia `idItem` en el detalle admite valor nulo.

## 10. Pantallas y responsabilidades

| Pantalla / componente | Responsabilidad |
|---|---|
| `LoginActivity` | Inicializa SQLite, valida campos y credenciales, y conduce al registro o al menú principal. |
| `registroUsuarioNuevo` | Crea un usuario, protege la clave con hash y salt, y activa la sesión local. |
| `MainActivity` | Navega a simulaciones, cuentas, ítems, registro de usuario y respaldo. |
| `RegistroActivity` | Actualiza las credenciales/datos del usuario activo. |
| `CuentasActivity` | Consulta y mantiene cuentas del usuario. |
| `ItemsActivity` | Consulta y mantiene el catálogo de egresos mensuales. |
| `MenuSimActivity` | Enruta a paso a paso, síntesis MVC y consulta de simulaciones. |
| `InputSimCuentaActivity` | Selecciona/crea simulación y cuenta y define el saldo de entrada. |
| `InputSimItemsActivity` | Construye la lista de gastos mensuales y su total. |
| `OutSimResumenActivity` | Calcula y muestra el resumen, guarda la simulación o genera PDF. |
| `SimulacionActivity` y sus fragments | Coordina la entrada y salida interactiva mediante Controller/Repository. |
| `ConsultaSimulacionesActivity` | Consulta simulaciones guardadas y exporta JSON, CSV o PDF. |
| `RespaldoActivity` | Respalda, restaura, carga datos de prueba o vacía la base con autorización. |
