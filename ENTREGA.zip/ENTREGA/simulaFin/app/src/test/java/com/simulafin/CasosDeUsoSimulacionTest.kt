package com.simulafin

import com.simulafin.clases.Cuenta
import com.simulafin.clases.DetalleSimulacion
import com.simulafin.clases.Item
import com.simulafin.clases.Simulacion
import com.simulafin.controller.GuardarSimulacionCommand
import com.simulafin.controller.GuardarSimulacionResultado
import com.simulafin.controller.SimulacionController
import com.simulafin.data.SimulacionRepository
import com.simulafin.domain.DetalleSimulacionEntrada
import com.simulafin.domain.ResultadoCalculoSimulacion
import com.simulafin.domain.SimulacionCalculo
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/**
 * Pruebas unitarias completas que simulan la interacción de dos perfiles de usuario:
 * 1. Emprendedor (Startup Panadería Artesanal / Food Truck)
 * 2. Gestor de Proyecto / Inversionista (Desarrollo Plataforma Software con Monto Fijo)
 */
class CasosDeUsoSimulacionTest {

    private lateinit var repository: InMemorySimulacionRepository
    private lateinit var controller: SimulacionController

    @Before
    fun setUp() {
        repository = InMemorySimulacionRepository()
        controller = SimulacionController(repository)
    }

    // -------------------------------------------------------------------------
    // CASO DE USO 1: EMPRENDEDOR (Panadería Artesanal)
    // -------------------------------------------------------------------------
    @Test
    fun testCasoEmprendedor_EscenarioInicialYOptimizado() {
        val idUsuario = 101
        val nombreUsuario = "emprendedor_juan"
        repository.usuarios[nombreUsuario] = idUsuario
        // 1. Crear Cuenta de Capital de Trabajo
        val nombreCuenta = "Banco Estado - Capital Semilla"
        val montoDisponible = 6_000_000
        controller.insertarCuenta(idUsuario, nombreCuenta, montoDisponible)
        val cuentas = controller.obtenerCuentas(idUsuario)
        assertEquals(1, cuentas.size)
        assertEquals(nombreCuenta, cuentas[0].nombreCuenta)
        assertEquals(montoDisponible, cuentas[0].totalCuenta)
        // 2. Escenario A: Gastos Iniciales Elevados
        val detallesEscenarioA = listOf(
            DetalleSimulacionEntrada("Arriendo Local Comercial", 1_200_000),
            DetalleSimulacionEntrada("Materias Primas e Insumos", 800_000),
            DetalleSimulacionEntrada("Sueldo Personal Operativo", 1_500_000),
            DetalleSimulacionEntrada("Servicios Básicos (Luz, Agua, Gas)", 250_000),
            DetalleSimulacionEntrada("Marketing Digital & Publicidad", 250_000)
        )
        val commandA = GuardarSimulacionCommand(
            idUsuario = idUsuario,
            nombreSimulacion = "Panadería - Escenario Inicial",
            nombreCuenta = nombreCuenta,
            totalDisponible = montoDisponible.toLong(),
            detalles = detallesEscenarioA
        )
        val resultadoA = controller.guardar(commandA)
        assertTrue(resultadoA is GuardarSimulacionResultado.Guardada)
        // Verificar Cálculos del Escenario A
        val calculoA = SimulacionCalculo.calcular(montoDisponible.toLong(), detallesEscenarioA)
        assertEquals(4_000_000L, calculoA.totalEgresos)
        assertEquals(1L, calculoA.meses) // 6.000.000 / 4.000.000 = 1 mes de cobertura completa
        assertEquals(2_000_000L, calculoA.excedente) // 6.000.000 - 4.000.000 = 2.000.000
        val simA = Simulacion(
            nombreSim = "Panadería - Escenario Inicial",
            totalDisponible = montoDisponible,
            totalEgresos = calculoA.totalEgresos.toInt(),
            meses = calculoA.meses.toInt(),
            excedente = calculoA.excedente.toInt()
        )
        assertTrue("La simulación debe ser viable ya que el disponible cubre los egresos", simA.esViable())
        // 3. Escenario B: Optimización de Gastos para Extender la Duración (Runway)
        val detallesEscenarioB = listOf(
            DetalleSimulacionEntrada("Arriendo Subarrendado", 700_000),
            DetalleSimulacionEntrada("Insumos Optimizados Por Mayor", 500_000),
            DetalleSimulacionEntrada("Sueldo Operativo Ajustado", 1_000_000),
            DetalleSimulacionEntrada("Servicios Básicos Eficientes", 150_000)
        )
        val commandB = GuardarSimulacionCommand(
            idUsuario = idUsuario,
            nombreSimulacion = "Panadería - Escenario Optimizado",
            nombreCuenta = nombreCuenta,
            totalDisponible = montoDisponible.toLong(),
            detalles = detallesEscenarioB
        )
        val resultadoB = controller.guardar(commandB)
        assertTrue(resultadoB is GuardarSimulacionResultado.Guardada)
        val calculoB = SimulacionCalculo.calcular(montoDisponible.toLong(), detallesEscenarioB)
        assertEquals(2_350_000L, calculoB.totalEgresos)
        assertEquals(2L, calculoB.meses) // 6.000.000 / 2.350.000 = 2 meses enteros
        assertEquals(1_300_000L, calculoB.excedente) // 6.000.000 - (2 * 2.350.000) = 1.300.000
        // Comparación de Duración: El escenario optimizado duplica la supervivencia financiera (runway) de 1 a 2 meses
        assertTrue("El escenario B extiende la duración proyectada", calculoB.meses > calculoA.meses)
    }
    // -------------------------------------------------------------------------
    // CASO DE USO 2: GESTOR DE PROYECTO / INVERSIONISTA (Monto Fijo $15M)
    // -------------------------------------------------------------------------
    @Test
    fun testCasoProyectoMontoFijo_PresupuestoSuficienteEInsuficiente() {
        val idUsuario = 202
        val nombreUsuario = "gestor_proyecto_maria"
        repository.usuarios[nombreUsuario] = idUsuario
        // 1. Crear Cuenta del Proyecto con Fondo Asignado
        val nombreCuenta = "Fondo Inversión Proyecto Tech"
        val montoDisponible = 15_000_000
        controller.insertarCuenta(idUsuario, nombreCuenta, montoDisponible)
        // 2. Escenario A: Presupuesto Planificado (Suficiente)
        val detallesPlanificados = listOf(
            DetalleSimulacionEntrada("Honorarios Equipo Desarrollo", 3_500_000),
            DetalleSimulacionEntrada("Diseñador UX/UI Senior", 1_500_000),
            DetalleSimulacionEntrada("Infraestructura Cloud AWS & Firebase", 500_000),
            DetalleSimulacionEntrada("Licencias Software & Herramientas", 300_000),
            DetalleSimulacionEntrada("Reserva de Contingencia", 700_000)
        )
        val commandProyectoA = GuardarSimulacionCommand(
            idUsuario = idUsuario,
            nombreSimulacion = "Proyecto Tech - Plan Normal",
            nombreCuenta = nombreCuenta,
            totalDisponible = montoDisponible.toLong(),
            detalles = detallesPlanificados
        )
        val resA = controller.guardar(commandProyectoA)
        assertTrue(resA is GuardarSimulacionResultado.Guardada)
        val calculoPlanificado = SimulacionCalculo.calcular(montoDisponible.toLong(), detallesPlanificados)
        assertEquals(6_500_000L, calculoPlanificado.totalEgresos)
        assertEquals(2L, calculoPlanificado.meses) // 15.000.000 / 6.500.000 = 2 meses completos
        assertEquals(2_000_000L, calculoPlanificado.excedente) // 15.000.000 - (2 * 6.500.000) = 2.000.000
        val simPlanificada = Simulacion(
            nombreSim = "Proyecto Tech - Plan Normal",
            totalDisponible = montoDisponible,
            totalEgresos = calculoPlanificado.totalEgresos.toInt(),
            meses = calculoPlanificado.meses.toInt(),
            excedente = calculoPlanificado.excedente.toInt()
        )
        assertTrue(simPlanificada.esViable())
        // 3. Escenario B: Sobrepaso de Presupuesto (Saldo Insuficiente)
        val detallesExcesivos = detallesPlanificados + listOf(
            DetalleSimulacionEntrada("Campaña Marketing Masivo Lanzamiento", 10_000_000)
        )
        val calculoExcesivo = SimulacionCalculo.calcular(montoDisponible.toLong(), detallesExcesivos)
        assertEquals(16_500_000L, calculoExcesivo.totalEgresos)
        assertEquals(0L, calculoExcesivo.meses) // No alcanza ni para 1 mes completo
        assertEquals(15_000_000L, calculoExcesivo.excedente) // Queda intacto el disponible sin consumir ciclo completo
        val simExcesiva = Simulacion(
            nombreSim = "Proyecto Tech - Plan Ampliado",
            totalDisponible = montoDisponible,
            totalEgresos = calculoExcesivo.totalEgresos.toInt(),
            meses = calculoExcesivo.meses.toInt(),
            excedente = calculoExcesivo.excedente.toInt()
        )
        assertFalse("Debe marcarse como NO viable si egresos > disponible", simExcesiva.esViable())
        assertTrue("Detecta condición de saldo insuficiente (gastos > cuenta)", calculoExcesivo.totalEgresos > montoDisponible)
    }
    // -------------------------------------------------------------------------
    // PRUEBAS DE REGLAS DE NEGOCIO Y VALIDACIONES SISTÉMICAS
    // -------------------------------------------------------------------------
    @Test
    fun testValidaciones_RechazoYConfirmacionSobrescritura() {
        val idUsuario = 303
        repository.usuarios["test_user"] = idUsuario
        controller.insertarCuenta(idUsuario, "Cuenta Test", 1_000_000)

        // Intento de guardar sin ítems
        val cmdSinItems = GuardarSimulacionCommand(
            idUsuario = idUsuario,
            nombreSimulacion = "Simulación Vacía",
            nombreCuenta = "Cuenta Test",
            totalDisponible = 1_000_000,
            detalles = emptyList()
        )
        val resSinItems = controller.guardar(cmdSinItems)
        assertTrue(resSinItems is GuardarSimulacionResultado.Rechazada)
        // Intento de guardar sin cuenta válida
        val cmdSinCuenta = GuardarSimulacionCommand(
            idUsuario = idUsuario,
            nombreSimulacion = "Simulación Test",
            nombreCuenta = "",
            totalDisponible = 1_000_000,
            detalles = listOf(DetalleSimulacionEntrada("Gasto", 100_000))
        )
        val resSinCuenta = controller.guardar(cmdSinCuenta)
        assertTrue(resSinCuenta is GuardarSimulacionResultado.Rechazada)
        // Primera guardada exitosa
        val cmdOk = GuardarSimulacionCommand(
            idUsuario = idUsuario,
            nombreSimulacion = "Simulación Repetida",
            nombreCuenta = "Cuenta Test",
            totalDisponible = 1_000_000,
            detalles = listOf(DetalleSimulacionEntrada("Servicio", 200_000))
        )
        val resInitial = controller.guardar(cmdOk)
        assertTrue(resInitial is GuardarSimulacionResultado.Guardada)
        // Segunda guardada con el mismo nombre exige confirmación de sobrescritura
        val resSobrescribir = controller.guardar(cmdOk, sobrescribirConfirmado = false)
        assertEquals(GuardarSimulacionResultado.RequiereConfirmacionSobrescritura, resSobrescribir)
        // Con sobrescritura confirmada se guarda exitosamente
        val resSobrescribirConfirmado = controller.guardar(cmdOk, sobrescribirConfirmado = true)
        assertTrue(resSobrescribirConfirmado is GuardarSimulacionResultado.Guardada)
    }
}
//Repositorio en memoria para ejecutar pruebas rápidas del controlador de simulaciones.
class InMemorySimulacionRepository : SimulacionRepository {
    val usuarios = mutableMapOf<String, Int>()
    val cuentas = mutableListOf<Cuenta>()
    val items = mutableListOf<Item>()
    val simulaciones = mutableListOf<Simulacion>()
    val detalles = mutableListOf<DetalleSimulacion>()
    private var autoIdCuenta = 1
    private var autoIdItem = 1
    private var autoIdSim = 1
    private var autoIdDetalle = 1
    override fun obtenerIdUsuarioActivo(nombreUsuario: String): Int = usuarios[nombreUsuario] ?: 1
    override fun obtenerNombreUsuarioActivo(nombreUsuario: String): String = nombreUsuario
    override fun obtenerSimulaciones(idUsuario: Int): List<Simulacion> =
        simulaciones.filter { it.idUsuario == idUsuario }
    override fun obtenerCuentas(idUsuario: Int): List<Cuenta> =
        cuentas.filter { it.idUsuario == idUsuario }
    override fun obtenerItems(idUsuario: Int): List<Item> =
        items.filter { it.idUsuario == idUsuario }
    override fun obtenerDetallesSimulacion(idSimulacion: Int): List<DetalleSimulacion> =
        detalles.filter { it.idSim == idSimulacion }
    override fun eliminarSimulacion(idSimulacion: Int): Boolean {
        detalles.removeAll { it.idSim == idSimulacion }
        return simulaciones.removeAll { it.idSim == idSimulacion }
    }
    override fun actualizarCuenta(idCuenta: Int, nombre: String, total: Int): Boolean {
        val index = cuentas.indexOfFirst { it.idCuenta == idCuenta }
        if (index >= 0) {
            cuentas[index] = cuentas[index].copy(nombreCuenta = nombre, totalCuenta = total)
            return true
        }
        return false
    }
    override fun cuentaOcupada(idCuenta: Int): String {
        return simulaciones.find { it.idCuenta == idCuenta }?.nombreSim ?: ""
    }
    override fun eliminarCuenta(idCuenta: Int): Boolean =
        cuentas.removeAll { it.idCuenta == idCuenta }
    override fun itemOcupado(idItem: Int): String = ""
    override fun eliminarItem(idItem: Int): Boolean =
        items.removeAll { it.idItem == idItem }
    override fun insertarSimulacion(
        idCuenta: Int,
        idUsuario: Int,
        nombre: String,
        totalDisponible: Int,
        totalEgresos: Int,
        meses: Int,
        excedente: Int
    ): Long {
        val newSim = Simulacion(
            idSim = autoIdSim++,
            idCuenta = idCuenta,
            idUsuario = idUsuario,
            nombreSim = nombre,
            fechaHoraSim = "2026-10-26",
            totalDisponible = totalDisponible,
            totalEgresos = totalEgresos,
            meses = meses,
            excedente = excedente
        )
        simulaciones.add(newSim)
        return newSim.idSim.toLong()
    }
    override fun insertarCuenta(idUsuario: Int, nombre: String, total: Int): Boolean {
        cuentas.add(
            Cuenta(
                idCuenta = autoIdCuenta++,
                idUsuario = idUsuario,
                nombreCuenta = nombre,
                totalCuenta = total,
                fechaHoraCuenta = "2026-10-26"
            )
        )
        return true
    }
    override fun insertarItem(idUsuario: Int, nombre: String, valor: Int): Boolean {
        items.add(
            Item(
                idItem = autoIdItem++,
                idUsuario = idUsuario,
                nombreItem = nombre,
                valorItem = valor
            )
        )
        return true
    }
    override fun obtenerIdCuenta(idUsuario: Int, nombreCuenta: String): Int? {
        return cuentas.find { it.idUsuario == idUsuario && it.nombreCuenta == nombreCuenta }?.idCuenta
    }
    override fun obtenerSimulacionId(idUsuario: Int, nombreSimulacion: String): Int? {
        return simulaciones.find { it.idUsuario == idUsuario && it.nombreSim == nombreSimulacion }?.idSim
    }
    override fun tieneDetalles(idSimulacion: Int): Boolean {
        return detalles.any { it.idSim == idSimulacion }
    }
    override fun guardarCompleta(
        idUsuario: Int,
        idCuenta: Int,
        nombreSimulacion: String,
        totalDisponible: Int,
        resultado: ResultadoCalculoSimulacion,
        detallesInput: List<DetalleSimulacionEntrada>
    ): Int {
        val simExistenteId = obtenerSimulacionId(idUsuario, nombreSimulacion)
        val idSim: Int
        if (simExistenteId != null) {
            idSim = simExistenteId
            detalles.removeAll { it.idSim == idSim }
            val index = simulaciones.indexOfFirst { it.idSim == idSim }
            if (index >= 0) {
                simulaciones[index] = simulaciones[index].copy(
                    idCuenta = idCuenta,
                    totalDisponible = totalDisponible,
                    totalEgresos = resultado.totalEgresos.toInt(),
                    meses = resultado.meses.toInt(),
                    excedente = resultado.excedente.toInt()
                )
            }
        } else {
            idSim = autoIdSim++
            simulaciones.add(
                Simulacion(
                    idSim = idSim,
                    idCuenta = idCuenta,
                    idUsuario = idUsuario,
                    nombreSim = nombreSimulacion,
                    fechaHoraSim = "2026-10-26",
                    totalDisponible = totalDisponible,
                    totalEgresos = resultado.totalEgresos.toInt(),
                    meses = resultado.meses.toInt(),
                    excedente = resultado.excedente.toInt()
                )
            )
        }
        for (det in detallesInput) {
            detalles.add(
                DetalleSimulacion(
                    idDetalle = autoIdDetalle++,
                    idSim = idSim,
                    nombreItem = det.nombreItem,
                    valorItem = det.valorItem
                )
            )
        }
        return idSim
    }
}
