package com.simulafin

import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.Simulacion
import com.simulafin.clases.presentaPie
import com.simulafin.clases.toFormatoChile
import java.io.File
import java.io.FileOutputStream

class AnalisisSimActivity : AppCompatActivity() {

    private lateinit var dbHelper: BaseDatosHelper

    // ComboBox (Spinners) para las 3 simulaciones independientes
    private lateinit var spnSim1: Spinner
    private lateinit var spnSim2: Spinner
    private lateinit var spnSim3: Spinner

    // Campos no editables para Panel 1
    private lateinit var txtCuenta1: TextView
    private lateinit var txtValorCta1: TextView
    private lateinit var txvDetalles1: TextView
    private lateinit var txtTotalItems1: TextView
    private lateinit var txtTotalMeses1: TextView
    private lateinit var txtExcedente1: TextView

    // Campos no editables para Panel 2
    private lateinit var txtCuenta2: TextView
    private lateinit var txtValorCta2: TextView
    private lateinit var txvDetalles2: TextView
    private lateinit var txtTotalItems2: TextView
    private lateinit var txtTotalMeses2: TextView
    private lateinit var txtExcedente2: TextView

    // Campos no editables para Panel 3
    private lateinit var txtCuenta3: TextView
    private lateinit var txtValorCta3: TextView
    private lateinit var txvDetalles3: TextView
    private lateinit var txtTotalItems3: TextView
    private lateinit var txtTotalMeses3: TextView
    private lateinit var txtExcedente3: TextView

    private val listaNombresSimulaciones = mutableListOf<String>()
    private val listaSimulacionesBD = mutableListOf<Simulacion>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analisis_sim)

        findViewById<ImageView>(R.id.btnVolverAnterior).setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        dbHelper = BaseDatosHelper(this)

        presentaPie("Módulo de Análisis Comparativo: Selección independiente de 3 simulaciones mediante ComboBox para evaluación en paralelo.")

        val uActivo = dbHelper.obtenerNombreUsuarioActivo(SesionUsuario.usuarioActivo)
        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario Activo: $uActivo"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        // Vincular Spinners
        spnSim1 = findViewById(R.id.spnSim1)
        spnSim2 = findViewById(R.id.spnSim2)
        spnSim3 = findViewById(R.id.spnSim3)

        // Vincular UI Panel 1
        txtCuenta1 = findViewById(R.id.txtCuenta1)
        txtValorCta1 = findViewById(R.id.txtValorCta1)
        txvDetalles1 = findViewById(R.id.txvDetalles1)
        txtTotalItems1 = findViewById(R.id.txtTotalItems1)
        txtTotalMeses1 = findViewById(R.id.txtTotalMeses1)
        txtExcedente1 = findViewById(R.id.txtExcedente1)

        // Vincular UI Panel 2
        txtCuenta2 = findViewById(R.id.txtCuenta2)
        txtValorCta2 = findViewById(R.id.txtValorCta2)
        txvDetalles2 = findViewById(R.id.txvDetalles2)
        txtTotalItems2 = findViewById(R.id.txtTotalItems2)
        txtTotalMeses2 = findViewById(R.id.txtTotalMeses2)
        txtExcedente2 = findViewById(R.id.txtExcedente2)

        // Vincular UI Panel 3
        txtCuenta3 = findViewById(R.id.txtCuenta3)
        txtValorCta3 = findViewById(R.id.txtValorCta3)
        txvDetalles3 = findViewById(R.id.txvDetalles3)
        txtTotalItems3 = findViewById(R.id.txtTotalItems3)
        txtTotalMeses3 = findViewById(R.id.txtTotalMeses3)
        txtExcedente3 = findViewById(R.id.txtExcedente3)

        val btnImprimirAnalisis = findViewById<Button>(R.id.btnImprimirAnalisis)
        val btnExportarCsvAnalisis = findViewById<Button>(R.id.btnExportarCsvAnalisis)

        cargarDatosSimulaciones(uActivo)

        // Listeners independientes para cada ComboBox
        spnSim1.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                actualizarPanel(spnSim1, txtCuenta1, txtValorCta1, txvDetalles1, txtTotalItems1, txtTotalMeses1, txtExcedente1)
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        spnSim2.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                actualizarPanel(spnSim2, txtCuenta2, txtValorCta2, txvDetalles2, txtTotalItems2, txtTotalMeses2, txtExcedente2)
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        spnSim3.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                actualizarPanel(spnSim3, txtCuenta3, txtValorCta3, txvDetalles3, txtTotalItems3, txtTotalMeses3, txtExcedente3)
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        btnImprimirAnalisis?.setOnClickListener {
            val pdfFile = generarPdfAnalisisComparativo()
            if (pdfFile != null && pdfFile.exists()) {
                try {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", pdfFile)
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/pdf")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(intent)
                    Toast.makeText(this, "Abriendo reporte comparativo PDF...", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "PDF guardado en Descargas:\n${pdfFile.absolutePath}", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Error al generar el PDF comparativo", Toast.LENGTH_SHORT).show()
            }
        }

        btnExportarCsvAnalisis?.setOnClickListener {
            val exito = exportarCsvAnalisisComparativo()
            if (exito) {
                Toast.makeText(this, "Análisis exportado a CSV (Peso Chileno CLP) en Descargas con éxito", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Error al exportar el análisis a CSV", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun cargarDatosSimulaciones(nombreUsuario: String) {
        val idUsuario = dbHelper.obtenerIdUsuarioActivo(nombreUsuario)
        listaSimulacionesBD.clear()
        listaNombresSimulaciones.clear()

        val simulaciones = dbHelper.obtenerSimulaciones(idUsuario)
        if (simulaciones.isEmpty()) {
            listaNombresSimulaciones.add("No hay simulaciones")
        } else {
            listaNombresSimulaciones.add("Seleccione simulación...")
            listaSimulacionesBD.addAll(simulaciones)
            for (sim in simulaciones) {
                if (!listaNombresSimulaciones.contains(sim.nombreSim)) {
                    listaNombresSimulaciones.add(sim.nombreSim)
                }
            }
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listaNombresSimulaciones)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        spnSim1.adapter = adapter
        spnSim2.adapter = adapter
        spnSim3.adapter = adapter

        // Preseleccionar por defecto si hay elementos disponibles y actualizar cada panel
        if (listaSimulacionesBD.size >= 1) {
            spnSim1.setSelection(1)
            actualizarPanel(spnSim1, txtCuenta1, txtValorCta1, txvDetalles1, txtTotalItems1, txtTotalMeses1, txtExcedente1)
        }
        if (listaSimulacionesBD.size >= 2) {
            spnSim2.setSelection(2)
            actualizarPanel(spnSim2, txtCuenta2, txtValorCta2, txvDetalles2, txtTotalItems2, txtTotalMeses2, txtExcedente2)
        } else if (listaSimulacionesBD.size == 1) {
            spnSim2.setSelection(1)
            actualizarPanel(spnSim2, txtCuenta2, txtValorCta2, txvDetalles2, txtTotalItems2, txtTotalMeses2, txtExcedente2)
        }
        if (listaSimulacionesBD.size >= 3) {
            spnSim3.setSelection(3)
            actualizarPanel(spnSim3, txtCuenta3, txtValorCta3, txvDetalles3, txtTotalItems3, txtTotalMeses3, txtExcedente3)
        } else if (listaSimulacionesBD.size > 0) {
            spnSim3.setSelection(1)
            actualizarPanel(spnSim3, txtCuenta3, txtValorCta3, txvDetalles3, txtTotalItems3, txtTotalMeses3, txtExcedente3)
        }
    }

    private fun actualizarPanel(
        spinner: Spinner,
        tvCuenta: TextView,
        tvValorCta: TextView,
        tvDetalles: TextView,
        tvTotalItems: TextView,
        tvTotalMeses: TextView,
        tvExcedente: TextView
    ) {
        val pos = spinner.selectedItemPosition
        if (pos <= 0 || listaSimulacionesBD.isEmpty()) {
            tvCuenta.text = "---"
            tvValorCta.text = 0.toFormatoChile()
            tvDetalles.text = "• (Sin seleccionar)"
            tvTotalItems.text = 0.toFormatoChile()
            tvTotalMeses.text = "0"
            tvExcedente.text = 0.toFormatoChile()
            return
        }

        val nombreSeleccionado = spinner.selectedItem?.toString() ?: ""
        val simObj = listaSimulacionesBD.find { it.nombreSim == nombreSeleccionado }

        if (simObj != null) {
            val nombreCuenta = dbHelper.obtenerNombreCuentaPorId(simObj.idCuenta)
            tvCuenta.text = if (nombreCuenta.isNotEmpty()) nombreCuenta else "Cta #${simObj.idCuenta}"
            tvValorCta.text = simObj.totalDisponible.toFormatoChile()

            val detalles = dbHelper.obtenerDetallesSimulacion(simObj.idSim)
            val sbDetalles = StringBuilder()
            if (detalles.isEmpty()) {
                sbDetalles.append("• Sin ítems de egreso")
            } else {
                for (det in detalles) {
                    sbDetalles.append("• ${det.nombreItem} - ${det.valorItem.toFormatoChile()}\n")
                }
            }
            tvDetalles.text = sbDetalles.toString().trim()

            tvTotalItems.text = simObj.totalEgresos.toFormatoChile()
            tvTotalMeses.text = simObj.meses.toString()
            tvExcedente.text = simObj.excedente.toFormatoChile()
        } else {
            tvCuenta.text = "---"
            tvValorCta.text = 0.toFormatoChile()
            tvDetalles.text = "• (Sin datos)"
            tvTotalItems.text = 0.toFormatoChile()
            tvTotalMeses.text = "0"
            tvExcedente.text = 0.toFormatoChile()
        }
    }

    private fun exportarCsvAnalisisComparativo(): Boolean {
        return try {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val archivoCsv = File(downloadsDir, "analisis_comparativo_simulaciones.csv")
            archivoCsv.parentFile?.mkdirs()

            val sb = StringBuilder()
            sb.append("=== ANALISIS COMPARATIVO DE SIMULACIONES - MONEDA CHILE (CLP) ===\n")
            sb.append("Panel,Nombre Simulacion,Cuenta Asociada,Total Disponible (CLP),Total Egresos (CLP),Meses,Excedente (CLP),Detalles Items\n")

            val sim1 = obtenerSimulacionDesdeSpinner(spnSim1)
            val sim2 = obtenerSimulacionDesdeSpinner(spnSim2)
            val sim3 = obtenerSimulacionDesdeSpinner(spnSim3)

            listOfNotNull(
                Triple("Panel 1", sim1, txvDetalles1.text.toString().replace("\n", " | ")),
                Triple("Panel 2", sim2, txvDetalles2.text.toString().replace("\n", " | ")),
                Triple("Panel 3", sim3, txvDetalles3.text.toString().replace("\n", " | "))
            ).forEach { triple ->
                val panel = triple.first
                val sim = triple.second
                val detTexto = triple.third
                if (sim.idSim > 0) {
                    val ctaNombre = dbHelper.obtenerNombreCuentaPorId(sim.idCuenta)
                    val dispCLP = sim.totalDisponible.toFormatoChile()
                    val egrCLP = sim.totalEgresos.toFormatoChile()
                    val excCLP = sim.excedente.toFormatoChile()
                    sb.append("$panel,\"${sim.nombreSim}\",\"$ctaNombre\",\"$dispCLP\",\"$egrCLP\",${sim.meses},\"$excCLP\",\"$detTexto\"\n")
                }
            }

            archivoCsv.writeText(sb.toString())
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun obtenerSimulacionDesdeSpinner(spinner: Spinner): Simulacion {
        val pos = spinner.selectedItemPosition
        val nombre = spinner.selectedItem?.toString() ?: ""
        return listaSimulacionesBD.find { it.nombreSim == nombre }
            ?: listaSimulacionesBD.getOrNull(pos - 1)
            ?: Simulacion()
    }

    private fun generarPdfAnalisisComparativo(): File? {
        return try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            val paint = Paint().apply {
                color = Color.BLACK
                textSize = 14f
            }

            var y = 50f
            val leftMargin = 50f

            paint.textSize = 20f
            paint.isFakeBoldText = true
            canvas.drawText("Reporte de Análisis Comparativo - SimulaFin (CLP)", leftMargin, y, paint)
            y += 35f

            paint.textSize = 12f
            paint.isFakeBoldText = false
            val uActivo = dbHelper.obtenerNombreUsuarioActivo(SesionUsuario.usuarioActivo)
            canvas.drawText("Usuario Activo: $uActivo", leftMargin, y, paint)
            y += 30f

            val sim1 = obtenerSimulacionDesdeSpinner(spnSim1)
            val sim2 = obtenerSimulacionDesdeSpinner(spnSim2)
            val sim3 = obtenerSimulacionDesdeSpinner(spnSim3)

            listOfNotNull(
                Triple("Simulación 1", sim1, txvDetalles1.text.toString()),
                Triple("Simulación 2", sim2, txvDetalles2.text.toString()),
                Triple("Simulación 3", sim3, txvDetalles3.text.toString())
            ).forEach { triple ->
                val titulo = triple.first
                val sim = triple.second
                val detallesTexto = triple.third

                if (sim.idSim > 0) {
                    val ctaNombre = dbHelper.obtenerNombreCuentaPorId(sim.idCuenta)
                    paint.isFakeBoldText = true
                    canvas.drawText("--- $titulo: ${sim.nombreSim} (Cuenta: $ctaNombre) ---", leftMargin, y, paint)
                    y += 20f

                    paint.isFakeBoldText = false
                    canvas.drawText("Disponible: ${sim.totalDisponible.toFormatoChile()} | Egresos: ${sim.totalEgresos.toFormatoChile()} | Meses: ${sim.meses} | Excedente: ${sim.excedente.toFormatoChile()}", leftMargin, y, paint)
                    y += 20f

                    val lineasDetalle = detallesTexto.split("\n")
                    for (linea in lineasDetalle) {
                        canvas.drawText(linea, leftMargin + 10f, y, paint)
                        y += 18f
                    }
                    y += 20f
                }
            }

            pdfDocument.finishPage(page)

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir?.mkdirs()
            val pdfFile = File(downloadsDir, "analisis_comparativo_simulaciones.pdf")
            pdfDocument.writeTo(FileOutputStream(pdfFile))
            pdfDocument.close()
            pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
