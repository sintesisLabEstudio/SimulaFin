package com.simulafin

import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie
import java.io.File
import java.io.FileOutputStream

class OutSimResumenActivity : AppCompatActivity() {

    private lateinit var dbHelper: BaseDatosHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_out_sim_resumen)

        findViewById<ImageView>(R.id.btnVolverAnterior).setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        dbHelper = BaseDatosHelper(this)

        // PIE INTEGRADO
        presentaPie("Aqui se presentara el resumen completo de la simulación presentando el nombre de la simulacion la cuenta asociada..todos los montos y el resultado de los meses y excedente...")

        // Componentes
        val uActivo = dbHelper.obtenerNombreUsuarioActivo(SesionUsuario.usuarioActivo)
        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario Activo: $uActivo"

        // HOME botón
        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        // RESUMEN
        val txvResumen = findViewById<TextView>(R.id.txvResumen)
        txvResumen.movementMethod = ScrollingMovementMethod()

        val btnImprimeSim = findViewById<Button>(R.id.btnImprimeSim)
        val btnItems = findViewById<Button>(R.id.btnItems)
        val btnSim = findViewById<Button>(R.id.btnSim)
        val btnGrabaSim = findViewById<Button>(R.id.btnGrabaSim)
        val btnMenu = findViewById<Button>(R.id.btnMenu)

        // Recuperar datos pasados desde InputSimItemsActivity
        val simulacion = intent.getStringExtra("EXTRA_SIMULACION") ?: "Sin especificar"
        val cuenta = intent.getStringExtra("EXTRA_CUENTA") ?: "Sin especificar"
        val valorCuentaStr = intent.getStringExtra("EXTRA_VALOR_CUENTA") ?: "0"
        val listaItems = intent.getStringArrayListExtra("EXTRA_LISTA_ITEMS") ?: arrayListOf()
        val totalGastos = intent.getLongExtra("EXTRA_TOTAL_GASTOS", 0L)

        val valorCuentaNum = valorCuentaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L

        // Cálculo de meses enteros y el excedente restante
        val mesesEnteros: Long
        val excedente: Long

        if (totalGastos > 0) {
            mesesEnteros = valorCuentaNum / totalGastos
            val costoTotalMeses = mesesEnteros * totalGastos
            excedente = valorCuentaNum - costoTotalMeses
        } else {
            mesesEnteros = 0L
            excedente = valorCuentaNum
        }

        // -------------------------------------------------------------------------
        // VALIDACIÓN DE SALDO INSUFICIENTE (Meses en 0 o cuenta menor al total de gastos)
        // -------------------------------------------------------------------------
        if (mesesEnteros == 0L && totalGastos > 0) {
            val builderAlerta = AlertDialog.Builder(this)

            val tvTitle = TextView(this).apply {
                text = "⚠️ ADVERTENCIA DE SALDO"
                setTextColor(Color.WHITE) // Texto en blanco para no saturar
                textSize = 18f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(50, 40, 50, 10)
            }

            val tvMessage = TextView(this).apply {
                text = "El monto total de la cuenta (\$$valorCuentaNum) no alcanza para cubrir el total de ítems de egreso mensuales (\$$totalGastos)."
                setTextColor(Color.WHITE) // Texto en blanco
                textSize = 15f
                setPadding(50, 20, 50, 30)
            }

            builderAlerta.setCustomTitle(tvTitle)
            builderAlerta.setView(tvMessage)
            builderAlerta.setPositiveButton("Entendido") { dialog, _ ->
                dialog.dismiss()
            }
            builderAlerta.show()
        }

        // Construir el texto del resumen detallado
        val resumenBuilder = StringBuilder()
        resumenBuilder.append("Simulación: $simulacion\n")
        resumenBuilder.append("Cuenta: $cuenta\n")
        resumenBuilder.append("Monto Cuenta: $$valorCuentaStr\n\n")
        resumenBuilder.append("--- Detalle de Gastos ---\n")

        if (listaItems.isEmpty()) {
            resumenBuilder.append("(No se agregaron ítems)\n")
        } else {
            for (item in listaItems) {
                resumenBuilder.append("• $item\n")
            }
        }

        resumenBuilder.append("\nTotal Gastos Mensuales: $$totalGastos\n")
        if (totalGastos > 0) {
            resumenBuilder.append("Duración: $mesesEnteros meses\n")
        } else {
            resumenBuilder.append("Duración: Indefinido\n")
        }
        resumenBuilder.append("Excedente: $$excedente")

        txvResumen.text = resumenBuilder.toString()

        // Acción de Imprimir Simulación a PDF
        btnImprimeSim?.setOnClickListener {
            btnIMprimeSim()
        }

        // Volver a la pantalla de ítems conservando el estado y la lista de ítems intacta
        btnItems.setOnClickListener {
            finish()
        }

        btnSim.setOnClickListener {
            val intentMain = Intent(this, InputSimCuentaActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intentMain)
        }

        btnGrabaSim?.setOnClickListener {
            val idUsuario = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)
            val cuentas = dbHelper.obtenerCuentas(idUsuario)
            val cuentaObj = cuentas.find { it.nombreCuenta.equals(cuenta, ignoreCase = true) }
            val idCuenta = cuentaObj?.idCuenta ?: cuentas.firstOrNull()?.idCuenta ?: 1

            val totalDisp = valorCuentaNum.toInt()
            val egr = totalGastos.toInt()
            val mes = mesesEnteros.toInt()
            val exc = excedente.toInt()

            val idSim = dbHelper.insertarSimulacion(idCuenta, idUsuario, simulacion, totalDisp, egr, mes, exc)
            if (idSim != -1L) {
                val detallesLista = mutableListOf<Pair<String, Int>>()
                for (itemStr in listaItems) {
                    val parts = itemStr.split("-")
                    val nombreItem = parts.firstOrNull()?.trim() ?: "Item"
                    val valorItemStr = parts.getOrNull(1)?.replace("[^0-9]".toRegex(), "") ?: "0"
                    val valorItem = valorItemStr.toIntOrNull() ?: 0
                    detallesLista.add(Pair(nombreItem, valorItem))
                }

                dbHelper.reemplazarDetallesSimulacion(idSim, detallesLista, idUsuario)
                Toast.makeText(this, "Simulación '$simulacion' y sus detalles guardados con éxito en la base de datos", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Error al guardar la simulación en la base de datos", Toast.LENGTH_SHORT).show()
            }
        }

        btnMenu.setOnClickListener {
            val intent = Intent(this, MenuSimActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
        }
    }

    /**
     * Función btnIMprimeSim: Genera un reporte PDF con la estructura completa de la simulación en pantalla y abre el visor de archivos PDF del sistema.
     */
    fun btnIMprimeSim() {
        val simulacion = intent.getStringExtra("EXTRA_SIMULACION") ?: "Sin especificar"
        val cuenta = intent.getStringExtra("EXTRA_CUENTA") ?: "Sin especificar"
        val valorCuentaStr = intent.getStringExtra("EXTRA_VALOR_CUENTA") ?: "0"
        val listaItems = intent.getStringArrayListExtra("EXTRA_LISTA_ITEMS") ?: arrayListOf()
        val totalGastos = intent.getLongExtra("EXTRA_TOTAL_GASTOS", 0L)

        val valorCuentaNum = valorCuentaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
        val mesesEnteros = if (totalGastos > 0) valorCuentaNum / totalGastos else 0L
        val excedente = if (totalGastos > 0) valorCuentaNum - (mesesEnteros * totalGastos) else valorCuentaNum

        val pdfFile = generarYVerPdfResumenSimulacion(
            simulacion = simulacion,
            cuenta = cuenta,
            valorCuentaNum = valorCuentaNum,
            listaItems = listaItems,
            totalGastos = totalGastos,
            mesesEnteros = mesesEnteros,
            excedente = excedente
        )

        if (pdfFile != null && pdfFile.exists()) {
            try {
                val uri = FileProvider.getUriForFile(
                    this,
                    "$packageName.fileprovider",
                    pdfFile
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(intent)
                Toast.makeText(this, "Abriendo reporte PDF...", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "PDF guardado en Descargas:\n${pdfFile.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Error al generar el reporte PDF", Toast.LENGTH_SHORT).show()
        }
    }

    private fun generarYVerPdfResumenSimulacion(
        simulacion: String,
        cuenta: String,
        valorCuentaNum: Long,
        listaItems: ArrayList<String>,
        totalGastos: Long,
        mesesEnteros: Long,
        excedente: Long
    ): File? {
        return try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            val paint = Paint().apply {
                color = Color.BLACK
                textSize = 14f
            }

            var y = 50f
            val leftMargin = 50f

            paint.textSize = 22f
            paint.isFakeBoldText = true
            canvas.drawText("Reporte Resumen de Simulación - SimulaFin", leftMargin, y, paint)
            y += 40f

            paint.textSize = 14f
            paint.isFakeBoldText = false
            val uActivo = dbHelper.obtenerNombreUsuarioActivo(SesionUsuario.usuarioActivo)
            canvas.drawText("Usuario Activo: $uActivo", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Simulación: $simulacion", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Cuenta Asociada: $cuenta", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Monto Total Cuenta: \$$valorCuentaNum", leftMargin, y, paint)
            y += 35f

            paint.isFakeBoldText = true
            canvas.drawText("Detalle de Gastos e Ítems:", leftMargin, y, paint)
            y += 25f

            paint.isFakeBoldText = false
            if (listaItems.isEmpty()) {
                canvas.drawText("(No se agregaron ítems)", leftMargin, y, paint)
                y += 22f
            } else {
                for (item in listaItems) {
                    canvas.drawText("• $item", leftMargin, y, paint)
                    y += 22f
                }
            }

            y += 15f
            paint.isFakeBoldText = true
            canvas.drawText("Resultados Calculados:", leftMargin, y, paint)
            y += 25f

            paint.isFakeBoldText = false
            canvas.drawText("• Total Gastos Mensuales: \$$totalGastos", leftMargin, y, paint)
            y += 22f
            val duracionStr = if (totalGastos > 0) "$mesesEnteros meses" else "Indefinido"
            canvas.drawText("• Duración / Cobertura: $duracionStr", leftMargin, y, paint)
            y += 22f
            canvas.drawText("• Excedente Resultante: \$$excedente", leftMargin, y, paint)

            pdfDocument.finishPage(page)

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir?.mkdirs()
            val pdfFile = File(downloadsDir, "resumen_simulacion_${simulacion.replace(" ", "_")}.pdf")
            pdfDocument.writeTo(FileOutputStream(pdfFile))
            pdfDocument.close()
            pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}