package com.simulafin.clases
data class Usuario(
    val idUsuario: Int = 0,
    val nombreUsuario: String = "",
    val claveUsuario: String = "",
    val fechaHoraUsuario: String = "",
    val esAdmin: Boolean = false,
    val preferenciaTema: String = ""
) {
    fun esValido(): Boolean = nombreUsuario.isNotBlank() && claveUsuario.isNotBlank()
    fun obtenerSaludo(): String = if (esAdmin) "Administrador $nombreUsuario" else "Usuario $nombreUsuario"
}
