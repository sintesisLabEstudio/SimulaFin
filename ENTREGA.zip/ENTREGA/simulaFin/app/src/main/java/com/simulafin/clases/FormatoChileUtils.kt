package com.simulafin.clases

import java.text.NumberFormat
import java.util.Locale

/**
 * Utilidades de formateo para Moneda de Chile (CLP / Peso Chileno).
 * Formato estándar: $1.234.567 (con separador de miles '.' y sin decimales).
 */
fun Number?.toFormatoChile(): String {
    val valor = this?.toLong() ?: 0L
    val nf = NumberFormat.getNumberInstance(Locale("es", "CL"))
    val textoFormateado = nf.format(valor)
    return "$$textoFormateado"
}
fun Long.toFormatoChile(): String = (this as Number).toFormatoChile()
fun Int.toFormatoChile(): String = (this as Number).toFormatoChile()
