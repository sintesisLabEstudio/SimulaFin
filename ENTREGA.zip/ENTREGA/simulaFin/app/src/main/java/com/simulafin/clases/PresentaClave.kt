package com.simulafin.clases

import android.annotation.SuppressLint
import android.text.InputType
import android.view.MotionEvent
import android.widget.EditText
import com.simulafin.R

@SuppressLint("ClickableViewAccessibility")
fun EditText.presentaClave() {
    val originalTypeface = this.typeface

    // Asegurar que el icono de ojo blanco esté presente e intínsecamente acotado desde el inicio
    this.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_eye, 0)

    var isVisible = false

    this.setOnTouchListener { _, event ->
        if (event.action == MotionEvent.ACTION_UP) {
            val drawableRight = this.compoundDrawablesRelative[2]
            if (drawableRight != null) {
                // Cálculo de la zona de toque en coordenadas locales del EditText (event.x)
                val boundLeft = this.width - this.paddingRight - drawableRight.intrinsicWidth - 24
                if (event.x >= boundLeft) {
                    isVisible = !isVisible
                    this.inputType = if (isVisible) {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    } else {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    }
                    this.typeface = originalTypeface
                    this.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_eye, 0)
                    this.setSelection(this.text?.length ?: 0)
                    this.performClick()
                    return@setOnTouchListener true
                }
            }
        }
        false
    }
}
