package com.simulafin

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Item
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie
import com.simulafin.clases.mostrarAlertaRestringida

class ItemsActivity : AppCompatActivity() {

    private lateinit var spnItems: Spinner
    private lateinit var txtNombreItem: EditText
    private lateinit var txtVal: EditText
    private lateinit var lsvItemsUsuario: ListView
    private lateinit var adapterItem: ArrayAdapter<String>
    private lateinit var adapterListViewItems: ArrayAdapter<String>
    private val listaItems = mutableListOf<String>()
    private val listaItemsUsuarioList = mutableListOf<String>()

    private lateinit var dbHelper: BaseDatosHelper
    private var idUsuarioActivo: Int = 1
    private val listaItemsBD = mutableListOf<Item>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_items)

        findViewById<ImageView>(R.id.btnVolverAnterior).setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        presentaPie("Gestión de Ítems: Permite administrar el catálogo global de gastos y egresos mensuales.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        dbHelper = BaseDatosHelper(this)
        idUsuarioActivo = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        spnItems = findViewById(R.id.spnItems)
        txtNombreItem = findViewById(R.id.txtNombreItem)
        txtVal = findViewById(R.id.txtVal)
        lsvItemsUsuario = findViewById(R.id.lsvItemsUsuario)

        val btnAgregaItem = findViewById<Button>(R.id.btnAgregaItem)
        val btnGrabaItem = findViewById<Button>(R.id.btnGrabaItem)
        val btnEliminaItem = findViewById<Button>(R.id.btnEliminaItem)

        adapterItem = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaItems
        )
        adapterItem.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnItems.adapter = adapterItem

        adapterListViewItems = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_single_choice,
            listaItemsUsuarioList
        )
        lsvItemsUsuario.adapter = adapterListViewItems
        lsvItemsUsuario.choiceMode = ListView.CHOICE_MODE_SINGLE

        // Listener para sincronizar la selección en lsvItemsUsuario con el Spinner y campos de edición
        lsvItemsUsuario.setOnItemClickListener { _, _, position, _ ->
            if (position >= 0 && position < listaItemsBD.size) {
                spnItems.setSelection(position + 1)
                val itemObj = listaItemsBD[position]
                txtNombreItem.setText(itemObj.nombreItem)
                txtVal.setText(itemObj.valorItem.toString())
            }
        }

        // Configurar lista de ítems exclusivamente desde la base de datos SQLite (sin auto-seeding)
        cargarItemsDesdeBD()

        // Listener del Spinner spnItems que llama a SeleccionItem()
        spnItems.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                SeleccionItem(position)
                if (position > 0 && position <= listaItemsBD.size) {
                    lsvItemsUsuario.setItemChecked(position - 1, true)
                } else {
                    lsvItemsUsuario.clearChoices()
                    adapterListViewItems.notifyDataSetChanged()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }

        // Configurar txtVal para seleccionar todo al hacer clic sin borrar
        txtVal.setSelectAllOnFocus(true)
        txtVal.setOnClickListener {
            txtVal.selectAll()
        }

        // Botón "+" para agregar un nuevo ítem solicitando datos con un Dialog
        btnAgregaItem.setOnClickListener {
            mostrarDialogNuevoItem()
        }

        // Botón Grabar para guardar cambios en el ítem seleccionado en la base de datos
        btnGrabaItem.setOnClickListener {
            val pos = spnItems.selectedItemPosition
            val nombreEditado = txtNombreItem.text.toString().trim()
            val valEditadoStr = txtVal.text.toString().trim()

            if (pos <= 0 || pos > listaItemsBD.size) {
                Toast.makeText(this, "Seleccione un ítem válido para guardar cambios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (nombreEditado.isEmpty() || valEditadoStr.isEmpty()) {
                Toast.makeText(this, "Nombre y valor no pueden estar vacíos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val itemActual = listaItemsBD[pos - 1]
            val montoEditado = valEditadoStr.toIntOrNull() ?: 0

            val exito = dbHelper.actualizarItem(itemActual.idItem, nombreEditado, montoEditado)

            if (exito) {
                cargarItemsDesdeBD()
                spnItems.setSelection(pos)
                lsvItemsUsuario.setItemChecked(pos - 1, true)
                txtNombreItem.setText(nombreEditado)
                txtVal.setText(montoEditado.toString())
                Toast.makeText(this, "Ítem '$nombreEditado' guardado con éxito ($$montoEditado)", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error al actualizar el ítem en la base de datos", Toast.LENGTH_SHORT).show()
            }
        }

        // Botón Eliminar para eliminar el ítem seleccionado de la tabla con confirmación
        btnEliminaItem.setOnClickListener {
            val pos = spnItems.selectedItemPosition
            if (pos <= 0 || pos > listaItemsBD.size) {
                Toast.makeText(this, "Seleccione un ítem válido para eliminar", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val itemActual = listaItemsBD[pos - 1]

            // Validar en SQLite si el ítem está ocupado/comprometido por alguna simulación
            val simOcupada = dbHelper.itemOcupado(itemActual.idItem)
            if (simOcupada.isNotEmpty()) {
                // [OPTIMIZACIÓN]: Reemplazado código redundante de AlertDialog por el método helper centralizado mostrarAlertaRestringida().
                // Código anterior comentado por requerimiento de conservar el código previo:
                /*
                val builder = AlertDialog.Builder(this)
                val tvTitle = TextView(this).apply {
                    text = "⚠️ OPERACIÓN DENEGADA"
                    setTextColor(Color.RED)
                    textSize = 18f
                    setTypeface(null, Typeface.BOLD)
                    setPadding(50, 40, 50, 10)
                }
                val tvMessage = TextView(this).apply {
                    text = "El ítem '${itemActual.nombreItem}' no se puede eliminar porque está ocupado por la simulación '$simOcupada'."
                    setTextColor(android.graphics.Color.WHITE)
                    textSize = 15f
                    setPadding(50, 20, 50, 30)
                }
                builder.setCustomTitle(tvTitle)
                builder.setView(tvMessage)
                builder.setPositiveButton("Aceptar") { dialog, _ ->
                    dialog.dismiss()
                }
                builder.show()
                */
                
                mostrarAlertaRestringida(
                    "⚠️ OPERACIÓN DENEGADA",
                    "El ítem '${itemActual.nombreItem}' no se puede eliminar porque está ocupado por la simulación '$simOcupada'."
                )

                return@setOnClickListener
            }

            mostrarDialogConfirmarEliminar(itemActual)
        }
    }

    private fun cargarItemsDesdeBD() {
        listaItemsBD.clear()
        listaItems.clear()
        listaItemsUsuarioList.clear()

        val items = dbHelper.obtenerItems(idUsuarioActivo)
        if (items.isEmpty()) {
            listaItems.add("No hay ítems guardados")
        } else {
            listaItems.add("Seleccione un ítem...")
            listaItemsBD.addAll(items)
            for (itemObj in listaItemsBD) {
                listaItems.add(itemObj.nombreItem)
                listaItemsUsuarioList.add("${itemObj.nombreItem} - $${itemObj.valorItem}")
            }
        }

        adapterItem.notifyDataSetChanged()
        adapterListViewItems.notifyDataSetChanged()
        lsvItemsUsuario.clearChoices()
    }

    private fun mostrarDialogNuevoItem() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nuevo Ítem y Valor")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(this).apply {
            hint = "Nombre del nuevo ítem"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(this).apply {
            hint = "Monto / Valor del ítem"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("Agregar") { dialog, _ ->
            val nombreNuevoItem = inputNombre.text.toString().trim()
            val valNuevoItemStr = inputValor.text.toString().trim()

            if (nombreNuevoItem.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el nombre del ítem", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            if (valNuevoItemStr.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el valor del ítem", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            if (listaItemsBD.any { it.nombreItem.equals(nombreNuevoItem, ignoreCase = true) }) {
                Toast.makeText(this, "El ítem '$nombreNuevoItem' ya existe", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            val montoNum = valNuevoItemStr.toIntOrNull() ?: 0
            val exito = dbHelper.insertarItem(idUsuarioActivo, nombreNuevoItem, montoNum)

            if (exito) {
                cargarItemsDesdeBD()
                val nuevaPos = listaItemsBD.indexOfFirst { it.nombreItem == nombreNuevoItem }
                if (nuevaPos != -1) {
                    spnItems.setSelection(nuevaPos + 1)
                    lsvItemsUsuario.setItemChecked(nuevaPos, true)
                    txtNombreItem.setText(nombreNuevoItem)
                    txtVal.setText(montoNum.toString())
                }
                Toast.makeText(this, "Ítem '$nombreNuevoItem' agregado con éxito ($$montoNum)", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error al guardar el ítem en la base de datos", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun mostrarDialogConfirmarEliminar(itemObj: Item) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Alerta de Eliminación")
        builder.setMessage("¿Está seguro de que desea eliminar el ítem '${itemObj.nombreItem}'? Esta acción eliminará el registro de la base de datos.")

        builder.setPositiveButton("Eliminar") { dialog, _ ->
            val exito = dbHelper.eliminarItem(itemObj.idItem)
            if (exito) {
                cargarItemsDesdeBD()
                spnItems.setSelection(0)
                txtNombreItem.setText("")
                txtVal.setText("")
                Toast.makeText(this, "Ítem '${itemObj.nombreItem}' eliminado con éxito", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error al eliminar el ítem de la base de datos", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    fun SeleccionItem(position: Int) {
        val itemSel = listaItemsBD.getOrNull(position - 1)
        if (position == 0 || itemSel == null) {
            txtNombreItem.setText("")
            txtVal.setText("")
        } else {
            txtNombreItem.setText(itemSel.nombreItem)
            txtVal.setText(itemSel.valorItem.toString())
        }
    }
}
