package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Cuenta
import com.simulafin.clases.Simulacion
import com.simulafin.clases.SesionSimulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class InputSimCuentaActivity : AppCompatActivity() {

    private lateinit var dbHelper: BaseDatosHelper
    private var idUsuarioActivo: Int = 1

    private lateinit var spnSeleccioSim: Spinner
    private lateinit var adapterSimulacion: ArrayAdapter<String>
    private val listaSimulaciones = mutableListOf<String>()
    private val listaSimulacionesBD = mutableListOf<Simulacion>()

    private lateinit var spnSeleccionCuenta: Spinner
    private lateinit var adapterCuenta: ArrayAdapter<String>
    private val listaCuentas = mutableListOf<String>()
    private val listaCuentasBD = mutableListOf<Cuenta>()

    private lateinit var txtValorCuenta: EditText
    private var isUpdatingCuentasProgrammatically: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_sim_cuenta)

        findViewById<ImageView>(R.id.btnVolverAnterior).setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        dbHelper = BaseDatosHelper(this)
        idUsuarioActivo = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)

        presentaPie("Aqui seleccionaremos la simulacion o crearemos una nueva simulacion, seleccionando la cuenta en la que simularemos que presentara el monto disponible de esa cuenta...")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
        }

        val btnOkCuenta = findViewById<Button>(R.id.btnOkCuenta)
        val btnNuevaSim = findViewById<Button>(R.id.btnNuevaSim)
        val btnNuevaCuenta = findViewById<Button>(R.id.btnNuevaCuenta)
        val btnGrabaSim = findViewById<Button>(R.id.btnGrabaSim)

        spnSeleccioSim = findViewById(R.id.spnSeleccioSim)
        spnSeleccionCuenta = findViewById(R.id.spnSeleccionCuenta)
        txtValorCuenta = findViewById(R.id.txtValorCuenta)

        // Configuración de adaptadores para alimentarse exclusivamente de la tabla Simulaciones y Cuentas
        adapterSimulacion = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaSimulaciones
        )
        adapterSimulacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccioSim.adapter = adapterSimulacion

        adapterCuenta = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaCuentas
        )
        adapterCuenta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccionCuenta.adapter = adapterCuenta

        // Cargar datos exclusivamente desde las tablas de la base de datos
        cargarDatosDesdeBD()

        // Listener para presentar la cuenta asociada cuando el usuario selecciona una simulación existente
        spnSeleccioSim.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position > 0 && position <= listaSimulacionesBD.size) {
                    val simObj = listaSimulacionesBD[position - 1]

                    isUpdatingCuentasProgrammatically = true

                    // 1. Buscar simultáneamente la cuenta asociada por ID de cuenta o por nombre de cuenta
                    var cuentaObj = listaCuentasBD.find { it.idCuenta == simObj.idCuenta }
                    if (cuentaObj == null && simObj.idCuenta > 0) {
                        val nomCtaBD = dbHelper.obtenerNombreCuentaPorId(simObj.idCuenta)
                        if (nomCtaBD.isNotEmpty()) {
                            cuentaObj = listaCuentasBD.find { it.nombreCuenta.equals(nomCtaBD, ignoreCase = true) }
                                ?: Cuenta(idCuenta = simObj.idCuenta, nombreCuenta = nomCtaBD, totalCuenta = simObj.totalDisponible)
                        }
                    }

                    // 2. Sincronizar simultáneamente el Spinner spnSeleccionCuenta y el monto txtValorCuenta
                    if (cuentaObj != null) {
                        val cuentaIndex = listaCuentasBD.indexOfFirst { it.idCuenta == cuentaObj.idCuenta || it.nombreCuenta.equals(cuentaObj.nombreCuenta, ignoreCase = true) }
                        if (cuentaIndex >= 0) {
                            spnSeleccionCuenta.setSelection(cuentaIndex + 1)
                            txtValorCuenta.setText(cuentaObj.totalCuenta.toString())
                        } else {
                            cargarDatosDesdeBD()
                            val nuevoIndex = listaCuentasBD.indexOfFirst { it.idCuenta == cuentaObj.idCuenta || it.nombreCuenta.equals(cuentaObj.nombreCuenta, ignoreCase = true) }
                            if (nuevoIndex >= 0) {
                                spnSeleccionCuenta.setSelection(nuevoIndex + 1)
                                txtValorCuenta.setText(cuentaObj.totalCuenta.toString())
                            } else {
                                spnSeleccionCuenta.setSelection(0)
                                txtValorCuenta.setText(simObj.totalDisponible.toString())
                            }
                        }
                    } else {
                        spnSeleccionCuenta.setSelection(0)
                        txtValorCuenta.setText(simObj.totalDisponible.toString())
                    }

                    isUpdatingCuentasProgrammatically = false

                    // 3. Sincronizar SesionSimulacion con los datos y ítems de la simulación seleccionada
                    SesionSimulacion.simulacion = simObj.nombreSim
                    SesionSimulacion.cuenta = cuentaObj?.nombreCuenta ?: ""
                    SesionSimulacion.valorCuenta = txtValorCuenta.text.toString()
                    SesionSimulacion.listaItemsAgregados.clear()
                    val detallesBD = dbHelper.obtenerDetallesSimulacion(simObj.idSim)
                    for (det in detallesBD) {
                        SesionSimulacion.listaItemsAgregados.add("${det.nombreItem} - $${det.valorItem}")
                    }
                } else if (position == 0) {
                    isUpdatingCuentasProgrammatically = true
                    spnSeleccionCuenta.setSelection(0)
                    txtValorCuenta.setText("")
                    isUpdatingCuentasProgrammatically = false
                    SesionSimulacion.limpiar()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Listener para actualizar el monto en txtValorCuenta según la cuenta seleccionada desde la tabla Cuentas
        spnSeleccionCuenta.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (isUpdatingCuentasProgrammatically) return

                if (position == 0) {
                    txtValorCuenta.setText("")
                } else {
                    val cuentaObj = listaCuentasBD.getOrNull(position - 1)
                    txtValorCuenta.setText(cuentaObj?.totalCuenta?.toString() ?: "")
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }

        txtValorCuenta.setSelectAllOnFocus(true)
        txtValorCuenta.setOnClickListener {
            txtValorCuenta.selectAll()
        }

        btnNuevaSim.setOnClickListener {
            mostrarDialogNuevaSimulacion()
        }

        btnNuevaCuenta.setOnClickListener {
            mostrarDialogNuevaCuenta()
        }

        btnGrabaSim?.setOnClickListener {
            val cuentaSeleccionada = spnSeleccionCuenta.selectedItem?.toString() ?: ""
            val nuevoValor = txtValorCuenta.text.toString().trim()

            if (spnSeleccionCuenta.selectedItemPosition == 0 || cuentaSeleccionada.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una cuenta para guardar el valor", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (nuevoValor.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el valor de la cuenta", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cuentaObj = listaCuentasBD.find { it.nombreCuenta == cuentaSeleccionada }
            if (cuentaObj != null) {
                val pos = spnSeleccionCuenta.selectedItemPosition
                val montoNum = nuevoValor.toIntOrNull() ?: 0
                dbHelper.actualizarCuenta(cuentaObj.idCuenta, cuentaObj.nombreCuenta, montoNum)
                cargarDatosDesdeBD(preservarPosicion = pos, preservarMonto = nuevoValor)
            }
            Toast.makeText(this, "Valor guardado para $cuentaSeleccionada: $$nuevoValor", Toast.LENGTH_SHORT).show()
        }

        btnOkCuenta.setOnClickListener {
            grabarSeleccionCuentaSim()
        }
    }

    private fun cargarDatosDesdeBD(preservarPosicion: Int = -1, preservarMonto: String? = null) {
        val posCuentaPrev = if (preservarPosicion > 0) preservarPosicion else spnSeleccionCuenta.selectedItemPosition
        val valorCuentaPrev = preservarMonto ?: txtValorCuenta.text.toString()

        isUpdatingCuentasProgrammatically = true

        // Cargar Simulaciones exclusivamente desde la tabla Simulaciones de la base de datos (nombreSim)
        listaSimulacionesBD.clear()
        listaSimulaciones.clear()

        val simulaciones = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        if (simulaciones.isEmpty()) {
            listaSimulaciones.add("No hay simulaciones guardadas")
        } else {
            listaSimulaciones.add("Seleccione la simulación")
            listaSimulacionesBD.addAll(simulaciones)
            for (sim in simulaciones) {
                if (!listaSimulaciones.contains(sim.nombreSim)) {
                    listaSimulaciones.add(sim.nombreSim)
                }
            }
        }
        adapterSimulacion.notifyDataSetChanged()

        // Cargar Cuentas exclusivamente desde la tabla Cuentas de la base de datos
        listaCuentasBD.clear()
        listaCuentas.clear()
        listaCuentas.add("Seleccione la cuenta")
        val cuentas = dbHelper.obtenerCuentas(idUsuarioActivo)
        if (cuentas.isEmpty()) {
            listaCuentas.add("No hay cuentas guardadas")
        } else {
            listaCuentasBD.addAll(cuentas)
            for (cta in cuentas) {
                if (!listaCuentas.contains(cta.nombreCuenta)) {
                    listaCuentas.add(cta.nombreCuenta)
                }
            }
        }
        adapterCuenta.notifyDataSetChanged()

        if (posCuentaPrev > 0 && posCuentaPrev < listaCuentas.size) {
            spnSeleccionCuenta.setSelection(posCuentaPrev)
        }
        if (valorCuentaPrev.isNotEmpty()) {
            txtValorCuenta.setText(valorCuentaPrev)
        }

        isUpdatingCuentasProgrammatically = false
    }

    private fun cargarSimulacionesDesdeBD(seleccionNuevaSim: String? = null) {
        val posCuentaPrev = spnSeleccionCuenta.selectedItemPosition
        val valorCuentaPrev = txtValorCuenta.text.toString()

        listaSimulacionesBD.clear()
        listaSimulaciones.clear()

        val simulaciones = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        if (simulaciones.isEmpty()) {
            listaSimulaciones.add("No hay simulaciones guardadas")
        } else {
            listaSimulaciones.add("Seleccione la simulación")
            listaSimulacionesBD.addAll(simulaciones)
            for (sim in simulaciones) {
                if (!listaSimulaciones.contains(sim.nombreSim)) {
                    listaSimulaciones.add(sim.nombreSim)
                }
            }
        }
        adapterSimulacion.notifyDataSetChanged()

        if (seleccionNuevaSim != null) {
            val index = listaSimulaciones.indexOf(seleccionNuevaSim)
            if (index != -1) {
                spnSeleccioSim.setSelection(index)
            }
        }

        if (posCuentaPrev > 0 && posCuentaPrev < listaCuentas.size) {
            spnSeleccionCuenta.setSelection(posCuentaPrev)
        }
        if (valorCuentaPrev.isNotEmpty()) {
            txtValorCuenta.setText(valorCuentaPrev)
        }
    }

    private fun mostrarDialogNuevaSimulacion() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nueva Simulación")

        val input = EditText(this)
        input.hint = "Ingrese nombre de la simulación"
        input.setPadding(40, 30, 40, 30)
        builder.setView(input)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaSim = input.text.toString().trim()
            if (nuevaSim.isNotEmpty()) {
                val idCtaDef = listaCuentasBD.getOrNull(spnSeleccionCuenta.selectedItemPosition - 1)?.idCuenta
                    ?: listaCuentasBD.firstOrNull()?.idCuenta
                    ?: 1
                dbHelper.insertarSimulacion(idCtaDef, idUsuarioActivo, nuevaSim, 1000000, 0, 12, 1000000)
                cargarSimulacionesDesdeBD(nuevaSim)
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun mostrarDialogNuevaCuenta() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nueva Cuenta y Valor")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(this).apply {
            hint = "Nombre de la nueva cuenta"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(this).apply {
            hint = "Monto / Valor de la cuenta"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaCta = inputNombre.text.toString().trim()
            val valorCta = inputValor.text.toString().trim()

            if (nuevaCta.isNotEmpty() && valorCta.isNotEmpty()) {
                val montoNum = valorCta.toIntOrNull() ?: 0
                dbHelper.insertarCuenta(idUsuarioActivo, nuevaCta, montoNum)
                cargarDatosDesdeBD()
                val index = listaCuentas.indexOf(nuevaCta)
                if (index != -1) {
                    spnSeleccionCuenta.setSelection(index)
                } else if (listaCuentas.size > 1) {
                    spnSeleccionCuenta.setSelection(1)
                }
                txtValorCuenta.setText(valorCta)
            } else {
                Toast.makeText(this, "Debe ingresar nombre y valor de la cuenta", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    /**
     * Función grabarSeleccionCuentaSim: Graba a partir de txtValorCuenta en el registro simulación
     * su nuevo nombre, cuenta y valor indicado, dando un mensaje y luego va a la vista que tiene programada.
     */
    fun grabarSeleccionCuentaSim() {
        val simulacionSeleccionada = spnSeleccioSim.selectedItem?.toString() ?: ""
        val cuentaSeleccionada = spnSeleccionCuenta.selectedItem?.toString() ?: ""
        val valorCuenta = txtValorCuenta.text.toString().trim()

        if (spnSeleccioSim.selectedItemPosition == 0 || simulacionSeleccionada.isEmpty()) {
            Toast.makeText(this, "Por favor seleccione una simulación", Toast.LENGTH_SHORT).show()
            return
        }

        if (spnSeleccionCuenta.selectedItemPosition == 0 || cuentaSeleccionada.isEmpty()) {
            Toast.makeText(this, "Por favor seleccione o ingrese una cuenta", Toast.LENGTH_SHORT).show()
            return
        }

        if (valorCuenta.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese el monto para la cuenta", Toast.LENGTH_SHORT).show()
            return
        }

        // Buscar si la simulación elegida ya posee detalles registrados
        val simObj = listaSimulacionesBD.getOrNull(spnSeleccioSim.selectedItemPosition - 1)
            ?: listaSimulacionesBD.find { it.nombreSim.equals(simulacionSeleccionada, ignoreCase = true) }

        if (simObj != null && dbHelper.simulacionConDetalle(simObj.idSim)) {
            AlertDialog.Builder(this)
                .setTitle("Confirmar Sobrescritura")
                .setMessage("La simulación '$simulacionSeleccionada' ya posee detalles guardados. ¿Desea sobrescribir esta simulación?")
                .setPositiveButton("Sí") { dialog, _ ->
                    procederConGrabarSeleccionCuentaSim(simulacionSeleccionada, cuentaSeleccionada, valorCuenta)
                    dialog.dismiss()
                }
                .setNegativeButton("No") { dialog, _ ->
                    dialog.dismiss()
                    mostrarDialogNuevaSimulacion()
                }
                .show()
        } else {
            procederConGrabarSeleccionCuentaSim(simulacionSeleccionada, cuentaSeleccionada, valorCuenta)
        }
    }

    private fun procederConGrabarSeleccionCuentaSim(
        simulacionSeleccionada: String,
        cuentaSeleccionada: String,
        valorCuenta: String
    ) {
        SesionSimulacion.simulacion = simulacionSeleccionada
        SesionSimulacion.cuenta = cuentaSeleccionada
        SesionSimulacion.valorCuenta = valorCuenta
        SesionSimulacion.listaItemsAgregados.clear()

        val simulacionesBD = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        val simExistente = simulacionesBD.find { it.nombreSim.equals(simulacionSeleccionada, ignoreCase = true) }
        if (simExistente != null) {
            val detallesBD = dbHelper.obtenerDetallesSimulacion(simExistente.idSim)
            for (det in detallesBD) {
                SesionSimulacion.listaItemsAgregados.add("${det.nombreItem} - $${det.valorItem}")
            }
        }

        Toast.makeText(
            this,
            "Simulación '$simulacionSeleccionada' grabada con cuenta '$cuentaSeleccionada' y valor de simulación: $$valorCuenta",
            Toast.LENGTH_LONG
        ).show()

        val intent = Intent(this, InputSimItemsActivity::class.java).apply {
            putExtra("EXTRA_SIMULACION", simulacionSeleccionada)
            putExtra("EXTRA_CUENTA", cuentaSeleccionada)
            putExtra("EXTRA_VALOR_CUENTA", valorCuenta)
            putStringArrayListExtra("EXTRA_LISTA_ITEMS", ArrayList(SesionSimulacion.listaItemsAgregados))
        }
        startActivity(intent)
    }
}
