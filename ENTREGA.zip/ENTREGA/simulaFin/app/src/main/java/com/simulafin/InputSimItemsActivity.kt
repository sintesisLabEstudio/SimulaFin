package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Item
import com.simulafin.clases.SesionSimulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class InputSimItemsActivity : AppCompatActivity() {

    private lateinit var spnSeleccionItem: Spinner
    private lateinit var adapterItem: ArrayAdapter<String>
    private val listaItems = mutableListOf<String>()
    private val listaItemsBD = mutableListOf<Item>()

    private lateinit var txtValorItem: EditText
    private lateinit var txvTotalItems: TextView
    private lateinit var lvItems: ListView
    private lateinit var adapterListado: ArrayAdapter<String>
    private val listaItemsAgregados = mutableListOf<String>()
    private var itemSeleccionadoListViewPosition: Int = -1

    private lateinit var dbHelper: BaseDatosHelper
    private var idUsuarioActivo: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_sim_items)

        findViewById<ImageView>(R.id.btnVolverAnterior).setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        presentaPie("Aqui ingresamos los items de gastos mensuales y formamos la lista de items de la simulación teniendo con esto el monto total de egreso mensual.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        dbHelper = BaseDatosHelper(this)
        idUsuarioActivo = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        // Recuperar datos pasados desde InputSimCuentaActivity
        val simulacion = intent.getStringExtra("EXTRA_SIMULACION") ?: ""
        val cuenta = intent.getStringExtra("EXTRA_CUENTA") ?: ""
        val valorCuenta = intent.getStringExtra("EXTRA_VALOR_CUENTA") ?: ""

        spnSeleccionItem = findViewById(R.id.spnSeleccionItem)
        txtValorItem = findViewById(R.id.txtValorItem)
        txvTotalItems = findViewById(R.id.txvTotalItems)
        lvItems = findViewById(R.id.lvItems)

        val btnNuevoItem = findViewById<Button>(R.id.btnNuevoItem)
        val btnAgregarItem = findViewById<Button>(R.id.btnAgregarItem)
        val bynEliminarItem = findViewById<Button>(R.id.bynEliminarItem)
        val btnOkItems = findViewById<Button>(R.id.btnOkItems)

        adapterItem = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaItems
        )
        adapterItem.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccionItem.adapter = adapterItem

        // Configurar lista de ítems exclusivamente desde la tabla Items de la base de datos (sin auto-seeding)
        cargarItemsDesdeBD()

        // Configurar adaptador para el ListView de ítems agregados
        adapterListado = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_single_choice,
            listaItemsAgregados
        )
        lvItems.adapter = adapterListado
        lvItems.choiceMode = ListView.CHOICE_MODE_SINGLE

        // Cargar ítems de la simulación desde la base de datos si existe, o desde la sesión activa
        listaItemsAgregados.clear()
        if (simulacion.isNotEmpty()) {
            val simulacionesBD = dbHelper.obtenerSimulaciones(idUsuarioActivo)
            val simExistente = simulacionesBD.find { it.nombreSim.equals(simulacion, ignoreCase = true) }
            if (simExistente != null) {
                val detallesBD = dbHelper.obtenerDetallesSimulacion(simExistente.idSim)
                for (det in detallesBD) {
                    val registro = "${det.nombreItem} - $${det.valorItem}"
                    listaItemsAgregados.add(registro)
                }
                SesionSimulacion.listaItemsAgregados.clear()
                SesionSimulacion.listaItemsAgregados.addAll(listaItemsAgregados)
            } else if (SesionSimulacion.listaItemsAgregados.isNotEmpty()) {
                listaItemsAgregados.addAll(SesionSimulacion.listaItemsAgregados)
            }
        } else if (SesionSimulacion.listaItemsAgregados.isNotEmpty()) {
            listaItemsAgregados.addAll(SesionSimulacion.listaItemsAgregados)
        }
        adapterListado.notifyDataSetChanged()

        // Calcular e informar el total inicial
        calcularYActualizarTotal()

        // Listener para registrar la posición al seleccionar una fila en el ListView
        lvItems.setOnItemClickListener { _, _, position, _ ->
            itemSeleccionadoListViewPosition = position
        }

        // Listener para actualizar el monto del item seleccionado en el Spinner desde la tabla Items
        spnSeleccionItem.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    txtValorItem.setText("")
                } else {
                    val itemObj = listaItemsBD.getOrNull(position - 1)
                    txtValorItem.setText(itemObj?.valorItem?.toString() ?: "")
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }

        // Seleccionar todo el texto al enfocar o hacer clic para permitir editar o reemplazar fácilmente
        txtValorItem.setSelectAllOnFocus(true)
        txtValorItem.setOnClickListener {
            txtValorItem.selectAll()
        }

        // Al presionar el botón btnNuevoItem (+) despliega el diálogo para nuevo ítem
        btnNuevoItem.setOnClickListener {
            mostrarDialogNuevoItem()
        }

        val btnEliminaItem = findViewById<Button>(R.id.btnEliminaItem)
        btnEliminaItem?.setOnClickListener {
            val pos = spnSeleccionItem.selectedItemPosition
            if (pos <= 0 || pos > listaItemsBD.size) {
                Toast.makeText(this, "Seleccione un ítem válido para eliminar de la base de datos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val itemActual = listaItemsBD[pos - 1]
            val simOcupada = dbHelper.itemOcupado(itemActual.idItem)
            if (simOcupada.isNotEmpty()) {
                val builder = AlertDialog.Builder(this)

                val tvTitle = TextView(this).apply {
                    text = "⚠️ OPERACIÓN DENEGADA"
                    setTextColor(android.graphics.Color.RED)
                    textSize = 18f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setPadding(50, 40, 50, 10)
                }

                val tvMessage = TextView(this).apply {
                    text = "El ítem '${itemActual.nombreItem}' no se puede eliminar porque está ocupado por la simulación '$simOcupada'."
                    setTextColor(android.graphics.Color.RED)
                    textSize = 15f
                    setPadding(50, 20, 50, 30)
                }

                builder.setCustomTitle(tvTitle)
                builder.setView(tvMessage)
                builder.setPositiveButton("Aceptar") { dialog, _ ->
                    dialog.dismiss()
                }
                builder.show()
                return@setOnClickListener
            }

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Alerta de Eliminación")
            builder.setMessage("¿Está seguro de que desea eliminar el ítem '${itemActual.nombreItem}' de la base de datos?")

            builder.setPositiveButton("Eliminar") { dialog, _ ->
                val exito = dbHelper.eliminarItem(itemActual.idItem)
                if (exito) {
                    cargarItemsDesdeBD()
                    spnSeleccionItem.setSelection(0)
                    txtValorItem.setText("")
                    Toast.makeText(this, "Ítem '${itemActual.nombreItem}' eliminado de la base de datos", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Error al eliminar el ítem de la base de datos", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }

            builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
            builder.show()
        }

        val btnGrabarValorItem = findViewById<Button>(R.id.btnGrabarValorItem)
        btnGrabarValorItem?.setOnClickListener {
            val itemSeleccionado = spnSeleccionItem.selectedItem?.toString() ?: ""
            val nuevoValor = txtValorItem.text.toString().trim()

            if (spnSeleccionItem.selectedItemPosition == 0 || itemSeleccionado.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione un ítem para guardar el valor", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (nuevoValor.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el valor del ítem", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val itemObj = listaItemsBD.find { it.nombreItem == itemSeleccionado }
            if (itemObj != null) {
                val valNum = nuevoValor.toIntOrNull() ?: 0
                dbHelper.actualizarItem(itemObj.idItem, itemObj.nombreItem, valNum)
                cargarItemsDesdeBD()
            }
            Toast.makeText(this, "Valor guardado para $itemSeleccionado: $$nuevoValor", Toast.LENGTH_SHORT).show()
        }

        btnAgregarItem.setOnClickListener {
            val itemSeleccionado = spnSeleccionItem.selectedItem?.toString() ?: ""
            val valorItem = txtValorItem.text.toString().trim()

            if (spnSeleccionItem.selectedItemPosition == 0 || itemSeleccionado.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione un ítem válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (valorItem.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese o verifique el monto del ítem", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val registro = "$itemSeleccionado - $$valorItem"
            listaItemsAgregados.add(registro)
            SesionSimulacion.listaItemsAgregados.add(registro)
            adapterListado.notifyDataSetChanged()
            calcularYActualizarTotal()

            // Resetear Spinner y EditText
            spnSeleccionItem.setSelection(0)
            txtValorItem.text.clear()
            itemSeleccionadoListViewPosition = -1
            lvItems.clearChoices()
        }

        // Listener para eliminar la fila seleccionada de lvItems
        bynEliminarItem.setOnClickListener {
            val pos = if (itemSeleccionadoListViewPosition != -1) itemSeleccionadoListViewPosition else lvItems.checkedItemPosition
            if (pos != ListView.INVALID_POSITION && pos >= 0 && pos < listaItemsAgregados.size) {
                val itemEliminado = listaItemsAgregados.removeAt(pos)
                SesionSimulacion.listaItemsAgregados.remove(itemEliminado)
                adapterListado.notifyDataSetChanged()
                calcularYActualizarTotal()
                itemSeleccionadoListViewPosition = -1
                lvItems.clearChoices()
                Toast.makeText(this, "Ítem eliminado: $itemEliminado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Seleccione una fila en la lista para eliminar", Toast.LENGTH_SHORT).show()
            }
        }

        btnOkItems.setOnClickListener {
            if (listaItemsAgregados.isEmpty()) {
                Toast.makeText(this, "Debe agregar al menos un ítem a la lista", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Sincronizar explícitamente SesionSimulacion con ÚNICAMENTE la lista de esta sesión
            SesionSimulacion.listaItemsAgregados.clear()
            SesionSimulacion.listaItemsAgregados.addAll(listaItemsAgregados)

            // Si la simulación ya existe previamente en la base de datos, reemplazar sus detalles en SQLite
            val simulacionesBD = dbHelper.obtenerSimulaciones(idUsuarioActivo)
            val simExistente = simulacionesBD.find { it.nombreSim.equals(simulacion, ignoreCase = true) }
            if (simExistente != null) {
                val detallesLista = mutableListOf<Pair<String, Int>>()
                for (registro in listaItemsAgregados) {
                    val nombreItem = registro.substringBefore("-").trim()
                    val valorItemStr = registro.substringAfter("-").replace("[^0-9]".toRegex(), "")
                    val valorItem = valorItemStr.toIntOrNull() ?: 0
                    detallesLista.add(Pair(nombreItem, valorItem))
                }
                dbHelper.reemplazarDetallesSimulacion(simExistente.idSim.toLong(), detallesLista, idUsuarioActivo)
            }

            var totalGastos = 0L
            for (registro in listaItemsAgregados) {
                val montoString = registro.substringAfter("-").replace("[^0-9]".toRegex(), "")
                totalGastos += (montoString.toLongOrNull() ?: 0L)
            }

            val intent = Intent(this, OutSimResumenActivity::class.java).apply {
                putExtra("EXTRA_SIMULACION", simulacion)
                putExtra("EXTRA_CUENTA", cuenta)
                putExtra("EXTRA_VALOR_CUENTA", valorCuenta)
                putStringArrayListExtra("EXTRA_LISTA_ITEMS", ArrayList(listaItemsAgregados))
                putExtra("EXTRA_TOTAL_GASTOS", totalGastos)
            }
            startActivity(intent)
        }
    }

    private fun cargarItemsDesdeBD() {
        listaItemsBD.clear()
        listaItems.clear()

        val items = dbHelper.obtenerItems(idUsuarioActivo)
        if (items.isEmpty()) {
            listaItems.add("No hay ítems guardados")
        } else {
            listaItems.add("Seleccione el Item Mensual")
            listaItemsBD.addAll(items)
            for (itemObj in listaItemsBD) {
                listaItems.add(itemObj.nombreItem)
            }
        }
        adapterItem.notifyDataSetChanged()
    }

    private fun calcularYActualizarTotal() {
        var total = 0L
        for (registro in listaItemsAgregados) {
            val montoString = registro.substringAfter("-").replace("[^0-9]".toRegex(), "")
            val monto = montoString.toLongOrNull() ?: 0L
            total += monto
        }
        txvTotalItems.text = "Total: $$total"
    }

    private fun mostrarDialogNuevoItem() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nuevo Ítem y Valor")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(this).apply {
            hint = "Nombre del nuevo ítem"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(this).apply {
            hint = "Monto/Valor del ítem"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevoItem = inputNombre.text.toString().trim()
            val valorItem = inputValor.text.toString().trim()

            if (nuevoItem.isNotEmpty() && valorItem.isNotEmpty()) {
                val valNum = valorItem.toIntOrNull() ?: 0
                dbHelper.insertarItem(idUsuarioActivo, nuevoItem, valNum)
                cargarItemsDesdeBD()
                val index = listaItems.indexOf(nuevoItem)
                if (index != -1) {
                    spnSeleccionItem.setSelection(index)
                }
                txtValorItem.setText(valorItem)
            } else {
                Toast.makeText(this, "Debe ingresar nombre y valor del ítem", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }
}
