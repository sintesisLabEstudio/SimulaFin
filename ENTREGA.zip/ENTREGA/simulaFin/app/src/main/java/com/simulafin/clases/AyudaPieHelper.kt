package com.simulafin.clases
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.R
fun AppCompatActivity.presentaPie(mensaje: String) {
    val txvPie = findViewById<TextView>(R.id.txvPiePagina)
        ?: findViewById<TextView>(R.id.textView2) //cambiar a txt definido
        ?: findViewById<TextView>(R.id.textView)
        ?: findViewById<TextView>(R.id.tvExplicacionResumen)
    
    txvPie?.text = mensaje
}

fun Context.mostrarAlertaRestringida(titulo: String, mensaje: String) {
    val builder = AlertDialog.Builder(this)

    val tvTitle = TextView(this).apply {
        text = titulo
        setTextColor(Color.RED)
        textSize = 18f
        setTypeface(null, Typeface.BOLD)
        setPadding(50, 40, 50, 10)
    }

    val tvMessage = TextView(this).apply {
        text = mensaje
        setTextColor(Color.WHITE)
        textSize = 15f
        setPadding(50, 20, 50, 30)
    }

    builder.setCustomTitle(tvTitle)
    builder.setView(tvMessage)
    builder.setPositiveButton("Aceptar") { dialog, _ ->
        dialog.dismiss()
    }
    builder.show()
}
fun String.parseMontoLimpio(): Long {
    return this.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
}
