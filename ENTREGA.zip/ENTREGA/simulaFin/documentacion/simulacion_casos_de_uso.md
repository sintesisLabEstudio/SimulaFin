# Informe de Simulación e Interacción de Casos de Uso en SimulaFin

Este informe documenta la simulación técnica y funcional realizada sobre la aplicación **SimulaFin**, evaluando dos perfiles de usuario reales:
1. **Caso 1: Emprendedor** (Startup / Panadería Artesanal).
2. **Caso 2: Inversionista / Gestor de Proyecto** (Desarrollo de Software con Monto Fijo).

---

## 📊 Resumen Ejecutivo de Resultados

| Perfil de Usuario | Escenario / Simulación | Fondo Disponible | Egresos Mensuales | Duración (Meses) | Excedente Resultante | Viabilidad (`esViable()`) | Alerta de Saldo |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Emprendedor** | Escenario A: Gastos Iniciales | $6.000.000 | $4.000.000 | **1 mes** | $2.000.000 | `true` | No |
| **Emprendedor** | Escenario B: Gastos Optimizados | $6.000.000 | $2.350.000 | **2 meses** | $1.300.000 | `true` | No |
| **Proyecto Monto Fijo** | Plan A: Presupuesto Normal | $15.000.000 | $6.500.000 | **2 meses** | $2.000.000 | `true` | No |
| **Proyecto Monto Fijo** | Plan B: Presupuesto Excedido | $15.000.000 | $16.500.000 | **0 meses** | $15.000.000 | `false` | **⚠️ Activa** |

---

## 🥐 CASO DE USO 1: Emprendedor (Panadería Artesanal)

### Contexto de Negocio
Un emprendedor cuenta con un fondo inicial de **$6.000.000** abonado en su cuenta corporativa `Banco Estado - Capital Semilla`. Necesita evaluar cuántos meses de operación completa ("Runway" o pista financiera) puede financiar antes de requerir ingresos por ventas.

### 📝 Escenario 1.1: Gastos Iniciales Elevados
- **Cuenta Asociada:** `Banco Estado - Capital Semilla` ($6.000.000)
- **Desglose de Ítems de Egreso Mensual:**
  - Arriendo Local Comercial: **$1.200.000**
  - Materias Primas e Insumos: **$800.000**
  - Sueldo Personal Operativo: **$1.500.000**
  - Servicios Básicos (Luz, Agua, Gas): **$250.000**
  - Marketing Digital & Publicidad: **$250.000**
- **Cálculos Matemáticos:**
  $$\text{Total Egresos Mensuales} = 1.200.000 + 800.000 + 1.500.000 + 250.000 + 250.000 = \$4.000.000$$
  $$\text{Meses Cubiertos} = \lfloor \frac{6.000.000}{4.000.000} \rfloor = 1 \text{ mes}$$
  $$\text{Excedente} = 6.000.000 - (1 \times 4.000.000) = \$2.000.000$$

### ⚡ Escenario 1.2: Optimización de Costos y Extensión de Pista
El emprendedor decide subarrendar un espacio sobrante del local y renegociar materias primas al por mayor.
- **Desglose de Ítems Optimizados:**
  - Arriendo Subarrendado: **$700.000**
  - Insumos Optimizados: **$500.000**
  - Sueldo Operativo Ajustado: **$1.000.000**
  - Servicios Básicos Eficientes: **$150.000**
- **Cálculos Matemáticos:**
  $$\text{Total Egresos Mensuales} = 700.000 + 500.000 + 1.000.000 + 150.000 = \$2.350.000$$
  $$\text{Meses Cubiertos} = \lfloor \frac{6.000.000}{2.350.000} \rfloor = 2 \text{ meses}$$
  $$\text{Excedente} = 6.000.000 - (2 \times 2.350.000) = \$1.300.000$$

> [!TIP]
> **Impacto en el Negocio:** Al reestructurar la estructura de costos en SimulaFin, el emprendedor **duplica su capacidad de supervivencia operativa de 1 a 2 meses enteros**, manteniendo además $1.300.000 de resguardo en caja.

---

## 💻 CASO DE USO 2: Proyecto con Monto Fijo (Desarrollo Tech)

### Contexto de Negocio
Un gestor de proyectos o inversionista administra un fondo cerrado de **$15.000.000** (`Fondo Inversión Proyecto Tech`) para la creación de una plataforma software.

### 📝 Escenario 2.1: Asignación Normal de Presupuesto
- **Cuenta Asociada:** `Fondo Inversión Proyecto Tech` ($15.000.000)
- **Desglose de Ítems:**
  - Honorarios Equipo Desarrollo: **$3.500.000**
  - Diseñador UX/UI Senior: **$1.500.000**
  - Infraestructura Cloud AWS & Firebase: **$500.000**
  - Licencias Software & Herramientas: **$300.000**
  - Reserva de Contingencias: **$700.000**
- **Cálculos Matemáticos:**
  $$\text{Total Egresos Mensuales} = \$6.500.000$$
  $$\text{Meses Cubiertos} = \lfloor \frac{15.000.000}{6.500.000} \rfloor = 2 \text{ meses}$$
  $$\text{Excedente} = 15.000.000 - (2 \times 6.500.000) = \$2.000.000$$

### 🚨 Escenario 2.2: Sobrecosto / Adición de Campaña Publicitaria (Déficit)
El equipo decide incluir una campaña masiva de lanzamiento de **$10.000.000** mensuales.
- **Total Egresos Mensuales:** $\$6.500.000 + \$10.000.000 = \$16.500.000$
- **Resultado del Sistema:**
  $$\text{Meses Cubiertos} = \lfloor \frac{15.000.000}{16.500.000} \rfloor = 0 \text{ meses}$$
  $$\text{Excedente} = \$15.000.000$$
  $$\text{Viabilidad (\texttt{esViable()})} = \text{False (Saldo Insuficiente)}$$

> [!WARNING]
> **Comportamiento del Sistema ante Saldo Insuficiente:**
> Tanto en la vista de Síntesis (`SimulacionActivity`) como en la vista de Resumen (`OutSimResumenActivity`), el sistema detecta que $\text{Total Egresos} > \text{Total Cuenta}$ y gatilla inmediatamente una ventana emergente modal:
> **`⚠️ ADVERTENCIA DE SALDO: El monto total de la cuenta ($15.000.000) no alcanza para cubrir el total de ítems de egreso mensuales ($16.500.000).`**

---

## 📈 Comportamiento de los Módulos del Sistema

```mermaid
flowchart TD
    A[Inicio / LoginUsuario] --> B[MainActivity: Menú Principal]
    B --> C[CuentasActivity: Gestión de Fondos]
    B --> D[ItemsActivity: Gestión de Egresos]
    B --> E[MenuSimActivity: Módulo de Simulaciones]

    E --> F[InputSimCuentaActivity & InputSimItemsActivity: Paso a Paso]
    E --> G[SimulacionActivity: Síntesis con Fragments]
    E --> H[AnalisisSimActivity: Análisis Comparativo de 3 Simulaciones]
    E --> I[ConsultaSimulacionesActivity: Historial & Exportación PDF/JSON/CSV]

    F --> J[OutSimResumenActivity: Cálculo de Meses, Excedente y Alerta de Saldo]
    G --> J
    H --> K[Generación de Reportes PDF/CSV]
```

### 1. Módulo Paso a Paso vs. Síntesis (Fragments)
- En **Paso a Paso** (`InputSimCuentaActivity` $\to$ `InputSimItemsActivity` $\to$ `OutSimResumenActivity`), los datos se propagan mediante `Intent extras` y `SesionSimulacion`, permitiendo navegación fluida de regreso sin perder la selección de ítems.
- En **Síntesis** (`SimulacionActivity`), la integración de `SimulacionInputFragment` y `SimulacionOutputFragment` recalcula en tiempo real cualquier cambio en la selección de cuentas o agregación/eliminación de ítems.

### 2. Módulo de Análisis Comparativo (`AnalisisSimActivity`)
Permite seleccionar hasta 3 simulaciones independientes registradas en SQLite y desplegar en paralelo:
- Cuenta asociada y disponible.
- Total de ítems de egreso.
- Meses de cobertura resultantes.
- Excedente financiero.

### 3. Persistencia y Confirmación de Sobrescritura (`SimulacionController`)
- Al intentar guardar una simulación cuyo nombre ya exista en la base de datos para el usuario activo, el sistema retorna `GuardarSimulacionResultado.RequiereConfirmacionSobrescritura`.
- Solo al recibir la confirmación explícita del usuario, la base de datos actualiza el registro principal en `Simulaciones` y reemplaza atómicamente sus ítems en `DetallesSimulaciones`.

---

## 🛠️ Verificación y Validación Automatizada

Las reglas de negocio, lógica financiera y control de excepciones fueron validadas mediante la suite de pruebas unitarias automatizada `CasosDeUsoSimulacionTest.kt`.

- **Pruebas ejecutadas:** 4/4 pasadas exitosamente.
- **Tiempo de ejecución:** < 1 segundo via Gradle test runner.
- **Cobertura de escenarios:** Validación de cálculo de meses, excedente, viabilidad, rechazo de montos negativos/vacíos, advertencia de saldo y sobreescritura con confirmación.
