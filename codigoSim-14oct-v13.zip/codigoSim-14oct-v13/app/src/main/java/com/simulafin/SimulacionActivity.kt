package com.simulafin

import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie
import com.simulafin.fragments.SimulacionInputFragment
import com.simulafin.fragments.SimulacionOutputFragment
import com.simulafin.interfaces.OnSimulacionDatosListener
import java.io.File
import java.io.FileOutputStream

class SimulacionActivity : AppCompatActivity(), OnSimulacionDatosListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simulacion)

        presentaPie("Vista de síntesis interactiva combinando entradas de datos y salida gráfica mediante Fragments.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }
    }

    override fun onDatosSimulacionIngresados(totalGastos: Long, totalCuenta: Long) {
        val fragmentOutput = supportFragmentManager.findFragmentById(R.id.containerOutput) as? SimulacionOutputFragment
        fragmentOutput?.actualizarResultados(totalGastos, totalCuenta)
    }

    override fun onSolicitarRecalcular() {
        val fragmentInput = supportFragmentManager.findFragmentById(R.id.containerInput) as? SimulacionInputFragment
        fragmentInput?.recalcularYNotificar()
    }

    override fun onSolicitarEliminarSimulacion() {
        val fragmentInput = supportFragmentManager.findFragmentById(R.id.containerInput) as? SimulacionInputFragment
        fragmentInput?.eliminarSimulacionSeleccionada()
    }

    override fun onSolicitarGuardarSimulacion() {
        val fragmentInput = supportFragmentManager.findFragmentById(R.id.containerInput) as? SimulacionInputFragment
        if (fragmentInput == null) {
            Toast.makeText(this, "Error al acceder a los datos de entrada", Toast.LENGTH_SHORT).show()
            return
        }

        val simulacionNombre = fragmentInput.getSimulacionSeleccionada()
        val cuentaNombre = fragmentInput.getCuentaSeleccionada()
        val totalCuenta = fragmentInput.getTotalCuenta()
        val listaItems = fragmentInput.getListaItemsAgregados()

        if (simulacionNombre.isEmpty() || simulacionNombre.startsWith("Seleccione") || simulacionNombre.startsWith("No hay")) {
            Toast.makeText(this, "Por favor seleccione una simulación válida para guardar", Toast.LENGTH_SHORT).show()
            return
        }

        if (listaItems.isEmpty()) {
            Toast.makeText(this, "Debe tener al menos un ítem en la lista para guardar la simulación", Toast.LENGTH_SHORT).show()
            return
        }

        val dbHelper = BaseDatosHelper(this)
        val idUsuario = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)
        val cuentas = dbHelper.obtenerCuentas(idUsuario)
        val cuentaObj = cuentas.find { it.nombreCuenta.equals(cuentaNombre, ignoreCase = true) }
        val idCuenta = cuentaObj?.idCuenta ?: cuentas.firstOrNull()?.idCuenta ?: 1

        var totalGastos = 0L
        for (itemStr in listaItems) {
            val montoStr = itemStr.substringAfter("-").replace("[^0-9]".toRegex(), "")
            totalGastos += (montoStr.toLongOrNull() ?: 0L)
        }

        val meses = if (totalGastos > 0) totalCuenta / totalGastos else 0L
        val excedente = if (totalGastos > 0) totalCuenta - (meses * totalGastos) else totalCuenta

        val idSim = dbHelper.guardarOActualizarSimulacion(
            idCuenta = idCuenta,
            idUsuario = idUsuario,
            nombreSim = simulacionNombre,
            totalDisponible = totalCuenta.toInt(),
            totalEgresos = totalGastos.toInt(),
            meses = meses.toInt(),
            excedente = excedente.toInt(),
        )

        if (idSim != -1L) {
            // Limpiar detalles anteriores para actualizar con la nueva lista modificada
            val db = dbHelper.writableDatabase
            db.delete("DetallesSimulaciones", "idSim = ?", arrayOf(idSim.toString()))
            db.close()

            // Insertar los nuevos detalles actualizados
            val itemsBD = dbHelper.obtenerItems(idUsuario)
            for (itemStr in listaItems) {
                val parts = itemStr.split("-")
                val nombreItem = parts.firstOrNull()?.trim() ?: "Item"
                val valorItemStr = parts.getOrNull(1)?.replace("[^0-9]".toRegex(), "") ?: "0"
                val valorItem = valorItemStr.toIntOrNull() ?: 0

                val itemObj = itemsBD.find { it.nombreItem.equals(nombreItem, ignoreCase = true) }
                val idItem = itemObj?.idItem ?: 0

                dbHelper.insertarDetalleSimulacion(idSim, idItem, nombreItem, valorItem)
            }

            Toast.makeText(this, "Simulación '$simulacionNombre' actualizada y guardada con éxito (con sus nuevos ítems)", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Error al guardar la simulación en la base de datos", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onSolicitarImprimirSimulacion() {
        val fragmentInput = supportFragmentManager.findFragmentById(R.id.containerInput) as? SimulacionInputFragment
        val fragmentOutput = supportFragmentManager.findFragmentById(R.id.containerOutput) as? SimulacionOutputFragment

        val simNombre = fragmentInput?.getSimulacionSeleccionada() ?: "Simulación"
        val cuentaNombre = fragmentInput?.getCuentaSeleccionada() ?: ""
        val totalCuenta = fragmentInput?.getTotalCuenta() ?: 0L
        val listaItems = fragmentInput?.getListaItemsAgregados() ?: emptyList()

        val totalGastos = fragmentOutput?.getTotalItemsValue() ?: 0L
        val meses = fragmentOutput?.getTotalMesesValue() ?: 0L
        val excedente = fragmentOutput?.getExcedenteValue() ?: 0L

        val pdfFile = generarPdfSimulacionCompleta(
            simNombre = simNombre,
            cuentaNombre = cuentaNombre,
            totalCuenta = totalCuenta,
            listaItems = listaItems,
            totalGastos = totalGastos,
            meses = meses,
            excedente = excedente,
        )

        if (pdfFile != null && pdfFile.exists()) {
            try {
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    this,
                    "$packageName.fileprovider",
                    pdfFile,
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(intent)
                Toast.makeText(this, "Abriendo reporte PDF...", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "PDF guardado en Descargas:\n${pdfFile.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Error al generar el PDF de la simulación", Toast.LENGTH_SHORT).show()
        }
    }

    private fun generarPdfSimulacionCompleta(
        simNombre: String,
        cuentaNombre: String,
        totalCuenta: Long,
        listaItems: List<String>,
        totalGastos: Long,
        meses: Long,
        excedente: Long,
    ): File? {
        return try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            val paint = Paint().apply {
                color = Color.BLACK
                textSize = 14f
            }

            var y = 50f
            val leftMargin = 50f

            paint.textSize = 22f
            paint.isFakeBoldText = true
            canvas.drawText("Reporte de Simulación Activa - SimulaFin", leftMargin, y, paint)
            y += 40f

            paint.textSize = 14f
            paint.isFakeBoldText = false
            canvas.drawText("Usuario Activo: ${SesionUsuario.usuarioActivo}", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Simulación: $simNombre", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Cuenta Asociada: $cuentaNombre", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Monto Total Cuenta: \$$totalCuenta", leftMargin, y, paint)
            y += 35f

            paint.isFakeBoldText = true
            canvas.drawText("Resultados Calculados:", leftMargin, y, paint)
            y += 25f
            paint.isFakeBoldText = false
            canvas.drawText("• Total Mensual Ítems: \$$totalGastos", leftMargin, y, paint)
            y += 22f
            canvas.drawText("• Total Meses (Duración): $meses meses", leftMargin, y, paint)
            y += 22f
            canvas.drawText("• Excedente Resultante: \$$excedente", leftMargin, y, paint)
            y += 35f

            paint.isFakeBoldText = true
            canvas.drawText("Lista de Ítems de Gastos en Pantalla:", leftMargin, y, paint)
            y += 25f

            paint.isFakeBoldText = false
            if (listaItems.isEmpty()) {
                canvas.drawText("(No hay ítems agregados)", leftMargin, y, paint)
            } else {
                for (itemStr in listaItems) {
                    canvas.drawText("• $itemStr", leftMargin, y, paint)
                    y += 22f
                }
            }

            pdfDocument.finishPage(page)

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir?.mkdirs()
            val pdfFile = File(downloadsDir, "simulacion_${simNombre.replace(" ", "_")}.pdf")
            pdfDocument.writeTo(FileOutputStream(pdfFile))
            pdfDocument.close()
            pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
