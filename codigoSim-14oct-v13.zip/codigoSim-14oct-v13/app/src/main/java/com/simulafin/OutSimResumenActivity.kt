package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class OutSimResumenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_out_sim_resumen)
        //PIE INTEGRADO
        presentaPie("Aqui se presentara el resumen completo de la simulación presentando el nombre de la simulacion la cuenta asociada..todos los montos y el resultado de los meses y excedente...")
        //componentes
        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"
        //HOME boton
        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }
        //RESUMEN
        val txvResumen = findViewById<TextView>(R.id.txvResumen)
        txvResumen.movementMethod = ScrollingMovementMethod()
        val btnItems = findViewById<Button>(R.id.btnItems)
        val btnSim = findViewById<Button>(R.id.btnSim)
        val btnGrabaSim = findViewById<Button>(R.id.btnGrabaSim)
        val btnMenu = findViewById<Button>(R.id.btnMenu)

        // Recuperar datos pasados desde InputSimItemsActivity
        val simulacion = intent.getStringExtra("EXTRA_SIMULACION") ?: "Sin especificar"
        val cuenta = intent.getStringExtra("EXTRA_CUENTA") ?: "Sin especificar"
        val valorCuentaStr = intent.getStringExtra("EXTRA_VALOR_CUENTA") ?: "0"
        val listaItems = intent.getStringArrayListExtra("EXTRA_LISTA_ITEMS") ?: arrayListOf()
        val totalGastos = intent.getLongExtra("EXTRA_TOTAL_GASTOS", 0L)

        val valorCuentaNum = valorCuentaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L

        // Cálculo de meses enteros y el excedente restante
        val mesesEnteros: Long
        val excedente: Long

        if (totalGastos > 0) {
            mesesEnteros = valorCuentaNum / totalGastos
            val costoTotalMeses = mesesEnteros * totalGastos
            excedente = valorCuentaNum - costoTotalMeses
        } else {
            mesesEnteros = 0L
            excedente = valorCuentaNum
        }

        // Construir el texto del resumen detallado
        val resumenBuilder = StringBuilder()
        resumenBuilder.append("Simulación: $simulacion\n")
        resumenBuilder.append("Cuenta: $cuenta\n")
        resumenBuilder.append("Monto Cuenta: $$valorCuentaStr\n\n")
        resumenBuilder.append("--- Detalle de Gastos ---\n")

        if (listaItems.isEmpty()) {
            resumenBuilder.append("(No se agregaron ítems)\n")
        } else {
            for (item in listaItems) {
                resumenBuilder.append("• $item\n")
            }
        }

        resumenBuilder.append("\nTotal Gastos Mensuales: $$totalGastos\n")
        if (totalGastos > 0) {
            resumenBuilder.append("Duración: $mesesEnteros meses\n")
        } else {
            resumenBuilder.append("Duración: Indefinido\n")
        }
        resumenBuilder.append("Excedente: $$excedente")

        txvResumen.text = resumenBuilder.toString()

        // Volver a la pantalla de ítems conservando el estado y la lista de ítems intacta
        btnItems.setOnClickListener {
            finish()
        }

        btnSim.setOnClickListener {
            val intentMain = Intent(this, InputSimCuentaActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intentMain)
        }

        btnGrabaSim?.setOnClickListener {
            val dbHelper = BaseDatosHelper(this)
            val idUsuario = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)
            val cuentas = dbHelper.obtenerCuentas(idUsuario)
            val cuentaObj = cuentas.find { it.nombreCuenta.equals(cuenta, ignoreCase = true) }
            val idCuenta = cuentaObj?.idCuenta ?: cuentas.firstOrNull()?.idCuenta ?: 1

            val totalDisp = valorCuentaNum.toInt()
            val egr = totalGastos.toInt()
            val mes = mesesEnteros.toInt()
            val exc = excedente.toInt()

            val idSim = dbHelper.insertarSimulacion(idCuenta, idUsuario, simulacion, totalDisp, egr, mes, exc)
            if (idSim != -1L) {
                // Grabar los registros de detalle en la tabla DetallesSimulaciones
                val itemsBD = dbHelper.obtenerItems(idUsuario)
                for (itemStr in listaItems) {
                    val parts = itemStr.split("-")
                    val nombreItem = parts.firstOrNull()?.trim() ?: "Item"
                    val valorItemStr = parts.getOrNull(1)?.replace("[^0-9]".toRegex(), "") ?: "0"
                    val valorItem = valorItemStr.toIntOrNull() ?: 0

                    val itemObj = itemsBD.find { it.nombreItem.equals(nombreItem, ignoreCase = true) }
                    val idItem = itemObj?.idItem ?: 0

                    dbHelper.insertarDetalleSimulacion(idSim, idItem, nombreItem, valorItem)
                }

                Toast.makeText(this, "Simulación '$simulacion' y sus detalles guardados con éxito en la base de datos", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Error al guardar la simulación en la base de datos", Toast.LENGTH_SHORT).show()
            }
        }

        btnMenu.setOnClickListener {
            val intent = Intent(this, MenuSimActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
        }
    }
}
