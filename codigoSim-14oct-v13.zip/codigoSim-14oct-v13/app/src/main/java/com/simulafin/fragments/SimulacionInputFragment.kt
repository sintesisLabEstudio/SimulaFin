package com.simulafin.fragments

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.simulafin.R
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Cuenta
import com.simulafin.clases.Item
import com.simulafin.clases.Simulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.interfaces.OnSimulacionDatosListener

class SimulacionInputFragment : Fragment() {
    private lateinit var spnSimulacion: Spinner
    private lateinit var adapterSimulacion: ArrayAdapter<String>
    private val listaSimulaciones = mutableListOf<String>()
    private val listaSimulacionesBD = mutableListOf<Simulacion>()

    private lateinit var spnCuenta: Spinner
    private lateinit var adapterCuenta: ArrayAdapter<String>
    private val listaCuentas = mutableListOf<String>()
    private val listaCuentasBD = mutableListOf<Cuenta>()

    private lateinit var spnItems: Spinner
    private lateinit var adapterItem: ArrayAdapter<String>
    private val listaItems = mutableListOf<String>()
    private val listaItemsBD = mutableListOf<Item>()

    private lateinit var txtTotalCuenta: EditText
    private lateinit var txtValorItem: EditText
    private lateinit var lstItemsSeleccionados: ListView
    private lateinit var adapterListado: ArrayAdapter<String>
    private val listaItemsAgregados = mutableListOf<String>()
    private var listener: OnSimulacionDatosListener? = null

    private lateinit var dbHelper: BaseDatosHelper
    private var idUsuarioActivo: Int = 1

    fun getSimulacionSeleccionada(): String = spnSimulacion.selectedItem?.toString() ?: ""
    fun getCuentaSeleccionada(): String = spnCuenta.selectedItem?.toString() ?: ""
    fun getTotalCuenta(): Long = txtTotalCuenta.text.toString().replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
    fun getListaItemsAgregados(): List<String> = listaItemsAgregados

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnSimulacionDatosListener) {
            listener = context
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_simulacion_input, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = BaseDatosHelper(requireContext())
        idUsuarioActivo = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)

        spnSimulacion = view.findViewById(R.id.spnSimulacion)
        spnCuenta = view.findViewById(R.id.spnCuenta)
        spnItems = view.findViewById(R.id.spnItems)

        txtTotalCuenta = view.findViewById(R.id.txtTotalCuenta)
        txtValorItem = view.findViewById(R.id.txtValorItem)

        val btnNuevaSim = view.findViewById<Button>(R.id.btnNuevaSim)
        val btnNuevaCuenta = view.findViewById<Button>(R.id.btnNuevaCuenta)
        val btnNuevoItem = view.findViewById<Button>(R.id.btnNuevoItem)
        val btnAgregaItem = view.findViewById<Button>(R.id.btnAgregaItem)
        val btnEliminarItem = view.findViewById<Button>(R.id.btnAgregaItem2)
        lstItemsSeleccionados = view.findViewById(R.id.lstItemsSeleccionados)

        cargarDatosDesdeBD()

        adapterListado = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_single_choice,
            listaItemsAgregados
        )
        lstItemsSeleccionados.adapter = adapterListado
        lstItemsSeleccionados.choiceMode = ListView.CHOICE_MODE_SINGLE

        spnSimulacion.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position > 0 && position <= listaSimulacionesBD.size) {
                    val simObj = listaSimulacionesBD[position - 1]

                    // Presentar la cuenta asociada
                    val cuentaObj = listaCuentasBD.find { it.idCuenta == simObj.idCuenta }
                    if (cuentaObj != null) {
                        val cuentaIndex = listaCuentasBD.indexOf(cuentaObj)
                        spnCuenta.setSelection(cuentaIndex + 1)
                        txtTotalCuenta.setText(cuentaObj.totalCuenta.toString())
                    } else {
                        txtTotalCuenta.setText(simObj.totalDisponible.toString())
                    }

                    // Cargar los items en la lista lstItemsSeleccionados
                    listaItemsAgregados.clear()
                    val detallesBD = dbHelper.obtenerDetallesSimulacion(simObj.idSim)
                    for (det in detallesBD) {
                        listaItemsAgregados.add("${det.nombreItem} - $${det.valorItem}")
                    }
                    adapterListado.notifyDataSetChanged()
                } else {
                    txtTotalCuenta.setText("")
                    listaItemsAgregados.clear()
                    adapterListado.notifyDataSetChanged()
                }

                recalcularYNotificar(mostrarToast = false)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        spnCuenta.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    txtTotalCuenta.setText("")
                } else {
                    val cuentaObj = listaCuentasBD.getOrNull(position - 1)
                    if (cuentaObj != null) {
                        txtTotalCuenta.setText(cuentaObj.totalCuenta.toString())
                    }
                }
                notificarTotalGastos()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        spnItems.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    txtValorItem.setText("")
                } else {
                    val itemObj = listaItemsBD.getOrNull(position - 1)
                    if (itemObj != null) {
                        txtValorItem.setText(itemObj.valorItem.toString())
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        txtTotalCuenta.setSelectAllOnFocus(true)
        txtTotalCuenta.setOnClickListener { txtTotalCuenta.selectAll() }

        txtValorItem.setSelectAllOnFocus(true)
        txtValorItem.setOnClickListener { txtValorItem.selectAll() }

        btnNuevaSim.setOnClickListener { mostrarDialogNuevaSimulacion() }
        btnNuevaCuenta.setOnClickListener { mostrarDialogNuevaCuenta() }
        btnNuevoItem.setOnClickListener { mostrarDialogNuevoItem() }

        btnAgregaItem.setOnClickListener {
            val itemSeleccionado = spnItems.selectedItem?.toString() ?: ""
            val monto = txtValorItem.text.toString().trim()

            if (spnItems.selectedItemPosition == 0 || itemSeleccionado.isEmpty()) {
                Toast.makeText(requireContext(), "Por favor seleccione un ítem válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (monto.isEmpty()) {
                Toast.makeText(requireContext(), "Por favor ingrese el monto del ítem", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val registro = "$itemSeleccionado - $$monto"
            listaItemsAgregados.add(registro)
            adapterListado.notifyDataSetChanged()
            spnItems.setSelection(0)
            txtValorItem.text.clear()

            notificarTotalGastos()
        }

        btnEliminarItem.setOnClickListener {
            val pos = lstItemsSeleccionados.checkedItemPosition
            if (pos != ListView.INVALID_POSITION && pos >= 0 && pos < listaItemsAgregados.size) {
                val eliminado = listaItemsAgregados.removeAt(pos)
                adapterListado.notifyDataSetChanged()
                lstItemsSeleccionados.clearChoices()
                notificarTotalGastos()
                Toast.makeText(requireContext(), "Eliminado: $eliminado", Toast.LENGTH_SHORT).show()
            } else if (listaItemsAgregados.isNotEmpty()) {
                val eliminado = listaItemsAgregados.removeAt(listaItemsAgregados.size - 1)
                adapterListado.notifyDataSetChanged()
                lstItemsSeleccionados.clearChoices()
                notificarTotalGastos()
                Toast.makeText(requireContext(), "Eliminado: $eliminado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "No hay ítems para eliminar", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun cargarDatosDesdeBD() {
        // Cargar Simulaciones exclusivamente desde la tabla Simulaciones de la base de datos
        listaSimulacionesBD.clear()
        listaSimulaciones.clear()
        val simulaciones = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        if (simulaciones.isEmpty()) {
            listaSimulaciones.add("No hay simulaciones guardadas")
        } else {
            listaSimulaciones.add("Seleccione la simulación")
            listaSimulacionesBD.addAll(simulaciones)
            for (sim in simulaciones) {
                if (!listaSimulaciones.contains(sim.nombreSim)) {
                    listaSimulaciones.add(sim.nombreSim)
                }
            }
        }
        adapterSimulacion = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listaSimulaciones)
        adapterSimulacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSimulacion.adapter = adapterSimulacion

        // Cargar Cuentas exclusivamente desde la tabla Cuentas de la base de datos
        listaCuentasBD.clear()
        listaCuentas.clear()
        val cuentas = dbHelper.obtenerCuentas(idUsuarioActivo)
        if (cuentas.isEmpty()) {
            listaCuentas.add("No hay cuentas guardadas")
        } else {
            listaCuentas.add("Seleccione la cuenta")
            listaCuentasBD.addAll(cuentas)
            for (cta in cuentas) {
                if (!listaCuentas.contains(cta.nombreCuenta)) {
                    listaCuentas.add(cta.nombreCuenta)
                }
            }
        }
        adapterCuenta = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listaCuentas)
        adapterCuenta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnCuenta.adapter = adapterCuenta

        // Cargar Items exclusivamente desde la tabla Items de la base de datos
        listaItemsBD.clear()
        listaItems.clear()
        val items = dbHelper.obtenerItems(idUsuarioActivo)
        if (items.isEmpty()) {
            listaItems.add("No hay ítems guardados")
        } else {
            listaItems.add("Seleccione el Item")
            listaItemsBD.addAll(items)
            for (itemObj in items) {
                if (!listaItems.contains(itemObj.nombreItem)) {
                    listaItems.add(itemObj.nombreItem)
                }
            }
        }
        adapterItem = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listaItems)
        adapterItem.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnItems.adapter = adapterItem
    }

    fun recalcularYNotificar(mostrarToast: Boolean = true) {
        var total = 0L
        for (item in listaItemsAgregados) {
            val m = item.substringAfter("-").replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
            total += m
        }
        val totalCtaStr = txtTotalCuenta.text.toString().trim()
        val totalCuenta = totalCtaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
        listener?.onDatosSimulacionIngresados(total, totalCuenta)

        if (mostrarToast) {
            Toast.makeText(requireContext(), "Valores recalculados con éxito", Toast.LENGTH_SHORT).show()
        }
    }

    fun eliminarSimulacionSeleccionada() {
        val pos = spnSimulacion.selectedItemPosition
        if (pos <= 0 || pos > listaSimulacionesBD.size) {
            Toast.makeText(requireContext(), "Por favor seleccione una simulación válida para eliminar", Toast.LENGTH_SHORT).show()
            return
        }

        val simObj = listaSimulacionesBD.getOrNull(pos - 1)
        if (simObj != null) {
            val db = dbHelper.writableDatabase
            db.delete("DetallesSimulaciones", "idSim = ?", arrayOf(simObj.idSim.toString()))
            db.delete("Simulaciones", "idSim = ?", arrayOf(simObj.idSim.toString()))
            db.close()

            Toast.makeText(requireContext(), "Simulación '${simObj.nombreSim}' eliminada de la base de datos", Toast.LENGTH_SHORT).show()
        }

        cargarDatosDesdeBD()
        spnSimulacion.setSelection(0)
        txtTotalCuenta.setText("")
        listaItemsAgregados.clear()
        adapterListado.notifyDataSetChanged()

        recalcularYNotificar(mostrarToast = false)
    }

    private fun notificarTotalGastos() {
        var total = 0L
        for (item in listaItemsAgregados) {
            val m = item.substringAfter("-").replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
            total += m
        }
        val totalCtaStr = txtTotalCuenta.text.toString().trim()
        val totalCuenta = totalCtaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
        listener?.onDatosSimulacionIngresados(total, totalCuenta)
    }

    private fun mostrarDialogNuevaSimulacion() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Nueva Simulación")

        val input = EditText(requireContext())
        input.hint = "Ingrese nombre de la simulación"
        input.setPadding(40, 30, 40, 30)
        builder.setView(input)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaSim = input.text.toString().trim()
            if (nuevaSim.isNotEmpty()) {
                val idCtaDef = listaCuentasBD.firstOrNull()?.idCuenta ?: 1
                dbHelper.insertarSimulacion(idCtaDef, idUsuarioActivo, nuevaSim, 1000000, 0, 12, 1000000)
                cargarDatosDesdeBD()
                val index = listaSimulaciones.indexOf(nuevaSim)
                if (index != -1) {
                    spnSimulacion.setSelection(index)
                } else if (listaSimulaciones.size > 1) {
                    spnSimulacion.setSelection(1)
                }
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
        builder.show()
    }

    private fun mostrarDialogNuevaCuenta() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Nueva Cuenta y Valor")

        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(requireContext()).apply {
            hint = "Nombre de la nueva cuenta"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(requireContext()).apply {
            hint = "Monto/Valor de la cuenta"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaCta = inputNombre.text.toString().trim()
            val valorCta = inputValor.text.toString().trim()

            if (nuevaCta.isNotEmpty() && valorCta.isNotEmpty()) {
                val montoNum = valorCta.toIntOrNull() ?: 0
                dbHelper.insertarCuenta(idUsuarioActivo, nuevaCta, montoNum)
                cargarDatosDesdeBD()
                val index = listaCuentas.indexOf(nuevaCta)
                if (index != -1) {
                    spnCuenta.setSelection(index)
                } else if (listaCuentas.size > 1) {
                    spnCuenta.setSelection(1)
                }
                txtTotalCuenta.setText(valorCta)
                notificarTotalGastos()
            } else {
                Toast.makeText(requireContext(), "Debe ingresar nombre y valor de la cuenta", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
        builder.show()
    }

    private fun mostrarDialogNuevoItem() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Nuevo Ítem y Valor")

        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(requireContext()).apply {
            hint = "Nombre del nuevo ítem"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(requireContext()).apply {
            hint = "Monto/Valor del ítem"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevoItem = inputNombre.text.toString().trim()
            val valorItem = inputValor.text.toString().trim()

            if (nuevoItem.isNotEmpty() && valorItem.isNotEmpty()) {
                val montoNum = valorItem.toIntOrNull() ?: 0
                dbHelper.insertarItem(idUsuarioActivo, nuevoItem, montoNum)
                cargarDatosDesdeBD()
                val index = listaItems.indexOf(nuevoItem)
                if (index != -1) {
                    spnItems.setSelection(index)
                }
                txtValorItem.setText(valorItem)
            } else {
                Toast.makeText(requireContext(), "Debe ingresar nombre y valor del ítem", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
        builder.show()
    }
}
