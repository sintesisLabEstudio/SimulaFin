package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MenuSimActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_sim)

        val btnPasoApaso = findViewById<Button>(R.id.btnPasoApaso)
        val btnSintesis = findViewById<Button>(R.id.btnSintesis)
        val btnMenuPrincipal = findViewById<Button>(R.id.btnMenuPrincipal)

        btnPasoApaso.setOnClickListener {
            val intent = Intent(this, InputSimCuentaActivity::class.java)
            startActivity(intent)
        }

        btnSintesis.setOnClickListener {
            val intent = Intent(this, SimulacionActivity::class.java)
            startActivity(intent)
        }

        btnMenuPrincipal.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
