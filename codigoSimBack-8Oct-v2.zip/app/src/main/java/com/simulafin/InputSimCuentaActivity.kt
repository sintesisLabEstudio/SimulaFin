package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class InputSimCuentaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_sim_cuenta)

        val btnOkCuenta = findViewById<Button>(R.id.btnOkCuenta)
        btnOkCuenta.setOnClickListener {
            val intent = Intent(this, InputSimItemsActivity::class.java)
            startActivity(intent)
        }
    }
}
