package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class OutSimResumenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_out_sim_resumen)

        val btnItems = findViewById<Button>(R.id.btnItems)
        val btnSim = findViewById<Button>(R.id.btnSim)
        val btnMenu = findViewById<Button>(R.id.btnMenu)

        btnItems.setOnClickListener {
            val intent = Intent(this, InputSimItemsActivity::class.java)
            startActivity(intent)
        }

        btnSim.setOnClickListener {
            val intent = Intent(this, InputSimCuentaActivity::class.java)
            startActivity(intent)
        }

        btnMenu.setOnClickListener {
            val intent = Intent(this, MenuSimActivity::class.java)
            startActivity(intent)
        }
    }
}
