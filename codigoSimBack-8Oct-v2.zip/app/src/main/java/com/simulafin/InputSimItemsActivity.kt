package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class InputSimItemsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_sim_items)

        val btnOkItems = findViewById<Button>(R.id.btnOkItems)
        btnOkItems.setOnClickListener {
            val intent = Intent(this, OutSimResumenActivity::class.java)
            startActivity(intent)
        }
    }
}
