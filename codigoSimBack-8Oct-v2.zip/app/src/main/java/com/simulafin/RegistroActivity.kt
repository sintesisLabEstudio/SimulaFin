package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class RegistroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        val btnResapaldar = findViewById<Button>(R.id.btnResapaldar)
        val btnRecuperar = findViewById<Button>(R.id.btnRecuperar)

        btnResapaldar.setOnClickListener {
            val intent = Intent(this, RespaldoActivity::class.java)
            startActivity(intent)
        }

        btnRecuperar.setOnClickListener {
            val intent = Intent(this, RespaldoActivity::class.java)
            startActivity(intent)
        }
    }
}
