package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie
import com.simulafin.fragments.SimulacionInputFragment
import com.simulafin.fragments.SimulacionOutputFragment
import com.simulafin.interfaces.OnSimulacionDatosListener

class SimulacionActivity : AppCompatActivity(), OnSimulacionDatosListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simulacion)

        presentaPie("Vista de síntesis interactiva combinando entradas de datos y salida gráfica mediante Fragments.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }
    }

    override fun onDatosSimulacionIngresados(totalGastos: Long, totalCuenta: Long) {
        val fragmentOutput = supportFragmentManager.findFragmentById(R.id.containerOutput) as? SimulacionOutputFragment
        fragmentOutput?.actualizarResultados(totalGastos, totalCuenta)
    }

    override fun onSolicitarRecalcular() {
        val fragmentInput = supportFragmentManager.findFragmentById(R.id.containerInput) as? SimulacionInputFragment
        fragmentInput?.recalcularYNotificar()
    }

    override fun onSolicitarEliminarSimulacion() {
        val fragmentInput = supportFragmentManager.findFragmentById(R.id.containerInput) as? SimulacionInputFragment
        fragmentInput?.eliminarSimulacionSeleccionada()
    }
}
