package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Cuenta
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class CuentasActivity : AppCompatActivity() {

    private lateinit var spnSeleccionCta: Spinner
    private lateinit var txtNOmbreCta: EditText
    private lateinit var txtValCta: EditText
    private lateinit var lsvCtasUsuario: ListView
    private lateinit var adapterCuenta: ArrayAdapter<String>
    private lateinit var adapterListViewCtas: ArrayAdapter<String>
    private val listaCuentas = mutableListOf<String>()
    private val listaCtasUsuarioList = mutableListOf<String>()

    private lateinit var dbHelper: BaseDatosHelper
    private var idUsuarioActivo: Int = 1
    private val listaCuentasBD = mutableListOf<Cuenta>()

    private val mapaValoresCuentas = mutableMapOf<String, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cuentas)

        presentaPie("Gestión de Cuentas: Permite consultar y administrar las fuentes de fondos y saldos reales disponibles.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        dbHelper = BaseDatosHelper(this)
        idUsuarioActivo = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        spnSeleccionCta = findViewById(R.id.spnSeleccionCta)
        txtNOmbreCta = findViewById(R.id.txtNOmbreCta)
        txtValCta = findViewById(R.id.txtValCta)
        lsvCtasUsuario = findViewById(R.id.lsvCtasUsuario)

        val btnAgregaCta = findViewById<Button>(R.id.btnAgregaCta)
        val btnGrabaCta = findViewById<Button>(R.id.btnGrabaCta)
        val btnEliminaCta = findViewById<Button>(R.id.btnEliminaCta)

        adapterCuenta = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaCuentas
        )
        adapterCuenta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccionCta.adapter = adapterCuenta

        adapterListViewCtas = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_single_choice,
            listaCtasUsuarioList
        )
        lsvCtasUsuario.adapter = adapterListViewCtas
        lsvCtasUsuario.choiceMode = ListView.CHOICE_MODE_SINGLE

        // Listener para sincronizar la selección en lsvCtasUsuario con el Spinner y campos de edición
        lsvCtasUsuario.setOnItemClickListener { _, _, position, _ ->
            if (position >= 0 && position < listaCuentasBD.size) {
                spnSeleccionCta.setSelection(position + 1)
                val cuentaSel = listaCuentasBD[position]
                txtNOmbreCta.setText(cuentaSel.nombreCuenta)
                txtValCta.setText(cuentaSel.totalCuenta.toString())
            }
        }

        // Configurar lista de cuentas desde la base de datos SQLite y recursos del sistema
        cargarCuentasDesdeBD()

        // Listener del Spinner que llama a SeleccionCta()
        spnSeleccionCta.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                SeleccionCta(position)
                if (position > 0 && position <= listaCuentasBD.size) {
                    lsvCtasUsuario.setItemChecked(position - 1, true)
                } else {
                    lsvCtasUsuario.clearChoices()
                    adapterListViewCtas.notifyDataSetChanged()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }

        // Configurar txtValCta para seleccionar todo al hacer clic sin borrar
        txtValCta.setSelectAllOnFocus(true)
        txtValCta.setOnClickListener {
            txtValCta.selectAll()
        }

        // Botón "+" para agregar cuenta nueva mediante un diálogo con nombre y valor guardando en la tabla
        btnAgregaCta.setOnClickListener {
            mostrarDialogNuevaCuenta()
        }

        // Botón Grabar para guardar cambios en la cuenta seleccionada en la base de datos
        btnGrabaCta.setOnClickListener {
            val pos = spnSeleccionCta.selectedItemPosition
            val nombreEditado = txtNOmbreCta.text.toString().trim()
            val valEditadoStr = txtValCta.text.toString().trim()

            if (pos <= 0 || pos > listaCuentasBD.size) {
                Toast.makeText(this, "Seleccione una cuenta válida para guardar cambios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (nombreEditado.isEmpty() || valEditadoStr.isEmpty()) {
                Toast.makeText(this, "Nombre y valor no pueden estar vacíos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cuentaActual = listaCuentasBD[pos - 1]
            val totalEditado = valEditadoStr.toIntOrNull() ?: 0

            val exito = dbHelper.actualizarCuenta(cuentaActual.idCuenta, nombreEditado, totalEditado)

            if (exito) {
                cargarCuentasDesdeBD()
                spnSeleccionCta.setSelection(pos)
                lsvCtasUsuario.setItemChecked(pos - 1, true)
                txtNOmbreCta.setText(nombreEditado)
                txtValCta.setText(totalEditado.toString())
                Toast.makeText(this, "Cuenta '$nombreEditado' guardada con éxito ($$totalEditado)", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error al actualizar la cuenta en la base de datos", Toast.LENGTH_SHORT).show()
            }
        }

        // Botón Eliminar para eliminar la cuenta seleccionada de la tabla con confirmación
        btnEliminaCta.setOnClickListener {
            val pos = spnSeleccionCta.selectedItemPosition
            if (pos <= 0 || pos > listaCuentasBD.size) {
                Toast.makeText(this, "Seleccione una cuenta válida para eliminar", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cuentaActual = listaCuentasBD[pos - 1]
            mostrarDialogConfirmarEliminar(cuentaActual)
        }
    }

    private fun cargarCuentasDesdeBD() {
        listaCuentasBD.clear()
        listaCuentas.clear()
        listaCtasUsuarioList.clear()
        mapaValoresCuentas.clear()

        listaCuentas.add("Seleccione una cuenta...")

        var cuentas = dbHelper.obtenerCuentas(idUsuarioActivo)
        if (cuentas.isEmpty()) {
            val recursosCuentas = resources.getStringArray(R.array.lista_opciones_cuentas)
            val montosIniciales = arrayOf(1000000, 550000, 750000)
            for (i in 1 until recursosCuentas.size) {
                val nom = recursosCuentas[i]
                val valMonto = montosIniciales.getOrElse(i - 1) { 500000 }
                dbHelper.insertarCuenta(idUsuarioActivo, nom, valMonto)
            }
            cuentas = dbHelper.obtenerCuentas(idUsuarioActivo)
        }

        listaCuentasBD.addAll(cuentas)
        for (cta in listaCuentasBD) {
            listaCuentas.add(cta.nombreCuenta)
            listaCtasUsuarioList.add("${cta.nombreCuenta} - $${cta.totalCuenta}")
            mapaValoresCuentas[cta.nombreCuenta] = cta.totalCuenta.toString()
        }

        adapterCuenta.notifyDataSetChanged()
        adapterListViewCtas.notifyDataSetChanged()
        lsvCtasUsuario.clearChoices()
    }

    private fun mostrarDialogNuevaCuenta() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nueva Cuenta y Valor")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(this).apply {
            hint = "Nombre de la nueva cuenta"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(this).apply {
            hint = "Monto / Valor de la cuenta"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("Agregar") { dialog, _ ->
            val nombreNuevaCta = inputNombre.text.toString().trim()
            val valNuevaCtaStr = inputValor.text.toString().trim()

            if (nombreNuevaCta.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el nombre de la cuenta para agregar", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            if (valNuevaCtaStr.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el valor de la cuenta", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            if (listaCuentasBD.any { it.nombreCuenta.equals(nombreNuevaCta, ignoreCase = true) }) {
                Toast.makeText(this, "La cuenta '$nombreNuevaCta' ya existe", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            val montoNum = valNuevaCtaStr.toIntOrNull() ?: 0
            val exito = dbHelper.insertarCuenta(idUsuarioActivo, nombreNuevaCta, montoNum)

            if (exito) {
                cargarCuentasDesdeBD()
                val nuevaPos = listaCuentasBD.indexOfFirst { it.nombreCuenta == nombreNuevaCta }
                if (nuevaPos != -1) {
                    spnSeleccionCta.setSelection(nuevaPos + 1)
                    lsvCtasUsuario.setItemChecked(nuevaPos, true)
                    txtNOmbreCta.setText(nombreNuevaCta)
                    txtValCta.setText(montoNum.toString())
                }
                Toast.makeText(this, "Cuenta '$nombreNuevaCta' agregada con éxito", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error al guardar la cuenta en la base de datos", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun mostrarDialogConfirmarEliminar(cuenta: Cuenta) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Alerta de Eliminación")
        builder.setMessage("¿Está seguro de que desea eliminar la cuenta '${cuenta.nombreCuenta}'? Esta acción eliminará el registro de la base de datos.")

        builder.setPositiveButton("Eliminar") { dialog, _ ->
            val exito = dbHelper.eliminarCuenta(cuenta.idCuenta)
            if (exito) {
                cargarCuentasDesdeBD()
                spnSeleccionCta.setSelection(0)
                txtNOmbreCta.setText("")
                txtValCta.setText("")
                Toast.makeText(this, "Cuenta '${cuenta.nombreCuenta}' eliminada con éxito", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error al eliminar la cuenta de la base de datos", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    /**
     * Función SeleccionCta: presenta el nombre en txtNOmbreCta
     * y el valor/monto en txtValCta según la selección del Spinner.
     */
    fun SeleccionCta(position: Int) {
        val cuentaSel = listaCuentasBD.getOrNull(position - 1)
        if (position == 0 || cuentaSel == null) {
            txtNOmbreCta.setText("")
            txtValCta.setText("")
        } else {
            txtNOmbreCta.setText(cuentaSel.nombreCuenta)
            txtValCta.setText(cuentaSel.totalCuenta.toString())
        }
    }
}
