package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Simulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie
import java.io.File

class ConsultaSimulacionesActivity : AppCompatActivity() {

    //COMPONENTES
    private lateinit var spnSeleccionSim: Spinner
    private lateinit var txtValorSim: EditText
    private lateinit var txvResumenSimulacion: TextView
    private lateinit var adapterSimulacion: ArrayAdapter<String>
    private val listaSimulaciones = mutableListOf<String>()
    private val listaSimulacionesBD = mutableListOf<Simulacion>()

    //ON CREATE
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consulta_simulaciones)

        //presentapie()
        presentaPie("Módulo de consulta para revisar e inspeccionar simulaciones previamente guardadas en la base de datos.")

        //usuario activo
        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario Activo: ${SesionUsuario.usuarioActivo}"

        //COMPOINENTE BOTON HOME activo
        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        spnSeleccionSim = findViewById(R.id.spnSeleccionSim)
        txtValorSim = findViewById(R.id.txtValorSim)
        txvResumenSimulacion = findViewById(R.id.txvResumenSimulacion)

        val btnExportarJson = findViewById<Button>(R.id.btnExportarJson)
        val btnExportaCSV = findViewById<Button>(R.id.btnExportaCSV)
        val btnImprimir = findViewById<Button>(R.id.btnImprimir)
        val btnEnviar = findViewById<Button>(R.id.btnEnviar)

        // Cargar simulaciones exclusivamente desde la tabla Simulaciones de la base de datos
        val dbHelper = BaseDatosHelper(this)
        val idUsuarioActivo = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)
        listaSimulaciones.clear()
        listaSimulacionesBD.clear()

        val simulacionesBD = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        if (simulacionesBD.isEmpty()) {
            listaSimulaciones.add("No hay simulaciones guardadas")
            txvResumenSimulacion.text = "No hay datos de simulaciones guardadas en la tabla."
        } else {
            listaSimulaciones.add("Seleccione la simulación")
            listaSimulacionesBD.addAll(simulacionesBD)
            for (sim in simulacionesBD) {
                if (!listaSimulaciones.contains(sim.nombreSim)) {
                    listaSimulaciones.add(sim.nombreSim)
                }
            }
            txvResumenSimulacion.text = "Resumen de la simulación guardada..."
        }

        adapterSimulacion = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaSimulaciones
        )
        adapterSimulacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccionSim.adapter = adapterSimulacion

        // Listener del Spinner que llama a SeleccionSim()
        spnSeleccionSim.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                SeleccionSim(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }

        // Seleccionar todo el texto al hacer clic en txtValorSim para permitir editar
        txtValorSim.setSelectAllOnFocus(true)
        txtValorSim.setOnClickListener {
            txtValorSim.selectAll()
        }

        btnExportarJson.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            if (listaSimulacionesBD.isEmpty() || spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación válida a exportar", Toast.LENGTH_SHORT).show()
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                val defaultFileName = "simulacion_${sim.replace(" ", "_")}.json"
                val defaultFile = File(downloadsDir, defaultFileName)

                val builder = AlertDialog.Builder(this)
                builder.setTitle("Exportar Simulación a JSON")

                val input = EditText(this).apply {
                    setText(defaultFile.absolutePath)
                    setSelection(text.length)
                    setPadding(40, 30, 40, 30)
                }
                builder.setView(input)

                builder.setPositiveButton("Exportar") { dialog, _ ->
                    val rutaIngresada = input.text.toString().trim()
                    val rutaFinal = if (rutaIngresada.isNotEmpty()) rutaIngresada else defaultFile.absolutePath
                    val exito = exportaJson(rutaFinal)
                    if (exito) {
                        Toast.makeText(this, "Simulación exportada con éxito en:\n$rutaFinal", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "Error al exportar la simulación a JSON", Toast.LENGTH_SHORT).show()
                    }
                    dialog.dismiss()
                }

                builder.setNegativeButton("Cancelar") { dialog, _ ->
                    dialog.cancel()
                }

                builder.show()
            }
        }

        btnExportaCSV.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            if (listaSimulacionesBD.isEmpty() || spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación válida a exportar", Toast.LENGTH_SHORT).show()
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                val defaultFileName = "simulacion_${sim.replace(" ", "_")}.csv"
                val defaultFile = File(downloadsDir, defaultFileName)

                val builder = AlertDialog.Builder(this)
                builder.setTitle("Exportar Simulación a CSV")

                val input = EditText(this).apply {
                    setText(defaultFile.absolutePath)
                    setSelection(text.length)
                    setPadding(40, 30, 40, 30)
                }
                builder.setView(input)

                builder.setPositiveButton("Exportar") { dialog, _ ->
                    val rutaIngresada = input.text.toString().trim()
                    val rutaFinal = if (rutaIngresada.isNotEmpty()) rutaIngresada else defaultFile.absolutePath
                    val exito = exportaCSV(rutaFinal)
                    if (exito) {
                        Toast.makeText(this, "Simulación exportada a CSV con éxito en:\n$rutaFinal", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "Error al exportar la simulación a CSV", Toast.LENGTH_SHORT).show()
                    }
                    dialog.dismiss()
                }

                builder.setNegativeButton("Cancelar") { dialog, _ ->
                    dialog.cancel()
                }

                builder.show()
            }
        }

        btnImprimir.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            val valSim = txtValorSim.text.toString().trim()
            if (listaSimulacionesBD.isEmpty() || spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación válida para imprimir", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Enviando $sim a la impresora (Monto: $$valSim)...", Toast.LENGTH_SHORT).show()
            }
        }

        btnEnviar.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            val valSim = txtValorSim.text.toString().trim()
            if (listaSimulacionesBD.isEmpty() || spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación válida para enviar", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Enviando simulación $sim (Monto: $$valSim)...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //Función SeleccionSim: maneja la selección en spnSeleccionSim y
    // muestra los resultados guardados de esa simulación en la tabla Simulaciones, indicando si no hay datos.
    fun SeleccionSim(position: Int) {
        if (listaSimulacionesBD.isEmpty()) {
            txtValorSim.setText("")
            txvResumenSimulacion.text = "No hay datos de simulaciones guardadas en la tabla."
            return
        }

        if (position == 0) {
            txtValorSim.setText("")
            txvResumenSimulacion.text = "Resumen de la simulación guardada..."
        } else {
            val simObj = listaSimulacionesBD.getOrNull(position - 1)
            if (simObj != null) {
                txtValorSim.setText(simObj.totalDisponible.toString())
                val resumen = """
                    • Nombre Simulación: ${simObj.nombreSim}
                    • Fecha / Hora: ${simObj.fechaHoraSim}
                    • Monto Disponible: $${simObj.totalDisponible}
                    • Total Egresos: $${simObj.totalEgresos}
                    • Plazo (Meses): ${simObj.meses}
                    • Excedente: $${simObj.excedente}
                """.trimIndent()
                txvResumenSimulacion.text = resumen
            } else {
                txtValorSim.setText("")
                txvResumenSimulacion.text = "No hay datos disponibles para esta simulación."
            }
        }
    }

    /**
     * Función exportaJson: Exporta los datos de la simulación actual en formato JSON a la ruta especificada.
     * Si la ruta está vacía, utiliza por defecto la carpeta de Descargas (Downloads).
     */
    fun exportaJson(ruta: String): Boolean {
        return try {
            val destino = if (ruta.isNotBlank()) {
                File(ruta)
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                File(downloadsDir, "simulacion_export.json")
            }

            destino.parentFile?.mkdirs()

            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            val valSim = txtValorSim.text.toString().trim()
            val usuario = SesionUsuario.usuarioActivo

            val jsonContent = """
                {
                  "usuario": "$usuario",
                  "simulacion": "$sim",
                  "valor": "$valSim"
                }
            """.trimIndent()

            destino.writeText(jsonContent)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Función exportaCSV: Exportar los datos de la simulación actual en formato CSV a la ruta especificada.
     * Si la ruta está vacía, utiliza por defecto la carpeta de Descargas (Downloads).
     */
    fun exportaCSV(ruta: String): Boolean {
        return try {
            val destino = if (ruta.isNotBlank()) {
                File(ruta)
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                File(downloadsDir, "simulacion_export.csv")
            }

            destino.parentFile?.mkdirs()

            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            val valSim = txtValorSim.text.toString().trim()
            val usuario = SesionUsuario.usuarioActivo

            val csvContent = "Usuario,Simulacion,Valor\n\"$usuario\",\"$sim\",\"$valSim\"\n"

            destino.writeText(csvContent)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
