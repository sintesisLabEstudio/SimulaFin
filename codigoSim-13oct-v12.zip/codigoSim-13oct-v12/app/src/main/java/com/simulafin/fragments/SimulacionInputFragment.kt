package com.simulafin.fragments

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.simulafin.R
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Cuenta
import com.simulafin.clases.Item
import com.simulafin.clases.Simulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.interfaces.OnSimulacionDatosListener

class SimulacionInputFragment : Fragment() {
    //DEFINICION COMPONENTES VAR
    //componente simulacion
    private lateinit var spnSimulacion: Spinner
    private lateinit var adapterSimulacion: ArrayAdapter<String>
    private val listaSimulaciones = mutableListOf<String>()
    private val listaSimulacionesBD = mutableListOf<Simulacion>()

    //componente cuentas
    private lateinit var spnCuenta: Spinner
    private lateinit var adapterCuenta: ArrayAdapter<String>
    private val listaCuentas = mutableListOf<String>()
    private val listaCuentasBD = mutableListOf<Cuenta>()

    /*
    // MAPA cuentas para simulacion (comentado por migración a lectura desde tabla Cuentas de la BD)
    private val mapaValoresCuentas = mutableMapOf(
        "Cuenta Sercotec" to "1000000",
        "Cuenta Personal" to "550000",
        "Cuenta Ahorro" to "750000",
        "Cuenta Fan" to "750000"
    )
    */

    //COMPONENTES spiner,ListaItems
    private lateinit var spnItems: Spinner
    private lateinit var adapterItem: ArrayAdapter<String>
    private val listaItems = mutableListOf<String>()
    private val listaItemsBD = mutableListOf<Item>()

    /*
    // MAPA items (comentado por migración a lectura desde tabla Items de la BD)
    private val mapaValoresItems = mutableMapOf(
        "luz" to "20000",
        "Movilización" to "10000",
        "Salud" to "30000",
        "agua" to "15000",
        "arriendo" to "250000",
        "celular" to "15000"
    )
    */

    //COMPONENTES
    private lateinit var txtTotalCuenta: EditText
    private lateinit var txtValorItem: EditText
    private lateinit var lstItemsSeleccionados: ListView
    private lateinit var adapterListado: ArrayAdapter<String>
    private val listaItemsAgregados = mutableListOf<String>()
    private var listener: OnSimulacionDatosListener? = null

    private lateinit var dbHelper: BaseDatosHelper
    private var idUsuarioActivo: Int = 1

    //ONATACH
    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnSimulacionDatosListener) {
            listener = context
        }
    }

    //ON DETACH
    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    //On CREATE
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_simulacion_input, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = BaseDatosHelper(requireContext())
        idUsuarioActivo = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)

        //componentes
        spnSimulacion = view.findViewById(R.id.spnSimulacion)
        spnCuenta = view.findViewById(R.id.spnCuenta)
        spnItems = view.findViewById(R.id.spnItems)

        txtTotalCuenta = view.findViewById(R.id.txtTotalCuenta)
        txtValorItem = view.findViewById(R.id.txtValorItem)

        //boton programable
        val btnNuevaSim = view.findViewById<Button>(R.id.btnNuevaSim)
        val btnNuevaCuenta = view.findViewById<Button>(R.id.btnNuevaCuenta)
        val btnNuevoItem = view.findViewById<Button>(R.id.btnNuevoItem)
        val btnAgregaItem = view.findViewById<Button>(R.id.btnAgregaItem)
        val btnEliminarItem = view.findViewById<Button>(R.id.btnAgregaItem2)
        lstItemsSeleccionados = view.findViewById(R.id.lstItemsSeleccionados)

        // Configurar adaptadores y cargar datos desde las tablas correspondientes de la BD
        cargarDatosDesdeBD()

        // Configurar ListView de ítems seleccionados
        adapterListado = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_single_choice,
            listaItemsAgregados
        )
        lstItemsSeleccionados.adapter = adapterListado
        lstItemsSeleccionados.choiceMode = ListView.CHOICE_MODE_SINGLE

        // Listeners para actualizar montos según la selección de los Spinners
        spnSimulacion.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                recalcularYNotificar(mostrarToast = false)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        spnCuenta.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    txtTotalCuenta.setText("")
                } else {
                    val cuentaObj = listaCuentasBD.getOrNull(position - 1)
                    if (cuentaObj != null) {
                        txtTotalCuenta.setText(cuentaObj.totalCuenta.toString())
                    }
                }
                notificarTotalGastos()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        spnItems.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    txtValorItem.setText("")
                } else {
                    val itemObj = listaItemsBD.getOrNull(position - 1)
                    if (itemObj != null) {
                        txtValorItem.setText(itemObj.valorItem.toString())
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Seleccionar todo al hacer clic en campos de texto
        txtTotalCuenta.setSelectAllOnFocus(true)
        txtTotalCuenta.setOnClickListener { txtTotalCuenta.selectAll() }

        txtValorItem.setSelectAllOnFocus(true)
        txtValorItem.setOnClickListener { txtValorItem.selectAll() }

        // Programación de los botones con texto '+'
        btnNuevaSim.setOnClickListener { mostrarDialogNuevaSimulacion() }
        btnNuevaCuenta.setOnClickListener { mostrarDialogNuevaCuenta() }
        btnNuevoItem.setOnClickListener { mostrarDialogNuevoItem() }

        // Evento Agregar Ítem seleccionado a la lista
        btnAgregaItem.setOnClickListener {
            val itemSeleccionado = spnItems.selectedItem?.toString() ?: ""
            val monto = txtValorItem.text.toString().trim()

            if (spnItems.selectedItemPosition == 0 || itemSeleccionado.isEmpty()) {
                Toast.makeText(requireContext(), "Por favor seleccione un ítem válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (monto.isEmpty()) {
                Toast.makeText(requireContext(), "Por favor ingrese el monto del ítem", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val registro = "$itemSeleccionado - $$monto"
            listaItemsAgregados.add(registro)
            adapterListado.notifyDataSetChanged()
            spnItems.setSelection(0)
            txtValorItem.text.clear()

            notificarTotalGastos()
        }

        // Evento Eliminar Ítem seleccionado
        btnEliminarItem.setOnClickListener {
            val pos = lstItemsSeleccionados.checkedItemPosition
            if (pos != ListView.INVALID_POSITION && pos >= 0 && pos < listaItemsAgregados.size) {
                val eliminado = listaItemsAgregados.removeAt(pos)
                adapterListado.notifyDataSetChanged()
                lstItemsSeleccionados.clearChoices()
                notificarTotalGastos()
                Toast.makeText(requireContext(), "Eliminado: $eliminado", Toast.LENGTH_SHORT).show()
            } else if (listaItemsAgregados.isNotEmpty()) {
                val eliminado = listaItemsAgregados.removeAt(listaItemsAgregados.size - 1)
                adapterListado.notifyDataSetChanged()
                lstItemsSeleccionados.clearChoices()
                notificarTotalGastos()
                Toast.makeText(requireContext(), "Eliminado: $eliminado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "No hay ítems para eliminar", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun cargarDatosDesdeBD() {
        // Cargar Simulaciones desde la tabla Simulaciones
        listaSimulacionesBD.clear()
        listaSimulaciones.clear()
        listaSimulaciones.add("Seleccione la simulación")
        var simulaciones = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        if (simulaciones.isEmpty()) {
            val recursosSim = resources.getStringArray(R.array.lista_opciones_simulacion)
            for (i in 1 until recursosSim.size) {
                dbHelper.insertarSimulacion(1, idUsuarioActivo, recursosSim[i], 1000000, 0, 12, 1000000)
            }
            simulaciones = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        }
        listaSimulacionesBD.addAll(simulaciones)
        for (sim in listaSimulacionesBD) {
            listaSimulaciones.add(sim.nombreSim)
        }
        adapterSimulacion = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listaSimulaciones)
        adapterSimulacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSimulacion.adapter = adapterSimulacion

        // Cargar Cuentas desde la tabla Cuentas
        listaCuentasBD.clear()
        listaCuentas.clear()
        listaCuentas.add("Seleccione la cuenta")
        var cuentas = dbHelper.obtenerCuentas(idUsuarioActivo)
        if (cuentas.isEmpty()) {
            val recursosCuentas = resources.getStringArray(R.array.lista_opciones_cuentas)
            val montosIni = arrayOf(1000000, 550000, 750000)
            for (i in 1 until recursosCuentas.size) {
                dbHelper.insertarCuenta(idUsuarioActivo, recursosCuentas[i], montosIni.getOrElse(i - 1) { 500000 })
            }
            cuentas = dbHelper.obtenerCuentas(idUsuarioActivo)
        }
        listaCuentasBD.addAll(cuentas)
        for (cta in listaCuentasBD) {
            listaCuentas.add(cta.nombreCuenta)
        }
        adapterCuenta = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listaCuentas)
        adapterCuenta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnCuenta.adapter = adapterCuenta

        // Cargar Items desde la tabla Items
        listaItemsBD.clear()
        listaItems.clear()
        listaItems.add("Seleccione el Item")
        var items = dbHelper.obtenerItems(idUsuarioActivo)
        if (items.isEmpty()) {
            val recursosItems = resources.getStringArray(R.array.lista_items)
            val valoresIni = arrayOf(20000, 15000, 250000, 10000)
            for (i in 1 until recursosItems.size) {
                dbHelper.insertarItem(idUsuarioActivo, recursosItems[i], valoresIni.getOrElse(i - 1) { 10000 })
            }
            items = dbHelper.obtenerItems(idUsuarioActivo)
        }
        listaItemsBD.addAll(items)
        for (itemObj in listaItemsBD) {
            listaItems.add(itemObj.nombreItem)
        }
        adapterItem = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listaItems)
        adapterItem.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnItems.adapter = adapterItem
    }

    /**
     * Recalcula el total de gastos e importe de la cuenta y los notifica
     * al listener (Activity) para que actualice la vista de salida (OutputFragment).
     */
    fun recalcularYNotificar(mostrarToast: Boolean = true) {
        var total = 0L
        for (item in listaItemsAgregados) {
            val m = item.substringAfter("-").replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
            total += m
        }
        val totalCtaStr = txtTotalCuenta.text.toString().trim()
        val totalCuenta = totalCtaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
        listener?.onDatosSimulacionIngresados(total, totalCuenta)

        if (mostrarToast) {
            Toast.makeText(requireContext(), "Valores recalculados con éxito", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Elimina la simulación actualmente seleccionada en el Spinner superior (spnSimulacion).
     */
    fun eliminarSimulacionSeleccionada() {
        val pos = spnSimulacion.selectedItemPosition
        if (pos <= 0 || pos >= listaSimulaciones.size) {
            Toast.makeText(requireContext(), "Por favor seleccione una simulación válida para eliminar", Toast.LENGTH_SHORT).show()
            return
        }

        val simEliminada = listaSimulaciones.removeAt(pos)
        adapterSimulacion.notifyDataSetChanged()
        spnSimulacion.setSelection(0)

        Toast.makeText(requireContext(), "Simulación '$simEliminada' eliminada de la base de datos", Toast.LENGTH_SHORT).show()

        recalcularYNotificar(mostrarToast = false)
    }

    private fun notificarTotalGastos() {
        var total = 0L
        for (item in listaItemsAgregados) {
            val m = item.substringAfter("-").replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
            total += m
        }
        val totalCtaStr = txtTotalCuenta.text.toString().trim()
        val totalCuenta = totalCtaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
        listener?.onDatosSimulacionIngresados(total, totalCuenta)
    }

    private fun mostrarDialogNuevaSimulacion() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Nueva Simulación")

        val input = EditText(requireContext())
        input.hint = "Ingrese nombre de la simulación"
        input.setPadding(40, 30, 40, 30)
        builder.setView(input)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaSim = input.text.toString().trim()
            if (nuevaSim.isNotEmpty()) {
                val idCtaDef = listaCuentasBD.firstOrNull()?.idCuenta ?: 1
                dbHelper.insertarSimulacion(idCtaDef, idUsuarioActivo, nuevaSim, 1000000, 0, 12, 1000000)
                cargarDatosDesdeBD()
                val index = listaSimulaciones.indexOf(nuevaSim)
                if (index != -1) {
                    spnSimulacion.setSelection(index)
                } else if (listaSimulaciones.size > 1) {
                    spnSimulacion.setSelection(1)
                }
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
        builder.show()
    }

    private fun mostrarDialogNuevaCuenta() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Nueva Cuenta y Valor")

        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(requireContext()).apply {
            hint = "Nombre de la nueva cuenta"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(requireContext()).apply {
            hint = "Monto/Valor de la cuenta"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaCta = inputNombre.text.toString().trim()
            val valorCta = inputValor.text.toString().trim()

            if (nuevaCta.isNotEmpty() && valorCta.isNotEmpty()) {
                val montoNum = valorCta.toIntOrNull() ?: 0
                dbHelper.insertarCuenta(idUsuarioActivo, nuevaCta, montoNum)
                cargarDatosDesdeBD()
                val index = listaCuentas.indexOf(nuevaCta)
                if (index != -1) {
                    spnCuenta.setSelection(index)
                } else if (listaCuentas.size > 1) {
                    spnCuenta.setSelection(1)
                }
                txtTotalCuenta.setText(valorCta)
                notificarTotalGastos()
            } else {
                Toast.makeText(requireContext(), "Debe ingresar nombre y valor de la cuenta", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
        builder.show()
    }

    private fun mostrarDialogNuevoItem() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Nuevo Ítem y Valor")

        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(requireContext()).apply {
            hint = "Nombre del nuevo ítem"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(requireContext()).apply {
            hint = "Monto/Valor del ítem"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevoItem = inputNombre.text.toString().trim()
            val valorItem = inputValor.text.toString().trim()

            if (nuevoItem.isNotEmpty() && valorItem.isNotEmpty()) {
                val montoNum = valorItem.toIntOrNull() ?: 0
                dbHelper.insertarItem(idUsuarioActivo, nuevoItem, montoNum)
                cargarDatosDesdeBD()
                spnItems.setSelection(listaItems.size - 1)
                txtValorItem.setText(valorItem)
            } else {
                Toast.makeText(requireContext(), "Debe ingresar nombre y valor del ítem", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
        builder.show()
    }
}
