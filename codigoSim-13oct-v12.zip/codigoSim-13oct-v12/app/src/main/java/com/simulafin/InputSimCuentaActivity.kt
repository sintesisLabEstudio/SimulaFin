package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Cuenta
import com.simulafin.clases.Simulacion
import com.simulafin.clases.SesionSimulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class InputSimCuentaActivity : AppCompatActivity() {

    private lateinit var dbHelper: BaseDatosHelper
    private var idUsuarioActivo: Int = 1

    private lateinit var spnSeleccioSim: Spinner
    private lateinit var adapterSimulacion: ArrayAdapter<String>
    private val listaSimulaciones = mutableListOf<String>()
    private val listaSimulacionesBD = mutableListOf<Simulacion>()

    private lateinit var spnSeleccionCuenta: Spinner
    private lateinit var adapterCuenta: ArrayAdapter<String>
    private val listaCuentas = mutableListOf<String>()
    private val listaCuentasBD = mutableListOf<Cuenta>()
    
    // Mapa para referenciar cada cuenta con su respectivo valor/monto
    private val mapaValoresCuentas = mutableMapOf<String, String>()

    private lateinit var txtValorCuenta: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_sim_cuenta)

        dbHelper = BaseDatosHelper(this)
        idUsuarioActivo = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)

        presentaPie("Aqui seleccionaremos la simulacion o crearemos una nueva simulacion, seleccionando la cuenta en la que simularemos que presentara el monto disponible de esa cuenta...")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
        }

        val btnOkCuenta = findViewById<Button>(R.id.btnOkCuenta)
        val btnNuevaSim = findViewById<Button>(R.id.btnNuevaSim)
        val btnNuevaCuenta = findViewById<Button>(R.id.btnNuevaCuenta)
        val btnGrabaSim = findViewById<Button>(R.id.btnGrabaSim)

        spnSeleccioSim = findViewById(R.id.spnSeleccioSim)
        spnSeleccionCuenta = findViewById(R.id.spnSeleccionCuenta)
        txtValorCuenta = findViewById(R.id.txtValorCuenta)

        // Configuración de adaptadores para alimentarse de sus tablas correspondientes
        adapterSimulacion = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaSimulaciones
        )
        adapterSimulacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccioSim.adapter = adapterSimulacion

        adapterCuenta = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaCuentas
        )
        adapterCuenta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccionCuenta.adapter = adapterCuenta

        // Cargar datos desde las tablas de la base de datos
        cargarDatosDesdeBD()

        // Listener para actualizar el monto en txtValorCuenta según la cuenta seleccionada
        spnSeleccionCuenta.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val cuentaSeleccionada = listaCuentas.getOrNull(position) ?: ""
                if (position == 0) {
                    txtValorCuenta.setText("")
                } else {
                    val valorRef = mapaValoresCuentas[cuentaSeleccionada] ?: ""
                    txtValorCuenta.setText(valorRef)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }

        txtValorCuenta.setSelectAllOnFocus(true)
        txtValorCuenta.setOnClickListener {
            txtValorCuenta.selectAll()
        }

        btnNuevaSim.setOnClickListener {
            mostrarDialogNuevaSimulacion()
        }

        btnNuevaCuenta.setOnClickListener {
            mostrarDialogNuevaCuenta()
        }

        btnGrabaSim?.setOnClickListener {
            val cuentaSeleccionada = spnSeleccionCuenta.selectedItem?.toString() ?: ""
            val nuevoValor = txtValorCuenta.text.toString().trim()

            if (spnSeleccionCuenta.selectedItemPosition == 0 || cuentaSeleccionada.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una cuenta para guardar el valor", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (nuevoValor.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el valor de la cuenta", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            mapaValoresCuentas[cuentaSeleccionada] = nuevoValor
            val cuentaObj = listaCuentasBD.find { it.nombreCuenta == cuentaSeleccionada }
            if (cuentaObj != null) {
                dbHelper.actualizarCuenta(cuentaObj.idCuenta, cuentaObj.nombreCuenta, nuevoValor.toIntOrNull() ?: 0)
            }
            Toast.makeText(this, "Valor guardado para $cuentaSeleccionada: $$nuevoValor", Toast.LENGTH_SHORT).show()
        }

        btnOkCuenta.setOnClickListener {
            grabarSeleccionCuentaSim()
        }
    }

    private fun cargarDatosDesdeBD() {
        // Cargar Simulaciones desde la tabla Simulaciones
        listaSimulacionesBD.clear()
        listaSimulaciones.clear()
        listaSimulaciones.add("Seleccione la simulación")
        var simulaciones = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        if (simulaciones.isEmpty()) {
            val recursosSim = resources.getStringArray(R.array.lista_opciones_simulacion)
            for (i in 1 until recursosSim.size) {
                dbHelper.insertarSimulacion(1, idUsuarioActivo, recursosSim[i], 1000000, 0, 12, 1000000)
            }
            simulaciones = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        }
        listaSimulacionesBD.addAll(simulaciones)
        for (sim in listaSimulacionesBD) {
            listaSimulaciones.add(sim.nombreSim)
        }
        adapterSimulacion.notifyDataSetChanged()

        // Cargar Cuentas desde la tabla Cuentas
        listaCuentasBD.clear()
        listaCuentas.clear()
        mapaValoresCuentas.clear()
        listaCuentas.add("Seleccione la cuenta")
        var cuentas = dbHelper.obtenerCuentas(idUsuarioActivo)
        if (cuentas.isEmpty()) {
            val recursosCuentas = resources.getStringArray(R.array.lista_opciones_cuentas)
            val montosIniciales = arrayOf(1000000, 550000, 750000)
            for (i in 1 until recursosCuentas.size) {
                val nom = recursosCuentas[i]
                val valMonto = montosIniciales.getOrElse(i - 1) { 500000 }
                dbHelper.insertarCuenta(idUsuarioActivo, nom, valMonto)
            }
            cuentas = dbHelper.obtenerCuentas(idUsuarioActivo)
        }
        listaCuentasBD.addAll(cuentas)
        for (cta in listaCuentasBD) {
            listaCuentas.add(cta.nombreCuenta)
            mapaValoresCuentas[cta.nombreCuenta] = cta.totalCuenta.toString()
        }
        adapterCuenta.notifyDataSetChanged()
    }

    private fun mostrarDialogNuevaSimulacion() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nueva Simulación")

        val input = EditText(this)
        input.hint = "Ingrese nombre de la simulación"
        input.setPadding(40, 30, 40, 30)
        builder.setView(input)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaSim = input.text.toString().trim()
            if (nuevaSim.isNotEmpty()) {
                val idCtaDef = listaCuentasBD.firstOrNull()?.idCuenta ?: 1
                dbHelper.insertarSimulacion(idCtaDef, idUsuarioActivo, nuevaSim, 1000000, 0, 12, 1000000)
                cargarDatosDesdeBD()
                val index = listaSimulaciones.indexOf(nuevaSim)
                if (index != -1) {
                    spnSeleccioSim.setSelection(index)
                } else if (listaSimulaciones.size > 1) {
                    spnSeleccioSim.setSelection(1)
                }
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun mostrarDialogNuevaCuenta() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nueva Cuenta y Valor")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(this).apply {
            hint = "Nombre de la nueva cuenta"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(this).apply {
            hint = "Monto/Valor de la cuenta"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaCta = inputNombre.text.toString().trim()
            val valorCta = inputValor.text.toString().trim()

            if (nuevaCta.isNotEmpty() && valorCta.isNotEmpty()) {
                val montoNum = valorCta.toIntOrNull() ?: 0
                dbHelper.insertarCuenta(idUsuarioActivo, nuevaCta, montoNum)
                cargarDatosDesdeBD()
                val index = listaCuentas.indexOf(nuevaCta)
                if (index != -1) {
                    spnSeleccionCuenta.setSelection(index)
                } else if (listaCuentas.size > 1) {
                    spnSeleccionCuenta.setSelection(1)
                }
                txtValorCuenta.setText(valorCta)
            } else {
                Toast.makeText(this, "Debe ingresar nombre y valor de la cuenta", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    /**
     * Función grabarSeleccionCuentaSim: Graba a partir de txtValorCuenta en el registro simulación
     * su nuevo nombre, cuenta y valor indicado, dando un mensaje y luego va a la vista que tiene programada.
     */
    fun grabarSeleccionCuentaSim() {
        val simulacionSeleccionada = spnSeleccioSim.selectedItem?.toString() ?: ""
        val cuentaSeleccionada = spnSeleccionCuenta.selectedItem?.toString() ?: ""
        val valorCuenta = txtValorCuenta.text.toString().trim()

        if (spnSeleccioSim.selectedItemPosition == 0 || simulacionSeleccionada.isEmpty()) {
            Toast.makeText(this, "Por favor seleccione una simulación", Toast.LENGTH_SHORT).show()
            return
        }

        if (spnSeleccionCuenta.selectedItemPosition == 0 || cuentaSeleccionada.isEmpty()) {
            Toast.makeText(this, "Por favor seleccione o ingrese una cuenta", Toast.LENGTH_SHORT).show()
            return
        }

        if (valorCuenta.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese el monto para la cuenta", Toast.LENGTH_SHORT).show()
            return
        }

        // Grabar a partir de txtValorCuenta en el registro simulación
        val montoNum = valorCuenta.toIntOrNull() ?: 0
        val cuentaObj = listaCuentasBD.find { it.nombreCuenta == cuentaSeleccionada }
        val idCta = cuentaObj?.idCuenta ?: 1

        dbHelper.insertarSimulacion(idCta, idUsuarioActivo, simulacionSeleccionada, montoNum, 0, 12, montoNum)

        SesionSimulacion.simulacion = simulacionSeleccionada
        SesionSimulacion.cuenta = cuentaSeleccionada
        SesionSimulacion.valorCuenta = valorCuenta
        mapaValoresCuentas[cuentaSeleccionada] = valorCuenta

        Toast.makeText(
            this,
            "Simulación '$simulacionSeleccionada' grabada con cuenta '$cuentaSeleccionada' y valor de simulación: $$valorCuenta",
            Toast.LENGTH_LONG
        ).show()

        val intent = Intent(this, InputSimItemsActivity::class.java).apply {
            putExtra("EXTRA_SIMULACION", simulacionSeleccionada)
            putExtra("EXTRA_CUENTA", cuentaSeleccionada)
            putExtra("EXTRA_VALOR_CUENTA", valorCuenta)
        }
        startActivity(intent)
    }
}
