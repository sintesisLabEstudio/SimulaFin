package com.simulafin.clases

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BaseDatosHelper(private val context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    /**
     * Verifica e inicializa la base de datos 'simulafin.db' y sus tablas.
     * Vacía explícitamente la tabla Usuarios en el archivo simulafin.db del dispositivo
     * para garantizar que comience con 0 registros (simulando el celular nuevo).
     * @return true si la base fue creada por primera vez, false si ya existía.
     */
    fun generaBaseDatos(): Boolean {
        val dbFile: File = context.getDatabasePath(DATABASE_NAME)
        val esNueva = !dbFile.exists()
        val db = this.writableDatabase
        CreacionBaseDatosSimula(db)
        /*
        // COMENTADO PARA PERMITIR PERSISTENCIA DE USUARIOS REGISTRADOS EN DISCO:
        if (esNueva) {
            vaciarTablaUsuarios(db)
            //BORRAR hasta entender el concepto
        }
        */
        db.close()
        return esNueva
    }

    override fun onCreate(db: SQLiteDatabase?) {
        if (db != null) {
            CreacionBaseDatosSimula(db)
            // vaciarTablaUsuarios(db) // COMENTADO PARA PERMITIR PERSISTENCIA
        }
    }

    /**
     * Crea todas las tablas en la base de datos basándose en las clases del sistema:
     * Usuarios, Cuentas, Items, Simulaciones, DetallesSimulaciones.
     * La tabla Usuarios inicia completamente vacía.
     */
    fun CreacionBaseDatosSimula(db: SQLiteDatabase? = null) {
        val database = db ?: this.writableDatabase

        // Eliminar tablas antiguas en singular de versiones anteriores si existen
        try { database.execSQL("DROP TABLE IF EXISTS DetalleSimulacion;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Simulacion;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Cuenta;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Item;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Usuario;") } catch (e: Exception) { e.printStackTrace() }

        // Tabla Usuarios (Totalmente vacía al inicio con soporte para fechaHoraUsuario, esAdmin y preferenciaTema)
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Usuarios (
                idUsuario INTEGER PRIMARY KEY AUTOINCREMENT,
                nombreUsuario TEXT NOT NULL UNIQUE,
                claveUsuario TEXT NOT NULL,
                fechaHoraUsuario TEXT NOT NULL DEFAULT '',
                esAdmin INTEGER DEFAULT 0,
                preferenciaTema TEXT DEFAULT ''
            )
            """.trimIndent()
        )

        // Tabla Cuentas
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Cuentas (
                idCuenta INTEGER PRIMARY KEY AUTOINCREMENT,
                idUsuario INTEGER NOT NULL,
                nombreCuenta TEXT NOT NULL,
                totalCuenta INTEGER NOT NULL,
                fechaHoraCuenta TEXT NOT NULL DEFAULT '',
                FOREIGN KEY (idUsuario) REFERENCES Usuarios(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // Tabla Items
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Items (
                idItem INTEGER PRIMARY KEY AUTOINCREMENT,
                idUsuario INTEGER NOT NULL,
                nombreItem TEXT NOT NULL,
                valorItem INTEGER NOT NULL,
                FOREIGN KEY (idUsuario) REFERENCES Usuarios(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // Tabla Simulaciones
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Simulaciones (
                idSim INTEGER PRIMARY KEY AUTOINCREMENT,
                idCuenta INTEGER NOT NULL,
                idUsuario INTEGER NOT NULL,
                nombreSim TEXT NOT NULL,
                fechaHoraSim TEXT NOT NULL,
                totalDisponible INTEGER NOT NULL,
                totalEgresos INTEGER NOT NULL,
                meses INTEGER NOT NULL,
                excedente INTEGER NOT NULL,
                FOREIGN KEY (idCuenta) REFERENCES Cuentas(idCuenta) ON DELETE CASCADE,
                FOREIGN KEY (idUsuario) REFERENCES Usuarios(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // Tabla DetallesSimulaciones
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS DetallesSimulaciones (
                idDetalle INTEGER PRIMARY KEY AUTOINCREMENT,
                idSim INTEGER NOT NULL,
                idItem INTEGER,
                nombreItem TEXT NOT NULL,
                valorItem INTEGER NOT NULL,
                FOREIGN KEY (idSim) REFERENCES Simulaciones(idSim) ON DELETE CASCADE,
                FOREIGN KEY (idItem) REFERENCES Items(idItem) ON DELETE SET NULL
            )
            """.trimIndent()
        )
    }

    // Vacía completamente la tabla Usuarios y reinicia la secuencia de forma segura usando transacciones.
    fun vaciarTablaUsuarios(db: SQLiteDatabase? = null) {
        val database = db ?: this.writableDatabase
        val isInternalDb = (db == null)
        try {
            if (isInternalDb) database.beginTransaction()
            database.delete("Usuarios", null, null)
            try {
                database.delete("sqlite_sequence", "name=?", arrayOf("Usuarios"))
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (isInternalDb) database.setTransactionSuccessful()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (isInternalDb) {
                try {
                    database.endTransaction()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                database.close()
            }
        }
    }

    // Método radical: elimina por completo el archivo de la base de datos del disco del dispositivo.
    fun vaciarTodaLaBaseDatos() {
        try {
            context.deleteDatabase(DATABASE_NAME)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


     //Devuelve la cantidad de usuarios guardados en la tabla Usuarios.
    fun obtenerCantidadUsuarios(): Int {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM Usuarios", null)
        val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        db.close()
        return count
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Migración segura preservando los datos existentes de los usuarios
        if (oldVersion < 2) {
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN esAdmin INTEGER DEFAULT 0;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN preferenciaTema TEXT DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 3) {
            try { db?.execSQL("ALTER TABLE Simulaciones ADD COLUMN idUsuario INTEGER NOT NULL DEFAULT 0;") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 4) {
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN fechaHoraUsuario TEXT NOT NULL DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("ALTER TABLE Cuentas ADD COLUMN fechaHoraCuenta TEXT NOT NULL DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 5) {
            try { db?.execSQL("DROP TABLE IF EXISTS DetalleSimulacion;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Simulacion;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Cuenta;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Item;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Usuario;") } catch (e: Exception) { e.printStackTrace() }
        }
    }

    // =========================================================================
    // MÉTODOS DE BASE DE DATOS PARA USUARIOS
    // =========================================================================

    /**
     * Registra un nuevo usuario en la tabla Usuarios.
     * @return true si el usuario se guardó correctamente en la BD, false si ya existía o falló.
     */
    fun registrarUsuario(nombre: String, clave: String): Boolean {
        if (existeUsuario(nombre)) return false

        val db = this.writableDatabase
        try {
            val cursor = db.rawQuery("SELECT COUNT(*) FROM Usuarios", null)
            val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
            cursor.close()

            val esAdminVal = if (count == 0) 1 else 0
            val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

            val values = ContentValues().apply {
                put("nombreUsuario", nombre)
                put("claveUsuario", clave)
                put("fechaHoraUsuario", fechaHoraActual)
                put("esAdmin", esAdminVal)
            }
            val id = db.insert("Usuarios", null, values)
            db.close()
            return id != -1L
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                db.close()
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
            return false
        }
    }

    /**
     * Valida si el nombre de usuario y la clave ingresados coinciden con un registro en la tabla Usuarios.
     * @return true si las credenciales son válidas.
     */
    fun validarUsuario(nombre: String, clave: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(
            "Usuarios",
            arrayOf("idUsuario"),
            "nombreUsuario = ? AND claveUsuario = ?",
            arrayOf(nombre, clave),
            null, null, null
        )
        val existe = cursor.moveToFirst()
        cursor.close()
        db.close()
        return existe
    }

    /**
     * Verifica si la contraseña ingresada corresponde a un usuario administrador (esAdmin = 1).
     */
    fun verificarPasswordAdmin(password: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(
            "Usuarios",
            arrayOf("idUsuario"),
            "esAdmin = 1 AND claveUsuario = ?",
            arrayOf(password),
            null, null, null
        )
        val esValido = cursor.moveToFirst()
        cursor.close()
        db.close()
        return esValido
    }

    /**
     * Actualiza el nombreUsuario y la claveUsuario de un usuario en la tabla Usuarios.
     */
    fun actualizarUsuario(nombreAnterior: String, nombreNuevo: String, claveNueva: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("nombreUsuario", nombreNuevo)
            put("claveUsuario", claveNueva)
        }
        val filas = db.update("Usuarios", values, "nombreUsuario = ?", arrayOf(nombreAnterior))
        db.close()
        return filas > 0
    }

    /**
     * Verifica si un nombre de usuario ya existe en la tabla Usuarios.
     */
    fun existeUsuario(nombre: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(
            "Usuarios",
            arrayOf("idUsuario"),
            "nombreUsuario = ?",
            arrayOf(nombre),
            null, null, null
        )
        val existe = cursor.moveToFirst()
        cursor.close()
        db.close()
        return existe
    }

    /**
     * Obtiene el idUsuario asociado a un nombreUsuario.
     */
    fun obtenerIdUsuarioActivo(nombreUsuario: String): Int {
        val db = this.readableDatabase
        val cursor = db.query(
            "Usuarios",
            arrayOf("idUsuario"),
            "nombreUsuario = ?",
            arrayOf(nombreUsuario),
            null, null, null
        )
        val id = if (cursor.moveToFirst()) cursor.getInt(cursor.getColumnIndexOrThrow("idUsuario")) else 1
        cursor.close()
        db.close()
        return id
    }

    // =========================================================================
    // MÉTODOS DE BASE DE DATOS PARA CUENTAS
    // =========================================================================

    /**
     * Devuelve la lista de cuentas guardadas en la tabla Cuentas de la base de datos.
     */
    fun obtenerCuentas(idUsuario: Int = 0): List<Cuenta> {
        val lista = mutableListOf<Cuenta>()
        val db = this.readableDatabase
        val cursor = if (idUsuario > 0) {
            db.query("Cuentas", null, "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, "nombreCuenta ASC")
        } else {
            db.query("Cuentas", null, null, null, null, null, "nombreCuenta ASC")
        }
        if (cursor.moveToFirst()) {
            val idCIndex = cursor.getColumnIndex("idCuenta")
            val idUIndex = cursor.getColumnIndex("idUsuario")
            val nomIndex = cursor.getColumnIndex("nombreCuenta")
            val totIndex = cursor.getColumnIndex("totalCuenta")
            val fecIndex = cursor.getColumnIndex("fechaHoraCuenta")
            do {
                val idC = if (idCIndex >= 0) cursor.getInt(idCIndex) else 0
                val idU = if (idUIndex >= 0) cursor.getInt(idUIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val tot = if (totIndex >= 0) cursor.getInt(totIndex) else 0
                val fec = if (fecIndex >= 0) cursor.getString(fecIndex) ?: "" else ""
                lista.add(Cuenta(idC, idU, nom, tot, fec))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    /**
     * Inserta una nueva cuenta en la tabla Cuentas con la fecha/hora actual.
     */
    fun insertarCuenta(idUsuario: Int, nombre: String, total: Int): Boolean {
        val db = this.writableDatabase
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val values = ContentValues().apply {
            put("idUsuario", idUsuario)
            put("nombreCuenta", nombre)
            put("totalCuenta", total)
            put("fechaHoraCuenta", fechaHoraActual)
        }
        val id = db.insert("Cuentas", null, values)
        db.close()
        return id != -1L
    }

    /**
     * Actualiza el nombre y el valor/monto de una cuenta existente por su idCuenta.
     */
    fun actualizarCuenta(idCuenta: Int, nombre: String, total: Int): Boolean {
        val db = this.writableDatabase
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val values = ContentValues().apply {
            put("nombreCuenta", nombre)
            put("totalCuenta", total)
            put("fechaHoraCuenta", fechaHoraActual)
        }
        val filas = db.update("Cuentas", values, "idCuenta = ?", arrayOf(idCuenta.toString()))
        db.close()
        return filas > 0
    }

    /**
     * Elimina una cuenta de la tabla Cuentas por su idCuenta.
     */
    fun eliminarCuenta(idCuenta: Int): Boolean {
        val db = this.writableDatabase
        val filas = db.delete("Cuentas", "idCuenta = ?", arrayOf(idCuenta.toString()))
        db.close()
        return filas > 0
    }

    // =========================================================================
    // MÉTODOS DE BASE DE DATOS PARA ITEMS
    // =========================================================================

    /**
     * Devuelve la lista de ítems guardados en la tabla Items de la base de datos.
     */
    fun obtenerItems(idUsuario: Int = 0): List<Item> {
        val lista = mutableListOf<Item>()
        val db = this.readableDatabase
        val cursor = if (idUsuario > 0) {
            db.query("Items", null, "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, "nombreItem ASC")
        } else {
            db.query("Items", null, null, null, null, null, "nombreItem ASC")
        }
        if (cursor.moveToFirst()) {
            val idIIndex = cursor.getColumnIndex("idItem")
            val idUIndex = cursor.getColumnIndex("idUsuario")
            val nomIndex = cursor.getColumnIndex("nombreItem")
            val valIndex = cursor.getColumnIndex("valorItem")
            do {
                val idI = if (idIIndex >= 0) cursor.getInt(idIIndex) else 0
                val idU = if (idUIndex >= 0) cursor.getInt(idUIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val vItem = if (valIndex >= 0) cursor.getInt(valIndex) else 0
                lista.add(Item(idI, idU, nom, vItem))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    /**
     * Inserta un nuevo ítem en la tabla Items de la base de datos.
     */
    fun insertarItem(idUsuario: Int, nombre: String, valor: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("idUsuario", idUsuario)
            put("nombreItem", nombre)
            put("valorItem", valor)
        }
        val id = db.insert("Items", null, values)
        db.close()
        return id != -1L
    }

    /**
     * Actualiza el nombre y valor de un ítem en la tabla Items por su idItem.
     */
    fun actualizarItem(idItem: Int, nombre: String, valor: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("nombreItem", nombre)
            put("valorItem", valor)
        }
        val filas = db.update("Items", values, "idItem = ?", arrayOf(idItem.toString()))
        db.close()
        return filas > 0
    }

    /**
     * Elimina un ítem de la tabla Items por su idItem.
     */
    fun eliminarItem(idItem: Int): Boolean {
        val db = this.writableDatabase
        val filas = db.delete("Items", "idItem = ?", arrayOf(idItem.toString()))
        db.close()
        return filas > 0
    }

    // =========================================================================
    // MÉTODOS DE BASE DE DATOS PARA SIMULACIONES
    // =========================================================================

    /**
     * Devuelve la lista de simulaciones guardadas en la tabla Simulaciones de la base de datos.
     */
    fun obtenerSimulaciones(idUsuario: Int = 0): List<Simulacion> {
        val lista = mutableListOf<Simulacion>()
        val db = this.readableDatabase
        val cursor = if (idUsuario > 0) {
            db.query("Simulaciones", null, "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, "idSim DESC")
        } else {
            db.query("Simulaciones", null, null, null, null, null, "idSim DESC")
        }
        if (cursor.moveToFirst()) {
            val idSIndex = cursor.getColumnIndex("idSim")
            val idCIndex = cursor.getColumnIndex("idCuenta")
            val idUIndex = cursor.getColumnIndex("idUsuario")
            val nomIndex = cursor.getColumnIndex("nombreSim")
            val fecIndex = cursor.getColumnIndex("fechaHoraSim")
            val dispIndex = cursor.getColumnIndex("totalDisponible")
            val egrIndex = cursor.getColumnIndex("totalEgresos")
            val mesIndex = cursor.getColumnIndex("meses")
            val excIndex = cursor.getColumnIndex("excedente")
            do {
                val idS = if (idSIndex >= 0) cursor.getInt(idSIndex) else 0
                val idC = if (idCIndex >= 0) cursor.getInt(idCIndex) else 0
                val idU = if (idUIndex >= 0) cursor.getInt(idUIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val fec = if (fecIndex >= 0) cursor.getString(fecIndex) ?: "" else ""
                val disp = if (dispIndex >= 0) cursor.getInt(dispIndex) else 0
                val egr = if (egrIndex >= 0) cursor.getInt(egrIndex) else 0
                val mes = if (mesIndex >= 0) cursor.getInt(mesIndex) else 0
                val exc = if (excIndex >= 0) cursor.getInt(excIndex) else 0
                lista.add(Simulacion(idS, idC, idU, nom, fec, disp, egr, mes, exc))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    /**
     * Inserta una nueva simulación en la tabla Simulaciones y devuelve su idSim generado (o -1L si falla).
     */
    fun insertarSimulacion(idCuenta: Int, idUsuario: Int, nombreSim: String, totalDisponible: Int, totalEgresos: Int, meses: Int, excedente: Int): Long {
        val db = this.writableDatabase
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val values = ContentValues().apply {
            put("idCuenta", idCuenta)
            put("idUsuario", idUsuario)
            put("nombreSim", nombreSim)
            put("fechaHoraSim", fechaHoraActual)
            put("totalDisponible", totalDisponible)
            put("totalEgresos", totalEgresos)
            put("meses", meses)
            put("excedente", excedente)
        }
        val id = db.insert("Simulaciones", null, values)
        db.close()
        return id
    }

    /**
     * Inserta un registro de detalle en la tabla DetallesSimulaciones.
     */
    fun insertarDetalleSimulacion(idSim: Long, idItem: Int, nombreItem: String, valorItem: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("idSim", idSim)
            if (idItem > 0) put("idItem", idItem)
            put("nombreItem", nombreItem)
            put("valorItem", valorItem)
        }
        val id = db.insert("DetallesSimulaciones", null, values)
        db.close()
        return id != -1L
    }

    companion object {
        const val DATABASE_NAME = "simulafin.db"
        private const val DATABASE_VERSION = 5
    }
}
