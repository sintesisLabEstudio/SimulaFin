package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.SesionSimulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class InputSimItemsActivity : AppCompatActivity() {

    private lateinit var spnSeleccionItem: Spinner
    private lateinit var adapterItem: ArrayAdapter<String>
    private val listaItems = mutableListOf<String>()

    private val mapaValoresItems = mutableMapOf(
        "luz" to "20000",
        "agua" to "15000",
        "arriendo" to "250000",
        "celular" to "10000",
        "Cekukar" to "10000"
    )

    private lateinit var txtValorItem: EditText
    private lateinit var txvTotalItems: TextView
    private lateinit var lvItems: ListView
    private lateinit var adapterListado: ArrayAdapter<String>
    private val listaItemsAgregados = mutableListOf<String>()
    private var itemSeleccionadoListViewPosition: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_sim_items)

        presentaPie("Aqui ingresamos los items de gastos mensuales y formamos la lista de items de la simulación teniendo con esto el monto total de egreso mensual.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        // Recuperar datos pasados desde InputSimCuentaActivity
        val simulacion = intent.getStringExtra("EXTRA_SIMULACION") ?: ""
        val cuenta = intent.getStringExtra("EXTRA_CUENTA") ?: ""
        val valorCuenta = intent.getStringExtra("EXTRA_VALOR_CUENTA") ?: ""

        spnSeleccionItem = findViewById(R.id.spnSeleccionItem)
        txtValorItem = findViewById(R.id.txtValorItem)
        txvTotalItems = findViewById(R.id.txvTotalItems)
        lvItems = findViewById(R.id.lvItems)
        val btnNuevoItem = findViewById<Button>(R.id.btnNuevoItem)
        val btnAgregarItem = findViewById<Button>(R.id.btnAgregarItem)
        val bynEliminarItem = findViewById<Button>(R.id.bynEliminarItem)
        val btnOkItems = findViewById<Button>(R.id.btnOkItems)

        // Configurar lista de ítems dinámicamente para el Spinner
        val recursosItems = resources.getStringArray(R.array.lista_items)
        listaItems.addAll(recursosItems)
        adapterItem = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaItems
        )
        adapterItem.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccionItem.adapter = adapterItem

        // Configurar adaptador para el ListView
        adapterListado = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_single_choice,
            listaItemsAgregados
        )
        lvItems.adapter = adapterListado
        lvItems.choiceMode = ListView.CHOICE_MODE_SINGLE

        // Cargar ítems previos desde SesionSimulacion si existen
        listaItemsAgregados.clear()
        listaItemsAgregados.addAll(SesionSimulacion.listaItemsAgregados)
        adapterListado.notifyDataSetChanged()

        // Calcular e informar el total inicial
        calcularYActualizarTotal()

        // Listener para registrar la posición al seleccionar una fila en el ListView
        lvItems.setOnItemClickListener { _, _, position, _ ->
            itemSeleccionadoListViewPosition = position
        }

        // Listener para actualizar el monto del item seleccionado en el Spinner
        spnSeleccionItem.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val itemSeleccionado = listaItems.getOrNull(position) ?: ""
                if (position == 0) {
                    txtValorItem.setText("")
                } else {
                    val valorRef = mapaValoresItems[itemSeleccionado] ?: ""
                    txtValorItem.setText(valorRef)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }

        // Vaciar txtValorItem y enfocar al hacer clic para ingresar un valor personalizado
        txtValorItem.setOnClickListener {
            txtValorItem.text.clear()
            txtValorItem.requestFocus()
            txtValorItem.selectAll()
        }

        // Al presionar el botón btnNuevoItem (+) despliega el diálogo para nuevo ítem
        btnNuevoItem.setOnClickListener {
            mostrarDialogNuevoItem()
        }

        val btnGrabarValorItem = findViewById<Button>(R.id.btnGrabarValorItem)
        btnGrabarValorItem?.setOnClickListener {
            val itemSeleccionado = spnSeleccionItem.selectedItem?.toString() ?: ""
            val nuevoValor = txtValorItem.text.toString().trim()

            if (spnSeleccionItem.selectedItemPosition == 0 || itemSeleccionado.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione un ítem para guardar el valor", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (nuevoValor.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el valor del ítem", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            mapaValoresItems[itemSeleccionado] = nuevoValor
            Toast.makeText(this, "Valor guardado para $itemSeleccionado: $$nuevoValor", Toast.LENGTH_SHORT).show()
        }

        btnAgregarItem.setOnClickListener {
            val itemSeleccionado = spnSeleccionItem.selectedItem?.toString() ?: ""
            val valorItem = txtValorItem.text.toString().trim()

            if (spnSeleccionItem.selectedItemPosition == 0 || itemSeleccionado.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione un ítem válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (valorItem.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese o verifique el monto del ítem", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val registro = "$itemSeleccionado - $$valorItem"
            listaItemsAgregados.add(registro)
            SesionSimulacion.listaItemsAgregados.add(registro)
            adapterListado.notifyDataSetChanged()
            calcularYActualizarTotal()

            // Resetear Spinner y EditText
            spnSeleccionItem.setSelection(0)
            txtValorItem.text.clear()
            itemSeleccionadoListViewPosition = -1
            lvItems.clearChoices()
        }

        // Listener para eliminar la fila seleccionada de lvItems
        bynEliminarItem.setOnClickListener {
            val pos = if (itemSeleccionadoListViewPosition != -1) itemSeleccionadoListViewPosition else lvItems.checkedItemPosition
            if (pos != ListView.INVALID_POSITION && pos >= 0 && pos < listaItemsAgregados.size) {
                val itemEliminado = listaItemsAgregados.removeAt(pos)
                SesionSimulacion.listaItemsAgregados.remove(itemEliminado)
                adapterListado.notifyDataSetChanged()
                calcularYActualizarTotal()
                itemSeleccionadoListViewPosition = -1
                lvItems.clearChoices()
                Toast.makeText(this, "Ítem eliminado: $itemEliminado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Seleccione una fila en la lista para eliminar", Toast.LENGTH_SHORT).show()
            }
        }

        btnOkItems.setOnClickListener {
            if (listaItemsAgregados.isEmpty()) {
                Toast.makeText(this, "Debe agregar al menos un ítem a la lista", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            var totalGastos = 0L
            for (registro in listaItemsAgregados) {
                val montoString = registro.substringAfter("-").replace("[^0-9]".toRegex(), "")
                totalGastos += (montoString.toLongOrNull() ?: 0L)
            }

            val intent = Intent(this, OutSimResumenActivity::class.java).apply {
                putExtra("EXTRA_SIMULACION", simulacion)
                putExtra("EXTRA_CUENTA", cuenta)
                putExtra("EXTRA_VALOR_CUENTA", valorCuenta)
                putStringArrayListExtra("EXTRA_LISTA_ITEMS", ArrayList(listaItemsAgregados))
                putExtra("EXTRA_TOTAL_GASTOS", totalGastos)
            }
            startActivity(intent)
        }
    }

    private fun calcularYActualizarTotal() {
        var total = 0L
        for (registro in listaItemsAgregados) {
            val montoString = registro.substringAfter("-").replace("[^0-9]".toRegex(), "")
            val monto = montoString.toLongOrNull() ?: 0L
            total += monto
        }
        txvTotalItems.text = "Total: $$total"
    }

    private fun mostrarDialogNuevoItem() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nuevo Ítem y Valor")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(this).apply {
            hint = "Nombre del nuevo ítem"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(this).apply {
            hint = "Monto/Valor del ítem"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevoItem = inputNombre.text.toString().trim()
            val valorItem = inputValor.text.toString().trim()

            if (nuevoItem.isNotEmpty() && valorItem.isNotEmpty()) {
                listaItems.add(nuevoItem)
                mapaValoresItems[nuevoItem] = valorItem
                adapterItem.notifyDataSetChanged()
                
                // Selecciona el ítem nuevo en el Spinner spnSeleccionItem
                spnSeleccionItem.setSelection(listaItems.size - 1)
                
                // Presenta su valor referenciado en txtValorItem
                txtValorItem.setText(valorItem)
            } else {
                Toast.makeText(this, "Debe ingresar nombre y valor del ítem", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }
}
