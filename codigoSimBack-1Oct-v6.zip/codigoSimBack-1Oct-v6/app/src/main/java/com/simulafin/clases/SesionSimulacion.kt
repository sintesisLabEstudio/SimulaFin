package com.simulafin.clases

object SesionSimulacion {
    var simulacion: String = ""
    var cuenta: String = ""
    var valorCuenta: String = ""
    val listaItemsAgregados = mutableListOf<String>()

    fun limpiar() {
        simulacion = ""
        cuenta = ""
        valorCuenta = ""
        listaItemsAgregados.clear()
    }
}
