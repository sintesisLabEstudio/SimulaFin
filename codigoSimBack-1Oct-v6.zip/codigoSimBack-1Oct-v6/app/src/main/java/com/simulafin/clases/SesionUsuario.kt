package com.simulafin.clases

object SesionUsuario {
    var usuarioActivo: String = "Usuario Activo"
}
