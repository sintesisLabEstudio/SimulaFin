package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.SesionSimulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class InputSimCuentaActivity : AppCompatActivity() {

    private lateinit var spnSeleccioSim: Spinner
    private lateinit var adapterSimulacion: ArrayAdapter<String>
    private val listaSimulaciones = mutableListOf<String>()

    private lateinit var spnSeleccionCuenta: Spinner
    private lateinit var adapterCuenta: ArrayAdapter<String>
    private val listaCuentas = mutableListOf<String>()
    
    // Mapa para referenciar cada cuenta con su respectivo valor/monto
    private val mapaValoresCuentas = mutableMapOf(
        "Cuenta Sercotec" to "1000000",
        "Cuenta Personal" to "550000",
        "Cuenta Ahorro" to "750000"
    )

    private lateinit var txtValorCuenta: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_sim_cuenta)

        presentaPie("Aqui seleccionaremos la simulacion o crearemos una nueva simulacion, seleccionando la cuenta en la que simularemos que presentara el monto disponible de esa cuenta...")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        val btnOkCuenta = findViewById<Button>(R.id.btnOkCuenta)
        val btnNuevaSim = findViewById<Button>(R.id.btnNuevaSim)
        val btnNuevaCuenta = findViewById<Button>(R.id.btnNuevaCuenta)
        val btnGrabaSim = findViewById<Button>(R.id.btnGrabaSim)

        spnSeleccioSim = findViewById(R.id.spnSeleccioSim)
        spnSeleccionCuenta = findViewById(R.id.spnSeleccionCuenta)
        txtValorCuenta = findViewById(R.id.txtValorCuenta)

        // Configuración de Simulación
        val recursosSim = resources.getStringArray(R.array.lista_opciones_simulacion)
        listaSimulaciones.addAll(recursosSim)
        adapterSimulacion = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaSimulaciones
        )
        adapterSimulacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccioSim.adapter = adapterSimulacion

        // Configuración de Cuenta
        val recursosCuentas = resources.getStringArray(R.array.lista_opciones_cuentas)
        listaCuentas.addAll(recursosCuentas)
        adapterCuenta = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaCuentas
        )
        adapterCuenta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccionCuenta.adapter = adapterCuenta

        // Listener para actualizar el monto en txtValorCuenta según la cuenta seleccionada (usando el mapa referenciado)
        spnSeleccionCuenta.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val cuentaSeleccionada = listaCuentas.getOrNull(position) ?: ""
                if (position == 0) {
                    txtValorCuenta.setText("")
                } else {
                    val valorRef = mapaValoresCuentas[cuentaSeleccionada] ?: ""
                    txtValorCuenta.setText(valorRef)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }

        // Vaciar txtValorCuenta y enfocar al hacer clic para ingresar un valor personalizado
        txtValorCuenta.setOnClickListener {
            txtValorCuenta.text.clear()
            txtValorCuenta.requestFocus()
            txtValorCuenta.selectAll()
        }

        btnNuevaSim.setOnClickListener {
            mostrarDialogNuevaSimulacion()
        }

        btnNuevaCuenta.setOnClickListener {
            txtValorCuenta.text.clear()
            txtValorCuenta.requestFocus()
            txtValorCuenta.selectAll()
            mostrarDialogNuevaCuenta()
        }

        btnGrabaSim?.setOnClickListener {
            val cuentaSeleccionada = spnSeleccionCuenta.selectedItem?.toString() ?: ""
            val nuevoValor = txtValorCuenta.text.toString().trim()

            if (spnSeleccionCuenta.selectedItemPosition == 0 || cuentaSeleccionada.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una cuenta para guardar el valor", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (nuevoValor.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el valor de la cuenta", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            mapaValoresCuentas[cuentaSeleccionada] = nuevoValor
            Toast.makeText(this, "Valor guardado para $cuentaSeleccionada: $$nuevoValor", Toast.LENGTH_SHORT).show()
        }

        btnOkCuenta.setOnClickListener {
            val simulacionSeleccionada = spnSeleccioSim.selectedItem?.toString() ?: ""
            val cuentaSeleccionada = spnSeleccionCuenta.selectedItem?.toString() ?: ""
            val valorCuenta = txtValorCuenta.text.toString().trim()

            if (spnSeleccionCuenta.selectedItemPosition == 0 || cuentaSeleccionada.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione o ingrese una cuenta", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (valorCuenta.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el monto para la cuenta", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            SesionSimulacion.simulacion = simulacionSeleccionada
            SesionSimulacion.cuenta = cuentaSeleccionada
            SesionSimulacion.valorCuenta = valorCuenta

            val intent = Intent(this, InputSimItemsActivity::class.java).apply {
                putExtra("EXTRA_SIMULACION", simulacionSeleccionada)
                putExtra("EXTRA_CUENTA", cuentaSeleccionada)
                putExtra("EXTRA_VALOR_CUENTA", valorCuenta)
            }
            startActivity(intent)
        }
    }

    private fun mostrarDialogNuevaSimulacion() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nueva Simulación")

        val input = EditText(this)
        input.hint = "Ingrese nombre de la simulación"
        input.setPadding(40, 30, 40, 30)
        builder.setView(input)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaSim = input.text.toString().trim()
            if (nuevaSim.isNotEmpty()) {
                listaSimulaciones.add(nuevaSim)
                adapterSimulacion.notifyDataSetChanged()
                spnSeleccioSim.setSelection(listaSimulaciones.size - 1)
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun mostrarDialogNuevaCuenta() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Nueva Cuenta y Valor")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(this).apply {
            hint = "Nombre de la nueva cuenta"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(this).apply {
            hint = "Monto/Valor de la cuenta"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaCta = inputNombre.text.toString().trim()
            val valorCta = inputValor.text.toString().trim()

            if (nuevaCta.isNotEmpty() && valorCta.isNotEmpty()) {
                listaCuentas.add(nuevaCta)
                mapaValoresCuentas[nuevaCta] = valorCta
                adapterCuenta.notifyDataSetChanged()
                spnSeleccionCuenta.setSelection(listaCuentas.size - 1)
                txtValorCuenta.setText(valorCta)
            } else {
                Toast.makeText(this, "Debe ingresar nombre y valor de la cuenta", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }
}
