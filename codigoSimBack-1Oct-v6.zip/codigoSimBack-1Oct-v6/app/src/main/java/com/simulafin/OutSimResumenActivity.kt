package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class OutSimResumenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_out_sim_resumen)

        presentaPie("Aqui se presentara el resumen completo de la simulación presentando el nombre de la simulacion la cuenta asociada..todos los montos y el resultado de los meses y excedente...")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        val txvResumen = findViewById<TextView>(R.id.txvResumen)
        txvResumen.movementMethod = ScrollingMovementMethod()

        val btnItems = findViewById<Button>(R.id.btnItems)
        val btnSim = findViewById<Button>(R.id.btnSim)
        val btnGrabaSim = findViewById<Button>(R.id.btnGrabaSim)
        val btnMenu = findViewById<Button>(R.id.btnMenu)

        // Recuperar datos pasados desde InputSimItemsActivity
        val simulacion = intent.getStringExtra("EXTRA_SIMULACION") ?: "Sin especificar"
        val cuenta = intent.getStringExtra("EXTRA_CUENTA") ?: "Sin especificar"
        val valorCuentaStr = intent.getStringExtra("EXTRA_VALOR_CUENTA") ?: "0"
        val listaItems = intent.getStringArrayListExtra("EXTRA_LISTA_ITEMS") ?: arrayListOf()
        val totalGastos = intent.getLongExtra("EXTRA_TOTAL_GASTOS", 0L)

        val valorCuentaNum = valorCuentaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L

        // Cálculo de meses enteros y el excedente restante
        val mesesEnteros: Long
        val excedente: Long

        if (totalGastos > 0) {
            mesesEnteros = valorCuentaNum / totalGastos
            val costoTotalMeses = mesesEnteros * totalGastos
            excedente = valorCuentaNum - costoTotalMeses
        } else {
            mesesEnteros = 0L
            excedente = valorCuentaNum
        }

        // Construir el texto del resumen detallado
        val resumenBuilder = StringBuilder()
        resumenBuilder.append("Simulación: $simulacion\n")
        resumenBuilder.append("Cuenta: $cuenta\n")
        resumenBuilder.append("Monto Cuenta: $$valorCuentaStr\n\n")
        resumenBuilder.append("--- Detalle de Gastos ---\n")

        if (listaItems.isEmpty()) {
            resumenBuilder.append("(No se agregaron ítems)\n")
        } else {
            for (item in listaItems) {
                resumenBuilder.append("• $item\n")
            }
        }

        resumenBuilder.append("\nTotal Gastos Mensuales: $$totalGastos\n")
        if (totalGastos > 0) {
            resumenBuilder.append("Duración: $mesesEnteros meses\n")
        } else {
            resumenBuilder.append("Duración: Indefinido\n")
        }
        resumenBuilder.append("Excedente: $$excedente")

        txvResumen.text = resumenBuilder.toString()

        // Volver a la pantalla de ítems conservando el estado y la lista de ítems intacta
        btnItems.setOnClickListener {
            finish()
        }

        btnSim.setOnClickListener {
            finish()
        }

        btnGrabaSim?.setOnClickListener {
            Toast.makeText(this, "Simulación guardada con éxito", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            val intent = Intent(this, MenuSimActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
        }
    }
}
