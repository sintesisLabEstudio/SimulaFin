package com.simulafin.clases

import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.R

/**
 * Función global para presentar el mensaje de ayuda en el pie de página de cualquier actividad.
 */
fun AppCompatActivity.presentaPie(mensaje: String) {
    val txvPie = findViewById<TextView>(R.id.txvPiePagina)
        ?: findViewById<TextView>(R.id.textView2)
        ?: findViewById<TextView>(R.id.textView)
        ?: findViewById<TextView>(R.id.tvExplicacionResumen)
    
    txvPie?.text = mensaje
}
