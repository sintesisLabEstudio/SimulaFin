package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class RegistroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        presentaPie("Edición de datos del usuario local. Ingrese su nombre, nueva contraseña y confirmación para cambiar sus credenciales.")

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        val etNombreUsuario = findViewById<EditText>(R.id.etNombreUsuario)
        val etClaveUsuario = findViewById<EditText>(R.id.etClaveUsuario)
        val etConfirmarClave = findViewById<EditText>(R.id.etConfirmarClave)
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)

        // Pre-cargar el nombre de usuario activo actual
        if (SesionUsuario.usuarioActivo.isNotEmpty() && SesionUsuario.usuarioActivo != "Usuario Activo") {
            etNombreUsuario.setText(SesionUsuario.usuarioActivo)
        }

        btnRegistrar.setOnClickListener {
            val nombre = etNombreUsuario.text.toString().trim()
            val clave = etClaveUsuario.text.toString().trim()
            val confirmacion = etConfirmarClave.text.toString().trim()

            if (nombre.isEmpty() || clave.isEmpty() || confirmacion.isEmpty()) {
                Toast.makeText(this, "Por favor complete todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (clave != confirmacion) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Actualiza el nombre de usuario único en sesión local
            SesionUsuario.usuarioActivo = nombre
            Toast.makeText(this, "Datos de usuario actualizados con éxito", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
