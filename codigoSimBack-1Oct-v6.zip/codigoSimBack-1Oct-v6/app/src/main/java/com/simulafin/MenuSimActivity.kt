package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class MenuSimActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_sim)

        presentaPie("Menú de Simulación: Elija entre el flujo Paso a Paso, la síntesis con Fragments o consultar simulaciones anteriores.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        val btnPasoApaso = findViewById<Button>(R.id.btnPasoApaso)
        val btnSintesis = findViewById<Button>(R.id.btnSintesis)
        val btnConsultaSim = findViewById<Button>(R.id.btnConsultaSim)
        val btnMenuPrincipal = findViewById<Button>(R.id.btnMenuPrincipal)

        btnPasoApaso.setOnClickListener {
            val intent = Intent(this, InputSimCuentaActivity::class.java)
            startActivity(intent)
        }

        btnSintesis.setOnClickListener {
            val intent = Intent(this, SimulacionActivity::class.java)
            startActivity(intent)
        }

        btnConsultaSim.setOnClickListener {
            val intent = Intent(this, ConsultaSimulacionesActivity::class.java)
            startActivity(intent)
        }

        btnMenuPrincipal.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
