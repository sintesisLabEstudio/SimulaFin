package com.simulafin.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.simulafin.R
import com.simulafin.interfaces.OnSimulacionDatosListener

class SimulacionInputFragment : Fragment() {

    private val listaItemsAgregados = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>
    private var listener: OnSimulacionDatosListener? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnSimulacionDatosListener) {
            listener = context
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_simulacion_input, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val spnItems = view.findViewById<Spinner>(R.id.spnItems)
        val txtValorItem = view.findViewById<EditText>(R.id.txtValorItem)
        val btnAgregaItem = view.findViewById<Button>(R.id.btnAgregaItem)
        val lstItemsSeleccionados = view.findViewById<ListView>(R.id.lstItemsSeleccionados)

        // Configurar el adaptador para el ListView
        adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            listaItemsAgregados
        )
        lstItemsSeleccionados.adapter = adapter

        // Listener para agregar un elemento a la lista al presionar 'Agregar'
        btnAgregaItem.setOnClickListener {
            val itemSeleccionado = spnItems.selectedItem?.toString() ?: ""
            val monto = txtValorItem.text.toString().trim()

            if (itemSeleccionado.isNotEmpty() && monto.isNotEmpty()) {
                val registro = "$itemSeleccionado - $$monto"
                listaItemsAgregados.add(registro)
                adapter.notifyDataSetChanged()
                txtValorItem.text.clear()

                // Notificar mediante la interfaz al Fragmento/Actividad padre
                var total = 0L
                for (item in listaItemsAgregados) {
                    val m = item.substringAfter("-").replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
                    total += m
                }
                listener?.onDatosSimulacionIngresados(total)
            } else {
                Toast.makeText(requireContext(), "Seleccione un ítem e ingrese el monto", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
