package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.GestorRespaldo
import com.simulafin.clases.presentaPie

class RespaldoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_respaldo)

        presentaPie("Gestor de Respaldo: Permite realizar copias de seguridad de la base de datos simulafin.db y recuperarlas.")

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        val btnRespaldar = findViewById<Button>(R.id.btnRespaldar)
        val btnRecuperar = findViewById<Button>(R.id.btnRecuperar)
        val gestor = GestorRespaldo()

        btnRespaldar.setOnClickListener {
            val exito = gestor.respaldar("")
            if (exito) {
                Toast.makeText(this, "Respaldo realizado con éxito", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error al respaldar", Toast.LENGTH_SHORT).show()
            }
        }

        btnRecuperar.setOnClickListener {
            val exito = gestor.importar("")
            if (exito) {
                Toast.makeText(this, "Recuperación realizada con éxito", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error al recuperar", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
