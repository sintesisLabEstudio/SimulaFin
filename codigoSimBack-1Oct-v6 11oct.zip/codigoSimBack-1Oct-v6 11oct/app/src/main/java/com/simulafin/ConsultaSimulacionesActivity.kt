package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class ConsultaSimulacionesActivity : AppCompatActivity() {

    private lateinit var spnSeleccionSim: Spinner
    private lateinit var txtValorSim: EditText
    private lateinit var adapterSimulacion: ArrayAdapter<String>
    private val listaSimulaciones = mutableListOf<String>()

    private val mapaValoresSimulaciones = mutableMapOf(
        "Escenario 1" to "1000000",
        "Escenario 2" to "1500000",
        "Escenario 3" to "2000000"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consulta_simulaciones)

        presentaPie("Módulo de consulta para revisar e inspeccionar simulaciones previamente guardadas en la base de datos.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        spnSeleccionSim = findViewById(R.id.spnSeleccionSim)
        txtValorSim = findViewById(R.id.txtValorSim)

        val btnExportarJson = findViewById<Button>(R.id.btnExportarJson)
        val btnImprimir = findViewById<Button>(R.id.btnImprimir)
        val btnEnviar = findViewById<Button>(R.id.btnEnviar)

        // Cargar las opciones de simulación del sistema desde el recurso de strings
        val recursosSim = resources.getStringArray(R.array.lista_opciones_simulacion)
        listaSimulaciones.addAll(recursosSim)

        adapterSimulacion = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaSimulaciones
        )
        adapterSimulacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccionSim.adapter = adapterSimulacion

        // Listener del Spinner que llama a SeleccionSim()
        spnSeleccionSim.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                SeleccionSim(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }

        // Seleccionar todo el texto al hacer clic en txtValorSim para permitir editar
        txtValorSim.setSelectAllOnFocus(true)
        txtValorSim.setOnClickListener {
            txtValorSim.selectAll()
        }

        btnExportarJson.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            val valSim = txtValorSim.text.toString().trim()
            if (spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación a exportar", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Exportando $sim en formato JSON (Monto: $$valSim)...", Toast.LENGTH_SHORT).show()
            }
        }

        btnImprimir.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            val valSim = txtValorSim.text.toString().trim()
            if (spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación para imprimir", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Enviando $sim a la impresora (Monto: $$valSim)...", Toast.LENGTH_SHORT).show()
            }
        }

        btnEnviar.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            val valSim = txtValorSim.text.toString().trim()
            if (spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación para enviar", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Enviando simulación $sim (Monto: $$valSim)...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Función SeleccionSim: maneja la selección en spnSeleccionSim y
     * presenta el valor/monto correspondiente en el EditText txtValorSim.
     */
    fun SeleccionSim(position: Int) {
        val simSeleccionada = listaSimulaciones.getOrNull(position) ?: ""
        if (position == 0) {
            txtValorSim.setText("")
        } else {
            val valorRef = mapaValoresSimulaciones[simSeleccionada] ?: ""
            txtValorSim.setText(valorRef)
        }
    }
}
