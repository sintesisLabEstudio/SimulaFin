@echo off
setlocal

set "SOURCE=%~dp0"
set "DEST=%SOURCE%sintesisCodigoSim"

if exist "%DEST%" (
    echo ERROR: Ya existe la carpeta:
    echo   "%DEST%"
    echo No se modifico para evitar sobrescribir o borrar archivos existentes.
    echo Renombrela o muevala y vuelva a ejecutar este archivo.
    exit /b 1
)

mkdir "%DEST%"
if errorlevel 1 (
    echo ERROR: No se pudo crear "%DEST%".
    exit /b 1
)

echo Copiando el codigo fuente y los recursos de Android...
robocopy "%SOURCE%app\src" "%DEST%\app\src" /E
if errorlevel 8 goto :copy_error

echo Copiando la configuracion del proyecto...
mkdir "%DEST%\gradle\wrapper"
if errorlevel 1 goto :copy_error

copy /Y "%SOURCE%app\build.gradle.kts" "%DEST%\app\build.gradle.kts" >nul
if errorlevel 1 goto :copy_error
copy /Y "%SOURCE%build.gradle.kts" "%DEST%\build.gradle.kts" >nul
if errorlevel 1 goto :copy_error
copy /Y "%SOURCE%settings.gradle.kts" "%DEST%\settings.gradle.kts" >nul
if errorlevel 1 goto :copy_error
copy /Y "%SOURCE%gradle.properties" "%DEST%\gradle.properties" >nul
if errorlevel 1 goto :copy_error
copy /Y "%SOURCE%gradlew.bat" "%DEST%\gradlew.bat" >nul
if errorlevel 1 goto :copy_error
copy /Y "%SOURCE%gradle\libs.versions.toml" "%DEST%\gradle\libs.versions.toml" >nul
if errorlevel 1 goto :copy_error
copy /Y "%SOURCE%gradle\gradle-daemon-jvm.properties" "%DEST%\gradle\gradle-daemon-jvm.properties" >nul
if errorlevel 1 goto :copy_error
copy /Y "%SOURCE%gradle\wrapper\gradle-wrapper.jar" "%DEST%\gradle\wrapper\gradle-wrapper.jar" >nul
if errorlevel 1 goto :copy_error
copy /Y "%SOURCE%gradle\wrapper\gradle-wrapper.properties" "%DEST%\gradle\wrapper\gradle-wrapper.properties" >nul
if errorlevel 1 goto :copy_error

if exist "%SOURCE%README.md" copy /Y "%SOURCE%README.md" "%DEST%\README.md" >nul

echo.
echo Sintesis creada correctamente en:
echo   "%DEST%"
echo.
echo Se excluyeron las carpetas build, .gradle, .idea y .kotlin,
echo la configuracion local.properties, los APK y la documentacion pesada.
exit /b 0

:copy_error
echo.
echo ERROR: Ocurrio un problema al copiar los archivos. Revise la salida anterior.
exit /b 1
