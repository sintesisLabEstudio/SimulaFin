El objetivo del repositorio es el desarrollo colaborativo de una app con android studio lenguaje kotlin
Aqui está la documentación y el código
para entregar en los ramos de TNT y Metodologías
app SimulaFin
simuladorFinanzasPersonales Básico

Ahylin Gonzalez
Ignacio Gaete
Jorge Vera
