package com.simulafin

import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.simulafin.clases.BaseDatosHelper
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SimulacionDatabaseTest {

    private lateinit var dbHelper: BaseDatosHelper

    @Before
    fun setUp() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        dbHelper = BaseDatosHelper(context)
        dbHelper.generaBaseDatos()
    }

    @After
    fun tearDown() {
        // Clean up if needed
    }

    @Test
    fun testGuardarYConsultarSimulacionYDetalles() {
        val usuarioPrueba = "test_user_${System.currentTimeMillis()}"
        val clavePrueba = "123456"

        // 1. Registrar usuario
        val usuarioRegistrado = dbHelper.registrarUsuario(usuarioPrueba, clavePrueba)
        assertTrue("El usuario de prueba debe registrarse correctamente", usuarioRegistrado)

        val idUsuario = dbHelper.obtenerIdUsuarioActivo(usuarioPrueba)
        assertTrue("El ID de usuario debe ser válido", idUsuario > 0)

        // 2. Insertar cuenta
        val cuentaInsertada = dbHelper.insertarCuenta(idUsuario, "Cuenta Test", 2000000)
        assertTrue("La cuenta debe insertarse correctamente", cuentaInsertada)

        val cuentas = dbHelper.obtenerCuentas(idUsuario)
        assertFalse("La lista de cuentas no debe estar vacía", cuentas.isEmpty())
        val idCuenta = cuentas.first().idCuenta

        // 3. Insertar simulación
        val nombreSim = "Simulación Test 2026"
        val totalDisp = 2000000
        val totalEgr = 300000
        val meses = 6
        val excedente = 200000

        val idSim = dbHelper.insertarSimulacion(
            idCuenta = idCuenta,
            idUsuario = idUsuario,
            nombreSim = nombreSim,
            totalDisponible = totalDisp,
            totalEgresos = totalEgr,
            meses = meses,
            excedente = excedente,
        )
        assertNotEquals("El idSim generado debe ser válido", -1L, idSim)

        // 4. Insertar detalles de simulación
        val detalleInsertado = dbHelper.insertarDetalleSimulacion(
            idSim = idSim,
            idItem = 0,
            nombreItem = "Luz Test",
            valorItem = 50000,
        )
        assertTrue("El detalle de simulación debe insertarse correctamente", detalleInsertado)

        // 5. Consultar simulación y verificar su representación
        val simulacionesBD = dbHelper.obtenerSimulaciones(idUsuario)
        assertFalse("La tabla Simulaciones debe contener registros", simulacionesBD.isEmpty())

        val simConsultada = simulacionesBD.find { it.nombreSim == nombreSim }
        assertNotNull("Debe encontrarse la simulación guardada en la tabla Simulaciones", simConsultada)

        if (simConsultada != null) {
            assertEquals("El nombre de la simulación coincide", nombreSim, simConsultada.nombreSim)
            assertEquals("El total disponible coincide", totalDisp, simConsultada.totalDisponible)
            assertEquals("El total de egresos coincide", totalEgr, simConsultada.totalEgresos)
            assertEquals("Los meses coinciden", meses, simConsultada.meses)
            assertEquals("El excedente coincide", excedente, simConsultada.excedente)
        }
    }
}
