package com.simulafin

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.HashUtils
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaClave
import com.simulafin.clases.presentaPie

class RegistroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        presentaPie("Edición de datos del usuario local. Ingrese su nombre, nueva contraseña y confirmación para cambiar sus credenciales.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        val etNombreUsuario = findViewById<EditText>(R.id.etNombreUsuario)
        val etClaveUsuario = findViewById<EditText>(R.id.etClaveUsuario)
        val etConfirmarClave = findViewById<EditText>(R.id.etConfirmarClave)
        etClaveUsuario.presentaClave()
        etConfirmarClave.presentaClave()
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)

        val dbHelper = BaseDatosHelper(this)

        // Pre-cargar el nombre de usuario activo actual
        if (SesionUsuario.usuarioActivo.isNotEmpty() && SesionUsuario.usuarioActivo != "Usuario Activo") {
            etNombreUsuario.setText(SesionUsuario.usuarioActivo)
        }

        //registro inicial como nuevo usuario
        btnRegistrar.setOnClickListener {
            val nombreAnterior = SesionUsuario.usuarioActivo
            val nombre = etNombreUsuario.text.toString().trim()
            val clave = etClaveUsuario.text.toString().trim()
            val confirmacion = etConfirmarClave.text.toString().trim()

            if (nombre.isEmpty() || clave.isEmpty() || confirmacion.isEmpty()) {
                Toast.makeText(this, "Por favor complete todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (clave != confirmacion) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Actualiza o inserta en la base de datos la información del usuario
            val exito = dbHelper.actualizarUsuario(nombreAnterior, nombre, clave)
            if (!exito) {
                if (dbHelper.existeUsuario(nombre)) {
                    val db = dbHelper.writableDatabase
                    val salt = HashUtils.generarSalt()
                    val claveHashed = HashUtils.hashPassword(clave, salt)
                    val values = ContentValues().apply {
                        put("claveUsuario", claveHashed)
                        put("saltUsuario", salt)
                    }
                    db.update("Usuarios", values, "nombreUsuario = ?", arrayOf(nombre))
                    db.close()
                } else {
                    dbHelper.registrarUsuario(nombre, clave)
                }
            }

            // Actualiza el nombre de usuario único en sesión local (memoria) y en pantalla
            SesionUsuario.usuarioActivo = nombre
            txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

            Toast.makeText(this, "Datos de usuario actualizados con éxito en la base de datos", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
