package com.simulafin.clases

import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Clase de utilidad modularizada para el hashing y salting seguro de contraseñas de usuario.
 */
object HashUtils {

    /**
     * Genera una Sal (Salt) aleatoria de 16 bytes para inmunizar la clave contra ataques de tablas arcoíris.
     */
    fun generarSalt(): String {
        val random = SecureRandom()
        val salt = ByteArray(16)
        random.nextBytes(salt)
        return salt.joinToString("") { "%02x".format(it) }
    }

    /**
     * Calcula el hash criptográfico SHA-256 combinando la contraseña con la sal especificada.
     */
    fun hashPassword(password: String, salt: String): String {
        if (salt.isBlank()) {
            val bytes = password.toByteArray(Charsets.UTF_8)
            val md = MessageDigest.getInstance("SHA-256")
            return md.digest(bytes).joinToString("") { "%02x".format(it) }
        }
        val bytes = (password + salt).toByteArray(Charsets.UTF_8)
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(bytes).joinToString("") { "%02x".format(it) }
    }
}
