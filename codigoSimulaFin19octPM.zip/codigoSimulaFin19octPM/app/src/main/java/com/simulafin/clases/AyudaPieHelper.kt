package com.simulafin.clases

import android.view.MotionEvent
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import com.simulafin.R

/**
 * Función global para presentar el mensaje de ayuda en el pie de página de cualquier actividad.
 */
fun AppCompatActivity.presentaPie(mensaje: String) {
    val txvPie = findViewById<TextView>(R.id.txvPiePagina)
        ?: findViewById<TextView>(R.id.textView2) //cambiar a txt definido
        ?: findViewById<TextView>(R.id.textView)
        ?: findViewById<TextView>(R.id.tvExplicacionResumen)
    
    txvPie?.text = mensaje
}

/**
 * Función para mostrar/ocultar la contraseña en el cuadro de input al hacer clic en el icono de ojo.
 */
fun EditText.presentaClave() {
    val eyeDrawable = AppCompatResources.getDrawable(context, R.drawable.ic_eye)
    this.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, eyeDrawable, null)

    var visible = false
    this.setOnTouchListener { _, event ->
        if (event.action == MotionEvent.ACTION_UP) {
            val drawableRight = this.compoundDrawablesRelative[2]
            if (drawableRight != null) {
                val boundLeft = this.width - this.paddingRight - drawableRight.intrinsicWidth
                if (event.rawX >= (this.left + boundLeft)) {
                    visible = !visible
                    if (visible) {
                        this.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    } else {
                        this.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
                    }
                    this.setSelection(this.text.length)
                    this.performClick()
                    return@setOnTouchListener true
                }
            }
        }
        false
    }
}
