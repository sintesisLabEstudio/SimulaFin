package com.simulafin

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaClave
import com.simulafin.clases.presentaPie
import java.io.File
import java.io.FileOutputStream

class RespaldoActivity : AppCompatActivity() {

    // Launcher para seleccionar y cargar un archivo de base de datos externo (.db)
    private val abrirArchivoLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val exito = cargaBdSim(uri.toString())
            if (exito) {
                Toast.makeText(this, "Base de datos cargada con éxito desde el archivo seleccionado", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Error al cargar la base de datos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Launcher para guardar una copia de respaldo en una ubicación personalizada
    private val crearArchivoLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        if (uri != null) {
            val exito = copiarBdAUri(uri)
            if (exito) {
                Toast.makeText(this, "Respaldo guardado con éxito en la ubicación seleccionada", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Error al guardar el respaldo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_respaldo)

        presentaPie("Gestor de Respaldo: Permite respaldar, recuperar o cargar bases de datos.")

        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        val btnRespaldar = findViewById<Button>(R.id.btnRespaldar)
        val btnRecuperar = findViewById<Button>(R.id.btnRecuperar)
        val btnVaciaBaseDatos = findViewById<Button>(R.id.btnVaciaBaseDatos)

        // Botón Respaldar
        btnRespaldar.setOnClickListener {
            val opciones = arrayOf(
                "Guardar en Descargas (simulafin_backup.db)",
                "Elegir ubicación personalizada..."
            )
            AlertDialog.Builder(this)
                .setTitle("Respaldar Base de Datos")
                .setItems(opciones) { _, which ->
                    val dbHelper = BaseDatosHelper(this)
                    val cantUsuarios = dbHelper.obtenerCantidadUsuarios()
                    when (which) {
                        0 -> {
                            val exito = respaldaBDSim("")
                            if (exito) {
                                Toast.makeText(this, "Respaldo guardado en Descargas con éxito (Usuarios en BD: $cantUsuarios)", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(this, "Error al crear el respaldo", Toast.LENGTH_SHORT).show()
                            }
                        }
                        1 -> {
                            crearArchivoLauncher.launch("simulafin_backup.db")
                        }
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        // Botón Recuperar / Cargar Base de Datos
        btnRecuperar.setOnClickListener {
            val opciones = arrayOf(
                "Cargar desde Descargas (simulafin_backup.db)",
                "Generar y Cargar baseParaAnalisis.db (Análisis Sercotec)",
                "Elegir archivo para importar..."
            )
            AlertDialog.Builder(this)
                .setTitle("Recuperar / Cargar Base de Datos")
                .setItems(opciones) { _, which ->
                    val dbHelper = BaseDatosHelper(this)
                    when (which) {
                        0 -> {
                            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                                ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                            val archivoDescargas = File(downloadsDir, "simulafin_backup.db")

                            if (archivoDescargas.exists()) {
                                val exito = cargaBdSim(archivoDescargas.absolutePath)
                                if (exito) {
                                    Toast.makeText(this, "Base de datos cargada con éxito desde Descargas", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(this, "Error al cargar la base de datos desde Descargas", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(this, "No se encontró el archivo 'simulafin_backup.db' en Descargas", Toast.LENGTH_LONG).show()
                            }
                        }
                        1 -> {
                            val exito = dbHelper.generaBaseDatosParaAnalisis()
                            if (exito) {
                                Toast.makeText(this, "Base de datos 'baseParaAnalisis.db' generada y cargada con éxito", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(this, "Error al generar baseParaAnalisis.db", Toast.LENGTH_SHORT).show()
                            }
                        }
                        2 -> {
                            abrirArchivoLauncher.launch(arrayOf("*/*"))
                        }
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        // Botón Vaciar Base de Datos
        btnVaciaBaseDatos.setOnClickListener {
            mostrarDialogPasswordAdmin {
                val dbHelper = BaseDatosHelper(this)
                dbHelper.vaciarTodaLaBaseDatos()
                Toast.makeText(
                    this,
                    "Base de datos vaciada completamente (0 usuarios). El primer usuario que se registre será el Administrador.",
                    Toast.LENGTH_LONG
                ).show()

                // Cerrar la aplicación para forzar un nuevo inicio desde cero
                finishAffinity()
            }
        }
    }

    private fun respaldaBDSim(rutaFin: String): Boolean {
        return try {
            val dbHelper = BaseDatosHelper(this)
            dbHelper.close()

            val dbFile = getDatabasePath(BaseDatosHelper.DATABASE_NAME)
            if (!dbFile.exists()) {
                dbHelper.writableDatabase.close()
            }

            val archivoDestino = if (rutaFin.isNotEmpty()) {
                File(rutaFin)
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                File(downloadsDir, "simulafin_backup.db")
            }

            archivoDestino.parentFile?.mkdirs()
            dbFile.copyTo(archivoDestino, overwrite = true)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun cargaBdSim(rutaOrigen: String): Boolean {
        return try {
            val dbHelper = BaseDatosHelper(this)
            dbHelper.close()
            deleteDatabase(BaseDatosHelper.DATABASE_NAME)

            val dbDestino = getDatabasePath(BaseDatosHelper.DATABASE_NAME)
            dbDestino.parentFile?.mkdirs()

            if (rutaOrigen.startsWith("content://")) {
                val uri = Uri.parse(rutaOrigen)
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(dbDestino).use { output ->
                        input.copyTo(output)
                    }
                } ?: return false
            } else {
                val archivoOrigen = File(rutaOrigen)
                if (!archivoOrigen.exists()) return false
                archivoOrigen.copyTo(dbDestino, overwrite = true)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun copiarBdAUri(uriDestino: Uri): Boolean {
        return try {
            val dbFile = getDatabasePath(BaseDatosHelper.DATABASE_NAME)
            if (!dbFile.exists()) {
                val helper = BaseDatosHelper(this)
                helper.writableDatabase.close()
            }
            contentResolver.openOutputStream(uriDestino)?.use { output ->
                dbFile.inputStream().use { input ->
                    input.copyTo(output)
                }
            } ?: return false
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun mostrarDialogPasswordAdmin(onValid: () -> Unit) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Autorización de Administrador")
        builder.setMessage("Ingrese la contraseña de administrador para continuar:")

        val input = EditText(this).apply {
            hint = "Contraseña de admin"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(50, 30, 50, 30)
            presentaClave()
        }
        builder.setView(input)

        builder.setPositiveButton("Verificar") { dialog, _ ->
            val password = input.text.toString().trim()
            val dbHelper = BaseDatosHelper(this)
            if (dbHelper.verificarPasswordAdmin(password)) {
                dialog.dismiss()
                onValid()
            } else {
                Toast.makeText(this, "Contraseña de administrador incorrecta", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }
}
