package com.simulafin.fragments

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.simulafin.R
import com.simulafin.clases.Cuenta
import com.simulafin.clases.Item
import com.simulafin.clases.Simulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.controller.SimulacionController
import com.simulafin.interfaces.OnSimulacionDatosListener
import com.simulafin.interfaces.SimulacionControllerProvider

class SimulacionInputFragment : Fragment() {
    private lateinit var spnSimulacion: Spinner
    private lateinit var adapterSimulacion: ArrayAdapter<String>
    private val listaSimulaciones = mutableListOf<String>()
    private val listaSimulacionesBD = mutableListOf<Simulacion>()

    private lateinit var spnCuenta: Spinner
    private lateinit var adapterCuenta: ArrayAdapter<String>
    private val listaCuentas = mutableListOf<String>()
    private val listaCuentasBD = mutableListOf<Cuenta>()

    private lateinit var spnItems: Spinner
    private lateinit var adapterItem: ArrayAdapter<String>
    private val listaItems = mutableListOf<String>()
    private val listaItemsBD = mutableListOf<Item>()

    private lateinit var txtTotalCuenta: EditText
    private lateinit var txtValorItem: EditText
    private lateinit var lstItemsSeleccionados: ListView
    private lateinit var adapterListado: ArrayAdapter<String>
    private val listaItemsAgregados = mutableListOf<String>()
    private var listener: OnSimulacionDatosListener? = null

    private lateinit var controller: SimulacionController
    private var idUsuarioActivo: Int = 1
    private var isUpdatingCuentasProgrammatically: Boolean = false

    fun getSimulacionSeleccionada(): String = spnSimulacion.selectedItem?.toString() ?: ""
    fun getCuentaSeleccionada(): String = spnCuenta.selectedItem?.toString() ?: ""
    fun getTotalCuenta(): Long = txtTotalCuenta.text.toString().replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
    fun getListaItemsAgregados(): List<String> = listaItemsAgregados
    fun getDetallesParaGuardar(): List<Pair<String, Int>>? {
        val detalles = mutableListOf<Pair<String, Int>>()
        for (item in listaItemsAgregados) {
            val separador = item.lastIndexOf('-')
            if (separador <= 0) return null

            val nombre = item.substring(0, separador).trim()
            val valor = item.substring(separador + 1).replace("[^0-9]".toRegex(), "").toIntOrNull()
                ?: return null
            if (nombre.isBlank()) return null
            detalles.add(nombre to valor)
        }
        return detalles
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context !is OnSimulacionDatosListener || context !is SimulacionControllerProvider) {
            throw IllegalStateException("La actividad debe implementar los contratos de simulación.")
        }
        listener = context
        controller = context.getSimulacionController()
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_simulacion_input, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        idUsuarioActivo = controller.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)

        spnSimulacion = view.findViewById(R.id.spnSimulacion)
        spnCuenta = view.findViewById(R.id.spnCuenta)
        spnItems = view.findViewById(R.id.spnItems)

        txtTotalCuenta = view.findViewById(R.id.txtTotalCuenta)
        txtValorItem = view.findViewById(R.id.txtValorItem)

        val btnNuevaSim = view.findViewById<Button>(R.id.btnNuevaSim)
        val btnEliminaSim = view.findViewById<Button>(R.id.btnEliminaSim)
        val btnNuevaCuenta = view.findViewById<Button>(R.id.btnNuevaCuenta)
        val btnEliminaCuenta = view.findViewById<Button>(R.id.btnEliminaCuenta)
        val btnGrabaValorCta = view.findViewById<Button>(R.id.btnGrabaValorCta)
        val btnNuevoItem = view.findViewById<Button>(R.id.btnNuevoItem)
        val btnEliminaItem = view.findViewById<Button>(R.id.btnEliminaItem)
        val btnAgregaItem = view.findViewById<Button>(R.id.btnAgregaItem)
        val btnEliminarItem = view.findViewById<Button>(R.id.btnAgregaItem2)
        lstItemsSeleccionados = view.findViewById(R.id.lstItemsSeleccionados)

        adapterSimulacion = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listaSimulaciones)
        adapterSimulacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSimulacion.adapter = adapterSimulacion

        adapterCuenta = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listaCuentas)
        adapterCuenta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnCuenta.adapter = adapterCuenta

        adapterItem = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listaItems)
        adapterItem.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnItems.adapter = adapterItem

        cargarDatosDesdeBD()

        adapterListado = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_single_choice,
            listaItemsAgregados
        )
        lstItemsSeleccionados.adapter = adapterListado
        lstItemsSeleccionados.choiceMode = ListView.CHOICE_MODE_SINGLE

        spnSimulacion.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position > 0 && position <= listaSimulacionesBD.size) {
                    val simObj = listaSimulacionesBD[position - 1]

                    // Presentar la cuenta asociada
                    val cuentaObj = listaCuentasBD.find { it.idCuenta == simObj.idCuenta }
                    if (cuentaObj != null) {
                        val cuentaIndex = listaCuentasBD.indexOf(cuentaObj)
                        spnCuenta.setSelection(cuentaIndex + 1)
                        txtTotalCuenta.setText(cuentaObj.totalCuenta.toString())
                    } else {
                        txtTotalCuenta.setText(simObj.totalDisponible.toString())
                    }

                    // Cargar los items en la lista lstItemsSeleccionados
                    listaItemsAgregados.clear()
                    val detallesBD = controller.obtenerDetallesSimulacion(simObj.idSim)
                    for (det in detallesBD) {
                        listaItemsAgregados.add("${det.nombreItem} - $${det.valorItem}")
                    }
                    adapterListado.notifyDataSetChanged()
                } else {
                    txtTotalCuenta.setText("")
                    listaItemsAgregados.clear()
                    adapterListado.notifyDataSetChanged()
                }

                recalcularYNotificar(mostrarToast = false)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        spnCuenta.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (isUpdatingCuentasProgrammatically) return

                if (position == 0) {
                    txtTotalCuenta.setText("")
                } else {
                    val cuentaObj = listaCuentasBD.getOrNull(position - 1)
                    if (cuentaObj != null) {
                        txtTotalCuenta.setText(cuentaObj.totalCuenta.toString())
                    }
                }
                notificarTotalGastos()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        spnItems.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    txtValorItem.setText("")
                } else {
                    val itemObj = listaItemsBD.getOrNull(position - 1)
                    if (itemObj != null) {
                        txtValorItem.setText(itemObj.valorItem.toString())
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        txtTotalCuenta.setSelectAllOnFocus(true)
        txtTotalCuenta.setOnClickListener { txtTotalCuenta.selectAll() }

        txtValorItem.setSelectAllOnFocus(true)
        txtValorItem.setOnClickListener { txtValorItem.selectAll() }

        btnNuevaSim.setOnClickListener { mostrarDialogNuevaSimulacion() }
        btnEliminaSim?.setOnClickListener { eliminarSimulacionSeleccionada() }
        btnNuevaCuenta.setOnClickListener { mostrarDialogNuevaCuenta() }
        btnEliminaCuenta?.setOnClickListener { eliminarCuentaSeleccionada() }
        btnGrabaValorCta?.setOnClickListener { grabarValorCuentaSeleccionada() }
        btnNuevoItem.setOnClickListener { mostrarDialogNuevoItem() }
        btnEliminaItem?.setOnClickListener { eliminarItemSeleccionado() }

        btnAgregaItem.setOnClickListener {
            val itemSeleccionado = spnItems.selectedItem?.toString() ?: ""
            val monto = txtValorItem.text.toString().trim()

            if (spnItems.selectedItemPosition == 0 || itemSeleccionado.isEmpty()) {
                Toast.makeText(requireContext(), "Por favor seleccione un ítem válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (monto.isEmpty()) {
                Toast.makeText(requireContext(), "Por favor ingrese el monto del ítem", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val registro = "$itemSeleccionado - $$monto"
            listaItemsAgregados.add(registro)
            adapterListado.notifyDataSetChanged()
            spnItems.setSelection(0)
            txtValorItem.text.clear()

            notificarTotalGastos()
        }

        btnEliminarItem.setOnClickListener {
            val pos = lstItemsSeleccionados.checkedItemPosition
            if (pos != ListView.INVALID_POSITION && pos >= 0 && pos < listaItemsAgregados.size) {
                val eliminado = listaItemsAgregados.removeAt(pos)
                adapterListado.notifyDataSetChanged()
                lstItemsSeleccionados.clearChoices()
                notificarTotalGastos()
                Toast.makeText(requireContext(), "Eliminado: $eliminado", Toast.LENGTH_SHORT).show()
            } else if (listaItemsAgregados.isNotEmpty()) {
                val eliminado = listaItemsAgregados.removeAt(listaItemsAgregados.size - 1)
                adapterListado.notifyDataSetChanged()
                lstItemsSeleccionados.clearChoices()
                notificarTotalGastos()
                Toast.makeText(requireContext(), "Eliminado: $eliminado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "No hay ítems para eliminar", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun cargarDatosDesdeBD() {
        cargarSimulacionesDesdeBD()
        cargarCuentasDesdeBD()
        cargarItemsDesdeBD()
    }

    private fun cargarSimulacionesDesdeBD() {
        val seleccionPrev = spnSimulacion.selectedItem?.toString() ?: ""
        listaSimulacionesBD.clear()
        listaSimulaciones.clear()
        val simulaciones = controller.obtenerSimulaciones(idUsuarioActivo)
        if (simulaciones.isEmpty()) {
            listaSimulaciones.add("No hay simulaciones guardadas")
        } else {
            listaSimulaciones.add("Seleccione la simulación")
            listaSimulacionesBD.addAll(simulaciones)
            for (sim in simulaciones) {
                if (!listaSimulaciones.contains(sim.nombreSim)) {
                    listaSimulaciones.add(sim.nombreSim)
                }
            }
        }
        adapterSimulacion.notifyDataSetChanged()
        val index = listaSimulaciones.indexOf(seleccionPrev)
        if (index > 0) {
            spnSimulacion.setSelection(index)
        }
    }

    private fun cargarCuentasDesdeBD(preservarPosicion: Int = -1, preservarMonto: String? = null) {
        val posActual = if (preservarPosicion > 0) preservarPosicion else spnCuenta.selectedItemPosition
        val seleccionPrev = if (posActual > 0 && posActual <= listaCuentasBD.size) {
            listaCuentasBD[posActual - 1].nombreCuenta
        } else {
            spnCuenta.selectedItem?.toString() ?: ""
        }

        isUpdatingCuentasProgrammatically = true
        listaCuentasBD.clear()
        listaCuentas.clear()
        val cuentas = controller.obtenerCuentas(idUsuarioActivo)
        if (cuentas.isEmpty()) {
            listaCuentas.add("No hay cuentas guardadas")
        } else {
            listaCuentas.add("Seleccione la cuenta")
            listaCuentasBD.addAll(cuentas)
            for (cta in cuentas) {
                if (!listaCuentas.contains(cta.nombreCuenta)) {
                    listaCuentas.add(cta.nombreCuenta)
                }
            }
        }
        adapterCuenta.notifyDataSetChanged()

        val index = if (preservarPosicion > 0 && preservarPosicion < listaCuentas.size) {
            preservarPosicion
        } else {
            listaCuentas.indexOf(seleccionPrev)
        }

        if (index > 0) {
            spnCuenta.setSelection(index)
            val cuentaActualizada = listaCuentasBD.getOrNull(index - 1)
            if (preservarMonto != null) {
                txtTotalCuenta.setText(preservarMonto)
            } else if (cuentaActualizada != null) {
                txtTotalCuenta.setText(cuentaActualizada.totalCuenta.toString())
            }
        }
        isUpdatingCuentasProgrammatically = false
    }

    private fun cargarItemsDesdeBD() {
        val seleccionPrev = spnItems.selectedItem?.toString() ?: ""
        listaItemsBD.clear()
        listaItems.clear()
        val items = controller.obtenerItems(idUsuarioActivo)
        if (items.isEmpty()) {
            listaItems.add("No hay ítems guardados")
        } else {
            listaItems.add("Seleccione el Item")
            listaItemsBD.addAll(items)
            for (itemObj in items) {
                if (!listaItems.contains(itemObj.nombreItem)) {
                    listaItems.add(itemObj.nombreItem)
                }
            }
        }
        adapterItem.notifyDataSetChanged()
        val index = listaItems.indexOf(seleccionPrev)
        if (index > 0) {
            spnItems.setSelection(index)
        }
    }

    /**
     * Vacía todas las selecciones y campos de entrada en SimulacionInputFragment.
     */
    fun limpiaSimulacionInput() {
        if (::spnSimulacion.isInitialized) spnSimulacion.setSelection(0)
        if (::spnCuenta.isInitialized) spnCuenta.setSelection(0)
        if (::spnItems.isInitialized) spnItems.setSelection(0)
        if (::txtTotalCuenta.isInitialized) txtTotalCuenta.setText("")
        if (::txtValorItem.isInitialized) txtValorItem.setText("")
        listaItemsAgregados.clear()
        if (::lstItemsSeleccionados.isInitialized) {
            lstItemsSeleccionados.clearChoices()
        }
        if (::adapterListado.isInitialized) {
            adapterListado.notifyDataSetChanged()
        }
        recalcularYNotificar(mostrarToast = false)
    }

    fun recalcularYNotificar(mostrarToast: Boolean = true) {
        var total = 0L
        for (item in listaItemsAgregados) {
            val m = item.substringAfter("-").replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
            total += m
        }
        val totalCtaStr = txtTotalCuenta.text.toString().trim()
        val totalCuenta = totalCtaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
        listener?.onDatosSimulacionIngresados(total, totalCuenta)

        if (mostrarToast) {
            Toast.makeText(requireContext(), "Valores recalculados con éxito", Toast.LENGTH_SHORT).show()
        }
    }

    fun eliminarSimulacionSeleccionada() {
        val pos = spnSimulacion.selectedItemPosition
        if (pos <= 0 || pos > listaSimulacionesBD.size) {
            Toast.makeText(requireContext(), "Por favor seleccione una simulación válida para eliminar", Toast.LENGTH_SHORT).show()
            return
        }

        val simObj = listaSimulacionesBD.getOrNull(pos - 1)
        if (simObj != null) {
            val builder = AlertDialog.Builder(requireContext())
            builder.setTitle("Alerta de Eliminación")
            builder.setMessage("¿Está seguro de que desea eliminar la simulación '${simObj.nombreSim}' y sus registros asociados de la base de datos?")

            builder.setPositiveButton("Eliminar") { dialog, _ ->
                val exito = controller.eliminarSimulacion(simObj.idSim)
                if (exito) {
                    Toast.makeText(requireContext(), "Simulación '${simObj.nombreSim}' eliminada de la base de datos", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "Error al eliminar la simulación de la base de datos", Toast.LENGTH_SHORT).show()
                }

                cargarSimulacionesDesdeBD()
                spnSimulacion.setSelection(0)
                txtTotalCuenta.setText("")
                listaItemsAgregados.clear()
                adapterListado.notifyDataSetChanged()

                recalcularYNotificar(mostrarToast = false)
                dialog.dismiss()
            }

            builder.setNegativeButton("Cancelar") { dialog, _ ->
                dialog.cancel()
            }

            builder.show()
        }
    }

    fun grabarValorCuentaSeleccionada() {
        val pos = spnCuenta.selectedItemPosition
        val ctx = context ?: return
        if (pos <= 0 || pos > listaCuentasBD.size) {
            Toast.makeText(ctx, "Por favor seleccione una cuenta válida para actualizar su valor", Toast.LENGTH_SHORT).show()
            return
        }

        val cuentaObj = listaCuentasBD.getOrNull(pos - 1)
        if (cuentaObj != null) {
            val nuevoValorStr = txtTotalCuenta.text.toString().trim()
            if (nuevoValorStr.isEmpty()) {
                Toast.makeText(ctx, "Por favor ingrese el monto/valor para la cuenta", Toast.LENGTH_SHORT).show()
                return
            }

            val nuevoMonto = nuevoValorStr.toIntOrNull() ?: 0

            val exito = controller.actualizarCuenta(cuentaObj.idCuenta, cuentaObj.nombreCuenta, nuevoMonto)
            if (exito) {
                Toast.makeText(ctx, "Monto de la cuenta '${cuentaObj.nombreCuenta}' actualizado a $$nuevoMonto con éxito", Toast.LENGTH_SHORT).show()
                cargarCuentasDesdeBD(preservarPosicion = pos, preservarMonto = nuevoMonto.toString())
                notificarTotalGastos()
            } else {
                Toast.makeText(ctx, "Error al actualizar el monto de la cuenta en la base de datos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun eliminarCuentaSeleccionada() {
        val pos = spnCuenta.selectedItemPosition
        val ctx = context ?: return
        if (pos <= 0 || pos > listaCuentasBD.size) {
            Toast.makeText(ctx, "Por favor seleccione una cuenta válida para eliminar", Toast.LENGTH_SHORT).show()
            return
        }

        val cuentaObj = listaCuentasBD.getOrNull(pos - 1)
        if (cuentaObj != null) {
            // 1. Validar en SQLite si la cuenta está asociada a alguna simulación
            var simOcupada = controller.cuentaOcupada(cuentaObj.idCuenta)

            // 2. Validar también en la lista de simulaciones en memoria
            if (simOcupada.isEmpty()) {
                val simEnMemoria = listaSimulacionesBD.find { it.idCuenta == cuentaObj.idCuenta }
                if (simEnMemoria != null) {
                    simOcupada = simEnMemoria.nombreSim
                }
            }

            // 3. Validar si hay una simulación seleccionada activamente en pantalla
            if (simOcupada.isEmpty() && spnSimulacion.selectedItemPosition > 0) {
                val simActual = listaSimulacionesBD.getOrNull(spnSimulacion.selectedItemPosition - 1)
                if (simActual != null && (simActual.idCuenta == cuentaObj.idCuenta || spnCuenta.selectedItemPosition == pos)) {
                    simOcupada = simActual.nombreSim
                }
            }

            if (simOcupada.isNotEmpty()) {
                val builder = AlertDialog.Builder(ctx)

                val tvTitle = android.widget.TextView(ctx).apply {
                    text = "⚠️ OPERACIÓN DENEGADA"
                    setTextColor(android.graphics.Color.RED)
                    textSize = 18f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setPadding(50, 40, 50, 10)
                }

                val tvMessage = android.widget.TextView(ctx).apply {
                    text = "La cuenta '${cuentaObj.nombreCuenta}' no se puede eliminar porque está comprometida en la simulación '$simOcupada'."
                    setTextColor(android.graphics.Color.RED)
                    textSize = 15f
                    setPadding(50, 20, 50, 30)
                }

                builder.setCustomTitle(tvTitle)
                builder.setView(tvMessage)
                builder.setPositiveButton("Aceptar") { dialog, _ ->
                    dialog.dismiss()
                }
                builder.show()

                // PROHIBIDO CONTINUAR: Retorno inmediato sin borrar la cuenta
                return
            }

            val builder = AlertDialog.Builder(ctx)
            builder.setTitle("Alerta de Eliminación")
            builder.setMessage("¿Está seguro de que desea eliminar la cuenta '${cuentaObj.nombreCuenta}' de la base de datos?")

            builder.setPositiveButton("Eliminar") { dialog, _ ->
                val exito = controller.eliminarCuenta(cuentaObj.idCuenta)
                if (exito) {
                    Toast.makeText(ctx, "Cuenta '${cuentaObj.nombreCuenta}' eliminada de la base de datos", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(ctx, "Error al eliminar la cuenta de la base de datos", Toast.LENGTH_SHORT).show()
                }

                cargarCuentasDesdeBD()
                spnCuenta.setSelection(0)
                txtTotalCuenta.setText("")
                listaItemsAgregados.clear()
                adapterListado.notifyDataSetChanged()

                recalcularYNotificar(mostrarToast = false)
                dialog.dismiss()
            }

            builder.setNegativeButton("Cancelar") { dialog, _ ->
                dialog.cancel()
            }

            builder.show()
        }
    }

    fun eliminarItemSeleccionado() {
        val pos = spnItems.selectedItemPosition
        val ctx = context ?: return
        if (pos <= 0 || pos > listaItemsBD.size) {
            Toast.makeText(ctx, "Por favor seleccione un ítem válido para eliminar de la base de datos", Toast.LENGTH_SHORT).show()
            return
        }

        val itemObj = listaItemsBD.getOrNull(pos - 1)
        if (itemObj != null) {
            eliminarItem(itemObj.idItem)
        }
    }

    fun eliminarItem(idItem: Int) {
        val ctx = context ?: return
        val simNombre = controller.itemOcupado(idItem)
        val itemObj = listaItemsBD.find { it.idItem == idItem }
        val nombreItem = itemObj?.nombreItem ?: "el ítem"

        if (simNombre.isNotEmpty()) {
            val builder = AlertDialog.Builder(ctx)

            val tvTitle = android.widget.TextView(ctx).apply {
                text = "⚠️ OPERACIÓN DENEGADA"
                setTextColor(android.graphics.Color.RED)
                textSize = 18f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(50, 40, 50, 10)
            }

            val tvMessage = android.widget.TextView(ctx).apply {
                text = "El ítem '$nombreItem' no se puede eliminar porque está ocupado por la simulación '$simNombre'."
                setTextColor(android.graphics.Color.RED)
                textSize = 15f
                setPadding(50, 20, 50, 30)
            }

            builder.setCustomTitle(tvTitle)
            builder.setView(tvMessage)
            builder.setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        } else {
            val builder = AlertDialog.Builder(ctx)
            builder.setTitle("Alerta de Eliminación")
            builder.setMessage("¿Está seguro de que desea eliminar el ítem '$nombreItem' de la base de datos?")

            builder.setPositiveButton("Eliminar") { dialog, _ ->
                val exito = controller.eliminarItem(idItem)
                if (exito) {
                    Toast.makeText(ctx, "Ítem '$nombreItem' eliminado con éxito", Toast.LENGTH_SHORT).show()

                    listaItemsBD.removeAll { it.idItem == idItem }
                    listaItems.removeAll { it.equals(nombreItem, ignoreCase = true) }
                    adapterItem.notifyDataSetChanged()

                    spnItems.setSelection(0)
                    txtValorItem.setText("")
                } else {
                    Toast.makeText(requireContext(), "Error al eliminar el ítem de la base de datos", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }

            builder.setNegativeButton("Cancelar") { dialog, _ ->
                dialog.cancel()
            }

            builder.show()
        }
    }

    private fun notificarTotalGastos() {
        var total = 0L
        for (item in listaItemsAgregados) {
            val m = item.substringAfter("-").replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
            total += m
        }
        val totalCtaStr = txtTotalCuenta.text.toString().trim()
        val totalCuenta = totalCtaStr.replace("[^0-9]".toRegex(), "").toLongOrNull() ?: 0L
        listener?.onDatosSimulacionIngresados(total, totalCuenta)
    }

    fun mostrarDialogNuevaSimulacion() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Nueva Simulación")

        val input = EditText(requireContext())
        input.hint = "Ingrese nombre de la simulación"
        input.setPadding(40, 30, 40, 30)
        builder.setView(input)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaSim = input.text.toString().trim()
            if (nuevaSim.isNotEmpty()) {
                val posCta = spnCuenta.selectedItemPosition
                val idCtaDef = if (posCta > 0) {
                    listaCuentasBD.getOrNull(posCta - 1)?.idCuenta ?: (listaCuentasBD.firstOrNull()?.idCuenta ?: 1)
                } else {
                    listaCuentasBD.firstOrNull()?.idCuenta ?: 1
                }
                controller.insertarSimulacion(idCtaDef, idUsuarioActivo, nuevaSim, 1000000, 0, 12, 1000000)
                cargarSimulacionesDesdeBD()
                val index = listaSimulaciones.indexOf(nuevaSim)
                if (index != -1) {
                    spnSimulacion.setSelection(index)
                } else if (listaSimulaciones.size > 1) {
                    spnSimulacion.setSelection(1)
                }
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
        builder.show()
    }

    private fun mostrarDialogNuevaCuenta() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Nueva Cuenta y Valor")

        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(requireContext()).apply {
            hint = "Nombre de la nueva cuenta"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(requireContext()).apply {
            hint = "Monto/Valor de la cuenta"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevaCta = inputNombre.text.toString().trim()
            val valorCta = inputValor.text.toString().trim()

            if (nuevaCta.isNotEmpty() && valorCta.isNotEmpty()) {
                val montoNum = valorCta.toIntOrNull() ?: 0
                controller.insertarCuenta(idUsuarioActivo, nuevaCta, montoNum)
                cargarCuentasDesdeBD()
                val index = listaCuentas.indexOf(nuevaCta)
                if (index != -1) {
                    spnCuenta.setSelection(index)
                } else if (listaCuentas.size > 1) {
                    spnCuenta.setSelection(1)
                }
                txtTotalCuenta.setText(valorCta)
                notificarTotalGastos()
            } else {
                Toast.makeText(requireContext(), "Debe ingresar nombre y valor de la cuenta", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
        builder.show()
    }

    private fun mostrarDialogNuevoItem() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Nuevo Ítem y Valor")

        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 40)
        }

        val inputNombre = EditText(requireContext()).apply {
            hint = "Nombre del nuevo ítem"
            setPadding(0, 0, 0, 30)
        }
        layout.addView(inputNombre)

        val inputValor = EditText(requireContext()).apply {
            hint = "Monto/Valor del ítem"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(inputValor)

        builder.setView(layout)

        builder.setPositiveButton("OK") { dialog, _ ->
            val nuevoItem = inputNombre.text.toString().trim()
            val valorItem = inputValor.text.toString().trim()

            if (nuevoItem.isNotEmpty() && valorItem.isNotEmpty()) {
                val montoNum = valorItem.toIntOrNull() ?: 0
                controller.insertarItem(idUsuarioActivo, nuevoItem, montoNum)
                cargarItemsDesdeBD()
                val index = listaItems.indexOf(nuevoItem)
                if (index != -1) {
                    spnItems.setSelection(index)
                }
                txtValorItem.setText(valorItem)
            } else {
                Toast.makeText(requireContext(), "Debe ingresar nombre y valor del ítem", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.cancel() }
        builder.show()
    }
}
