package com.simulafin.controller

import android.database.sqlite.SQLiteException
import com.simulafin.clases.Cuenta
import com.simulafin.clases.DetalleSimulacion
import com.simulafin.clases.Item
import com.simulafin.clases.Simulacion
import com.simulafin.data.SimulacionRepository
import com.simulafin.domain.DetalleSimulacionEntrada
import com.simulafin.domain.SimulacionCalculo

data class GuardarSimulacionCommand(
    val idUsuario: Int,
    val nombreSimulacion: String,
    val nombreCuenta: String,
    val totalDisponible: Long,
    val detalles: List<DetalleSimulacionEntrada>
)

sealed class GuardarSimulacionResultado {
    object RequiereConfirmacionSobrescritura : GuardarSimulacionResultado()
    data class Guardada(val idSimulacion: Int) : GuardarSimulacionResultado()
    data class Rechazada(val mensaje: String) : GuardarSimulacionResultado()
    data class Error(val mensaje: String) : GuardarSimulacionResultado()
}

class SimulacionController(
    private val repository: SimulacionRepository
) {
    fun obtenerIdUsuarioActivo(nombreUsuario: String): Int =
        repository.obtenerIdUsuarioActivo(nombreUsuario)

    fun obtenerNombreUsuarioActivo(nombreUsuario: String): String =
        repository.obtenerNombreUsuarioActivo(nombreUsuario)

    fun obtenerSimulaciones(idUsuario: Int): List<Simulacion> =
        repository.obtenerSimulaciones(idUsuario)

    fun obtenerCuentas(idUsuario: Int): List<Cuenta> =
        repository.obtenerCuentas(idUsuario)

    fun obtenerItems(idUsuario: Int): List<Item> =
        repository.obtenerItems(idUsuario)

    fun obtenerDetallesSimulacion(idSimulacion: Int): List<DetalleSimulacion> =
        repository.obtenerDetallesSimulacion(idSimulacion)

    fun eliminarSimulacion(idSimulacion: Int): Boolean =
        repository.eliminarSimulacion(idSimulacion)

    fun actualizarCuenta(idCuenta: Int, nombre: String, total: Int): Boolean =
        repository.actualizarCuenta(idCuenta, nombre, total)

    fun cuentaOcupada(idCuenta: Int): String =
        repository.cuentaOcupada(idCuenta)

    fun eliminarCuenta(idCuenta: Int): Boolean =
        repository.eliminarCuenta(idCuenta)

    fun itemOcupado(idItem: Int): String =
        repository.itemOcupado(idItem)

    fun eliminarItem(idItem: Int): Boolean =
        repository.eliminarItem(idItem)

    fun insertarSimulacion(
        idCuenta: Int,
        idUsuario: Int,
        nombre: String,
        totalDisponible: Int,
        totalEgresos: Int,
        meses: Int,
        excedente: Int
    ): Long = repository.insertarSimulacion(
        idCuenta,
        idUsuario,
        nombre,
        totalDisponible,
        totalEgresos,
        meses,
        excedente
    )

    fun insertarCuenta(idUsuario: Int, nombre: String, total: Int): Boolean =
        repository.insertarCuenta(idUsuario, nombre, total)

    fun insertarItem(idUsuario: Int, nombre: String, valor: Int): Boolean =
        repository.insertarItem(idUsuario, nombre, valor)

    fun guardar(
        command: GuardarSimulacionCommand,
        sobrescribirConfirmado: Boolean = false
    ): GuardarSimulacionResultado {
        validar(command)?.let { return GuardarSimulacionResultado.Rechazada(it) }
        val nombreSimulacion = command.nombreSimulacion.trim()
        val nombreCuenta = command.nombreCuenta.trim()
        val detalles = command.detalles.map { it.copy(nombreItem = it.nombreItem.trim()) }

        val resultadoCalculo = try {
            SimulacionCalculo.calcular(command.totalDisponible, detalles)
        } catch (_: ArithmeticException) {
            return GuardarSimulacionResultado.Rechazada("El total de los ítems excede el valor permitido.")
        }

        if (!valoresPersistibles(command, resultadoCalculo.totalEgresos, resultadoCalculo.meses, resultadoCalculo.excedente)) {
            return GuardarSimulacionResultado.Rechazada("Uno o más montos exceden el valor permitido para guardar.")
        }

        return try {
            val idCuenta = repository.obtenerIdCuenta(command.idUsuario, nombreCuenta)
                ?: return GuardarSimulacionResultado.Rechazada("Seleccione una cuenta válida antes de guardar.")

            val idExistente = repository.obtenerSimulacionId(command.idUsuario, nombreSimulacion)
            if (
                !sobrescribirConfirmado &&
                idExistente != null &&
                repository.tieneDetalles(idExistente)
            ) {
                return GuardarSimulacionResultado.RequiereConfirmacionSobrescritura
            }

            val idSimulacion = repository.guardarCompleta(
                idUsuario = command.idUsuario,
                idCuenta = idCuenta,
                nombreSimulacion = nombreSimulacion,
                totalDisponible = command.totalDisponible.toInt(),
                resultado = resultadoCalculo,
                detalles = detalles
            )
            GuardarSimulacionResultado.Guardada(idSimulacion)
        } catch (_: SQLiteException) {
            GuardarSimulacionResultado.Error("No se pudo guardar la simulación. No se guardaron cambios parciales.")
        }
    }

    private fun validar(command: GuardarSimulacionCommand): String? {
        if (command.idUsuario <= 0) return "No se pudo identificar al usuario activo."
        if (command.nombreSimulacion.isBlank()) return "Ingrese o seleccione una simulación válida."
        if (command.nombreCuenta.isBlank()) return "Seleccione una cuenta válida antes de guardar."
        if (command.totalDisponible < 0) return "El monto de la cuenta no puede ser negativo."
        if (command.detalles.isEmpty()) return "Debe agregar al menos un ítem para guardar la simulación."
        if (command.detalles.any { it.nombreItem.trim().isEmpty() || it.valorItem < 0 }) {
            return "Revise los nombres y montos de los ítems."
        }
        return null
    }

    private fun valoresPersistibles(
        command: GuardarSimulacionCommand,
        totalEgresos: Long,
        meses: Long,
        excedente: Long
    ): Boolean {
        return command.totalDisponible <= Int.MAX_VALUE &&
            totalEgresos <= Int.MAX_VALUE &&
            meses <= Int.MAX_VALUE &&
            excedente <= Int.MAX_VALUE
    }
}
