package com.simulafin.clases

data class Usuario(
    val idUsuario: Int = 0,
    val nombreUsuario: String = "",
    val claveUsuario: String = "",
    val fechaHoraUsuario: String = "",
    val esAdmin: Boolean = false,
    val preferenciaTema: String = ""
)
