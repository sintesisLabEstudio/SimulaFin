package com.simulafin

import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Simulacion
import com.simulafin.clases.DetalleSimulacion
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie
import com.simulafin.clases.toFormatoChile
import java.io.File
import java.io.FileOutputStream

class ConsultaSimulacionesActivity : AppCompatActivity() {

    //COMPONENTES
    private lateinit var spnSeleccionSim: Spinner
    private lateinit var txtValorSim: EditText
    private lateinit var tblValNombre: TextView
    private lateinit var tblValCuenta: TextView
    private lateinit var tblValFecha: TextView
    private lateinit var tblValDisponible: TextView
    private lateinit var tblValEgresos: TextView
    private lateinit var tblValMeses: TextView
    private lateinit var tblValExcedente: TextView
    private lateinit var lsvDetallesSim: ListView

    private lateinit var adapterSimulacion: ArrayAdapter<String>
    private val listaSimulaciones = mutableListOf<String>()
    private val listaSimulacionesBD = mutableListOf<Simulacion>()

    private lateinit var adapterDetalles: ArrayAdapter<String>
    private val listaDetallesStr = mutableListOf<String>()
    private lateinit var dbHelper: BaseDatosHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consulta_simulaciones)

        presentaPie("Módulo de consulta para revisar e inspeccionar simulaciones previamente guardadas en la base de datos.")

        dbHelper = BaseDatosHelper(this)

        val usuarioActivo = dbHelper.obtenerNombreUsuarioActivo(SesionUsuario.usuarioActivo)
        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario Activo: $usuarioActivo"

        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        spnSeleccionSim = findViewById(R.id.spnSeleccionSim)
        txtValorSim = findViewById(R.id.txtValorSim)
        tblValNombre = findViewById(R.id.tblValNombre)
        tblValCuenta = findViewById(R.id.tblValCuenta)
        tblValFecha = findViewById(R.id.tblValFecha)
        tblValDisponible = findViewById(R.id.tblValDisponible)
        tblValEgresos = findViewById(R.id.tblValEgresos)
        tblValMeses = findViewById(R.id.tblValMeses)
        tblValExcedente = findViewById(R.id.tblValExcedente)
        lsvDetallesSim = findViewById(R.id.lsvDetallesSim)

        adapterDetalles = ArrayAdapter(this, R.layout.item_detalle_simulacion, listaDetallesStr)
        lsvDetallesSim.adapter = adapterDetalles

        val btnExportarJson = findViewById<Button>(R.id.btnExportarJson)
        val btnExportaCSV = findViewById<Button>(R.id.btnExportaCSV)
        val btnImprimir = findViewById<Button>(R.id.btnImprimir)
        val btnEnviar = findViewById<Button>(R.id.btnEnviar)

        val idUsuarioActivo = dbHelper.obtenerIdUsuarioActivo(SesionUsuario.usuarioActivo)
        listaSimulaciones.clear()
        listaSimulacionesBD.clear()

        val simulacionesBD = dbHelper.obtenerSimulaciones(idUsuarioActivo)
        if (simulacionesBD.isEmpty()) {
            listaSimulaciones.add("No hay simulaciones guardadas")
            tblValNombre.text = "Sin datos"
        } else {
            listaSimulaciones.add("Seleccione la simulación")
            listaSimulacionesBD.addAll(simulacionesBD)
            for (sim in simulacionesBD) {
                if (!listaSimulaciones.contains(sim.nombreSim)) {
                    listaSimulaciones.add(sim.nombreSim)
                }
            }
        }

        adapterSimulacion = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listaSimulaciones
        )
        adapterSimulacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnSeleccionSim.adapter = adapterSimulacion

        spnSeleccionSim.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                SeleccionSim(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        txtValorSim.setSelectAllOnFocus(true)
        txtValorSim.setOnClickListener {
            txtValorSim.selectAll()
        }

        btnExportarJson.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            if (listaSimulacionesBD.isEmpty() || spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación válida a exportar", Toast.LENGTH_SHORT).show()
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                val defaultFileName = "simulacion_${sim.replace(" ", "_")}.json"
                val defaultFile = File(downloadsDir, defaultFileName)

                val builder = AlertDialog.Builder(this)
                builder.setTitle("Exportar Simulación a JSON")

                val input = EditText(this).apply {
                    setText(defaultFile.absolutePath)
                    setSelection(text.length)
                    setPadding(40, 30, 40, 30)
                }
                builder.setView(input)

                builder.setPositiveButton("Exportar") { dialog, _ ->
                    val rutaIngresada = input.text.toString().trim()
                    val rutaFinal = if (rutaIngresada.isNotEmpty()) rutaIngresada else defaultFile.absolutePath
                    val exito = exportaJson(rutaFinal)
                    if (exito) {
                        Toast.makeText(this, "Simulación y detalles exportados a JSON en:\n$rutaFinal", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "Error al exportar la simulación a JSON", Toast.LENGTH_SHORT).show()
                    }
                    dialog.dismiss()
                }

                builder.setNegativeButton("Cancelar") { dialog, _ ->
                    dialog.cancel()
                }

                builder.show()
            }
        }

        btnExportaCSV.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            if (listaSimulacionesBD.isEmpty() || spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación válida a exportar", Toast.LENGTH_SHORT).show()
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                val defaultFileName = "simulacion_${sim.replace(" ", "_")}.csv"
                val defaultFile = File(downloadsDir, defaultFileName)

                val builder = AlertDialog.Builder(this)
                builder.setTitle("Exportar Simulación a CSV")

                val input = EditText(this).apply {
                    setText(defaultFile.absolutePath)
                    setSelection(text.length)
                    setPadding(40, 30, 40, 30)
                }
                builder.setView(input)

                builder.setPositiveButton("Exportar") { dialog, _ ->
                    val rutaIngresada = input.text.toString().trim()
                    val rutaFinal = if (rutaIngresada.isNotEmpty()) rutaIngresada else defaultFile.absolutePath
                    val exito = exportaCSV(rutaFinal)
                    if (exito) {
                        Toast.makeText(this, "Simulación y detalles exportados a CSV en:\n$rutaFinal", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "Error al exportar la simulación a CSV", Toast.LENGTH_SHORT).show()
                    }
                    dialog.dismiss()
                }

                builder.setNegativeButton("Cancelar") { dialog, _ ->
                    dialog.cancel()
                }

                builder.show()
            }
        }

        btnImprimir.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            if (listaSimulacionesBD.isEmpty() || spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación válida para imprimir", Toast.LENGTH_SHORT).show()
            } else {
                val simObj = listaSimulacionesBD.getOrNull(spnSeleccionSim.selectedItemPosition - 1)
                if (simObj != null) {
                    val detalles = dbHelper.obtenerDetallesSimulacion(simObj.idSim)
                    val pdfFile = generarYVerPdfSimulacion(simObj, detalles)
                    if (pdfFile != null && pdfFile.exists()) {
                        try {
                            val uri = androidx.core.content.FileProvider.getUriForFile(
                                this,
                                "${packageName}.fileprovider",
                                pdfFile
                            )
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "application/pdf")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            startActivity(intent)
                            Toast.makeText(this, "Abriendo reporte PDF...", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(this, "PDF guardado en Descargas:\n${pdfFile.absolutePath}", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(this, "Error al generar el reporte PDF", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        btnEnviar.setOnClickListener {
            val sim = spnSeleccionSim.selectedItem?.toString() ?: ""
            val valSim = txtValorSim.text.toString().trim()
            if (listaSimulacionesBD.isEmpty() || spnSeleccionSim.selectedItemPosition == 0 || sim.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una simulación válida para enviar", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Enviando simulación $sim (Monto: $$valSim)...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun SeleccionSim(position: Int) {
        if (listaSimulacionesBD.isEmpty()) {
            txtValorSim.setText("")
            tblValNombre.text = "No hay datos"
            tblValCuenta.text = "---"
            tblValFecha.text = "---"
            tblValDisponible.text = "---"
            tblValEgresos.text = "---"
            tblValMeses.text = "---"
            tblValExcedente.text = "---"
            listaDetallesStr.clear()
            adapterDetalles.notifyDataSetChanged()
            return
        }

        if (position == 0) {
            txtValorSim.setText("")
            tblValNombre.text = "---"
            tblValCuenta.text = "---"
            tblValFecha.text = "---"
            tblValDisponible.text = "---"
            tblValEgresos.text = "---"
            tblValMeses.text = "---"
            tblValExcedente.text = "---"
            listaDetallesStr.clear()
            adapterDetalles.notifyDataSetChanged()
        } else {
            val simObj = listaSimulacionesBD.getOrNull(position - 1)
            if (simObj != null) {
                val nomCuenta = dbHelper.obtenerNombreCuentaPorId(simObj.idCuenta)
                txtValorSim.setText(simObj.totalDisponible.toString())
                tblValNombre.text = simObj.nombreSim
                tblValCuenta.text = if (nomCuenta.isNotEmpty()) nomCuenta else "Cuenta #${simObj.idCuenta}"
                tblValFecha.text = simObj.fechaHoraSim
                tblValDisponible.text = "$${simObj.totalDisponible}"
                tblValEgresos.text = "$${simObj.totalEgresos}"
                tblValMeses.text = "${simObj.meses} meses"
                tblValExcedente.text = "$${simObj.excedente}"

                // Cargar detalles de la tabla DetallesSimulaciones
                listaDetallesStr.clear()
                val detallesBD = dbHelper.obtenerDetallesSimulacion(simObj.idSim)
                if (detallesBD.isEmpty()) {
                    listaDetallesStr.add("Sin ítems de detalle registrados")
                } else {
                    for (det in detallesBD) {
                        listaDetallesStr.add("• ${det.nombreItem}: $${det.valorItem}")
                    }
                }
                adapterDetalles.notifyDataSetChanged()
            } else {
                txtValorSim.setText("")
                tblValNombre.text = "Sin datos"
                tblValCuenta.text = "---"
                listaDetallesStr.clear()
                adapterDetalles.notifyDataSetChanged()
            }
        }
    }

    fun exportaJson(ruta: String): Boolean {
        return try {
            val destino = if (ruta.isNotBlank()) {
                File(ruta)
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                File(downloadsDir, "simulacion_export.json")
            }

            destino.parentFile?.mkdirs()

            val pos = spnSeleccionSim.selectedItemPosition
            val simObj = listaSimulacionesBD.getOrNull(pos - 1)
            val detalles = if (simObj != null) dbHelper.obtenerDetallesSimulacion(simObj.idSim) else emptyList()
            val usuario = SesionUsuario.usuarioActivo
            val nombreCuenta = if (simObj != null) dbHelper.obtenerNombreCuentaPorId(simObj.idCuenta) else ""

            val detallesJson = detalles.joinToString(separator = ",") { det ->
                """
                {
                  "idDetalle": ${det.idDetalle},
                  "idSim": ${det.idSim},
                  "idItem": ${det.idItem ?: 0},
                  "nombreItem": "${det.nombreItem}",
                  "valorItem": ${det.valorItem}
                }
                """.trimIndent()
            }

            val jsonContent = """
                {
                  "usuario": "$usuario",
                  "simulacion": {
                    "idSim": ${simObj?.idSim ?: 0},
                    "idCuenta": ${simObj?.idCuenta ?: 0},
                    "nombreCuenta": "$nombreCuenta",
                    "idUsuario": ${simObj?.idUsuario ?: 0},
                    "nombreSim": "${simObj?.nombreSim ?: ""}",
                    "fechaHoraSim": "${simObj?.fechaHoraSim ?: ""}",
                    "totalDisponible": ${simObj?.totalDisponible ?: 0},
                    "totalEgresos": ${simObj?.totalEgresos ?: 0},
                    "meses": ${simObj?.meses ?: 0},
                    "excedente": ${simObj?.excedente ?: 0}
                  },
                  "detalles": [
                    $detallesJson
                  ]
                }
            """.trimIndent()

            destino.writeText(jsonContent)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun exportaCSV(ruta: String): Boolean {
        return try {
            val destino = if (ruta.isNotBlank()) {
                File(ruta)
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                File(downloadsDir, "simulacion_export.csv")
            }

            destino.parentFile?.mkdirs()

            val pos = spnSeleccionSim.selectedItemPosition
            val simObj = listaSimulacionesBD.getOrNull(pos - 1)
            val detalles = if (simObj != null) dbHelper.obtenerDetallesSimulacion(simObj.idSim) else emptyList()
            val usuario = SesionUsuario.usuarioActivo
            val nombreCuenta = if (simObj != null) dbHelper.obtenerNombreCuentaPorId(simObj.idCuenta) else ""

            val sb = StringBuilder()

            // SECCIÓN 1: REPORTE SINTÉTICO (RESUMEN GENERAL)
            sb.append("=== RESUMEN SINTETICO DE LA SIMULACION ===\n")
            sb.append("Usuario,ID Sim,Nombre Simulacion,ID Cuenta,Cuenta Asociada,Fecha/Hora,Total Disponible ($),Total Egresos ($),Duracion (Meses),Excedente ($)\n")
            if (simObj != null) {
                sb.append("\"$usuario\",${simObj.idSim},\"${simObj.nombreSim}\",${simObj.idCuenta},\"${if (nombreCuenta.isNotEmpty()) nombreCuenta else "Sin cuenta"}\",\"${simObj.fechaHoraSim}\",${simObj.totalDisponible},${simObj.totalEgresos},${simObj.meses},${simObj.excedente}\n")
            } else {
                sb.append("\"$usuario\",0,\"Sin seleccion\",0,\"---\",\"---\",0,0,0,0\n")
            }

            sb.append("\n")

            // SECCIÓN 2: REPORTE ANALÍTICO (DESGLOSE DE ÍTEMS Y PORCENTAJES)
            sb.append("=== DETALLE ANALITICO DE ITEMS Y GASTOS ===\n")
            sb.append("Nro,ID Detalle,ID Item,Nombre del Item,Monto Item ($),Porcentaje del Total (%)\n")

            var sumaMonto = 0L
            val totalEgresos = simObj?.totalEgresos?.toLong() ?: 0L

            if (detalles.isEmpty()) {
                sb.append("1,0,0,\"Sin items de detalle registrados\",0,0.00%\n")
            } else {
                detalles.forEachIndexed { index, det ->
                    val montoItem = det.valorItem.toLong()
                    sumaMonto += montoItem
                    val pct = if (totalEgresos > 0) (montoItem.toDouble() / totalEgresos.toDouble()) * 100.0 else 0.0
                    val pctStr = String.format(java.util.Locale.US, "%.2f%%", pct)
                    sb.append("${index + 1},${det.idDetalle},${det.idItem ?: 0},\"${det.nombreItem}\",$montoItem,$pctStr\n")
                }
            }

            // TOTALES DE LA SECCIÓN ANALÍTICA
            val pctTotalStr = if (sumaMonto > 0) "100.00%" else "0.00%"
            sb.append("---,---,---,TOTAL EGRESOS ANALITICOS,$sumaMonto,$pctTotalStr\n")

            destino.writeText(sb.toString())
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun generarYVerPdfSimulacion(simObj: Simulacion, detalles: List<DetalleSimulacion>): File? {
        return try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            val paint = Paint().apply {
                color = Color.BLACK
                textSize = 14f
            }

            var y = 50f
            val leftMargin = 50f

            paint.textSize = 22f
            paint.isFakeBoldText = true
            canvas.drawText("Reporte de Simulación - SimulaFin", leftMargin, y, paint)
            y += 40f

            paint.textSize = 14f
            paint.isFakeBoldText = false
            val uActivo = dbHelper.obtenerNombreUsuarioActivo(SesionUsuario.usuarioActivo)
            canvas.drawText("Usuario Activo: $uActivo", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Simulación: ${simObj.nombreSim}", leftMargin, y, paint)
            y += 25f
            val nomCtaPdf = dbHelper.obtenerNombreCuentaPorId(simObj.idCuenta)
            canvas.drawText("Cuenta Asociada: ${if (nomCtaPdf.isNotEmpty()) nomCtaPdf else simObj.idCuenta.toString()}", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Fecha / Hora: ${simObj.fechaHoraSim}", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Monto Disponible: \$${simObj.totalDisponible}", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Total Egresos: \$${simObj.totalEgresos}", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Plazo (Meses): ${simObj.meses}", leftMargin, y, paint)
            y += 25f
            canvas.drawText("Excedente: \$${simObj.excedente}", leftMargin, y, paint)
            y += 40f

            paint.isFakeBoldText = true
            canvas.drawText("Detalle de Ítems de Gastos (Tabla DetallesSimulaciones):", leftMargin, y, paint)
            y += 25f

            paint.isFakeBoldText = false
            if (detalles.isEmpty()) {
                canvas.drawText("(Sin ítems de detalle registrados)", leftMargin, y, paint)
            } else {
                for (det in detalles) {
                    canvas.drawText("• ${det.nombreItem}: \$${det.valorItem}", leftMargin, y, paint)
                    y += 22f
                }
            }

            pdfDocument.finishPage(page)

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                ?: getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir?.mkdirs()
            val pdfFile = File(downloadsDir, "simulacion_${simObj.nombreSim.replace(" ", "_")}.pdf")
            pdfDocument.writeTo(FileOutputStream(pdfFile))
            pdfDocument.close()
            pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
