package com.simulafin.domain

data class DetalleSimulacionEntrada(
    val nombreItem: String,
    val valorItem: Int
)

data class ResultadoCalculoSimulacion(
    val totalEgresos: Long,
    val meses: Long,
    val excedente: Long
)

object SimulacionCalculo {
    fun calcular(totalDisponible: Long, detalles: List<DetalleSimulacionEntrada>): ResultadoCalculoSimulacion {
        val totalEgresos = detalles.fold(0L) { total, detalle ->
            val valor = detalle.valorItem.toLong()
            if (valor > Long.MAX_VALUE - total) {
                throw ArithmeticException("El total de los ítems excede el rango numérico.")
            }
            total + valor
        }
        return calcularTotales(totalDisponible, totalEgresos)
    }

    fun calcularTotales(totalDisponible: Long, totalEgresos: Long): ResultadoCalculoSimulacion {
        val meses = if (totalEgresos > 0L) totalDisponible / totalEgresos else 0L
        val excedente = if (totalEgresos > 0L) {
            totalDisponible - (meses * totalEgresos)
        } else {
            totalDisponible
        }

        return ResultadoCalculoSimulacion(totalEgresos, meses, excedente)
    }
}
