// ARCHIVO: app\src\main\java\com\simulafin\clases\BaseDatosHelper.kt
package com.simulafin.clases

import android.content.ContentValues
import android.content.ContentUris
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BaseDatosHelper(private val context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    /**
     * Verifica e inicializa la base de datos 'simulafin.db' y sus tablas.
     * Vacía explícitamente la tabla Usuarios en el archivo simulafin.db del dispositivo
     * para garantizar que comience con 0 registros (simulando el celular nuevo).
     * @return true si la base fue creada por primera vez, false si ya existía.
     */
    fun generaBaseDatos(): Boolean {
        val dbFile: File = context.getDatabasePath(DATABASE_NAME)
        val esNueva = !dbFile.exists()
        val db = this.writableDatabase
        CreacionBaseDatosSimula(db)
        db.close()
        return esNueva
    }

    override fun onCreate(db: SQLiteDatabase?) {
        if (db != null) {
            CreacionBaseDatosSimula(db)
        }
    }

    /**
     * Crea todas las tablas en la base de datos basándose en las clases del sistema:
     * Usuarios, Cuentas, Items, Simulaciones, DetallesSimulaciones.
     * La tabla Usuarios inicia completamente vacía.
     */
    fun CreacionBaseDatosSimula(db: SQLiteDatabase? = null) {
        val database = db ?: this.writableDatabase

        // Eliminar tablas antiguas en singular de versiones anteriores si existen
        try { database.execSQL("DROP TABLE IF EXISTS DetalleSimulacion;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Simulacion;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Cuenta;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Item;") } catch (e: Exception) { e.printStackTrace() }
        try { database.execSQL("DROP TABLE IF EXISTS Usuario;") } catch (e: Exception) { e.printStackTrace() }

        // Tabla Usuarios
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Usuarios (
                idUsuario INTEGER PRIMARY KEY AUTOINCREMENT,
                nombreUsuario TEXT NOT NULL UNIQUE,
                claveUsuario TEXT NOT NULL,
                saltUsuario TEXT NOT NULL DEFAULT '',
                fechaHoraUsuario TEXT NOT NULL DEFAULT '',
                esAdmin INTEGER DEFAULT 0,
                preferenciaTema TEXT DEFAULT ''
            )
            """.trimIndent()
        )

        // Tabla Cuentas
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Cuentas (
                idCuenta INTEGER PRIMARY KEY AUTOINCREMENT,
                idUsuario INTEGER NOT NULL,
                nombreCuenta TEXT NOT NULL,
                totalCuenta INTEGER NOT NULL,
                fechaHoraCuenta TEXT NOT NULL DEFAULT '',
                UNIQUE(idUsuario, nombreCuenta),
                FOREIGN KEY (idUsuario) REFERENCES Usuarios(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // Tabla Items
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Items (
                idItem INTEGER PRIMARY KEY AUTOINCREMENT,
                idUsuario INTEGER NOT NULL,
                nombreItem TEXT NOT NULL,
                valorItem INTEGER NOT NULL,
                UNIQUE(idUsuario, nombreItem),
                FOREIGN KEY (idUsuario) REFERENCES Usuarios(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // Tabla Simulaciones
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS Simulaciones (
                idSim INTEGER PRIMARY KEY AUTOINCREMENT,
                idCuenta INTEGER NOT NULL,
                idUsuario INTEGER NOT NULL,
                nombreSim TEXT NOT NULL,
                fechaHoraSim TEXT NOT NULL,
                totalDisponible INTEGER NOT NULL,
                totalEgresos INTEGER NOT NULL,
                meses INTEGER NOT NULL,
                excedente INTEGER NOT NULL,
                UNIQUE(idUsuario, nombreSim),
                FOREIGN KEY (idCuenta) REFERENCES Cuentas(idCuenta) ON DELETE CASCADE,
                FOREIGN KEY (idUsuario) REFERENCES Usuarios(idUsuario) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // Tabla DetallesSimulaciones
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS DetallesSimulaciones (
                idDetalle INTEGER PRIMARY KEY AUTOINCREMENT,
                idSim INTEGER NOT NULL,
                idItem INTEGER,
                nombreItem TEXT NOT NULL,
                valorItem INTEGER NOT NULL,
                FOREIGN KEY (idSim) REFERENCES Simulaciones(idSim) ON DELETE CASCADE,
                FOREIGN KEY (idItem) REFERENCES Items(idItem) ON DELETE SET NULL
            )
            """.trimIndent()
        )
    }

    // Vacía completamente la tabla Usuarios y reinicia la secuencia de forma segura usando transacciones.
    fun vaciarTablaUsuarios(db: SQLiteDatabase? = null) {
        val database = db ?: this.writableDatabase
        val isInternalDb = (db == null)
        try {
            if (isInternalDb) database.beginTransaction()
            database.delete("Usuarios", null, null)
            try {
                database.delete("sqlite_sequence", "name=?", arrayOf("Usuarios"))
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (isInternalDb) database.setTransactionSuccessful()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (isInternalDb) {
                try {
                    database.endTransaction()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                database.close()
            }
        }
    }

    /**
     * Vacía completamente la base de datos eliminando todas las tablas y registros.
     * La tabla Usuarios queda totalmente vacía (0 usuarios). El primer usuario
     * que se registre posteriormente será nombrado Administrador (esAdmin = 1).
     */
    fun vaciarTodaLaBaseDatos() {
        try {
            context.deleteDatabase(DATABASE_NAME)
            val db = this.writableDatabase
            CreacionBaseDatosSimula(db)
            db.close()
            SesionUsuario.usuarioActivo = ""
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun obtenerCantidadUsuarios(): Int {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM Usuarios", null)
        val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        db.close()
        return count
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN esAdmin INTEGER DEFAULT 0;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN preferenciaTema TEXT DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 3) {
            try { db?.execSQL("ALTER TABLE Simulaciones ADD COLUMN idUsuario INTEGER NOT NULL DEFAULT 0;") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 4) {
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN fechaHoraUsuario TEXT NOT NULL DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("ALTER TABLE Cuentas ADD COLUMN fechaHoraCuenta TEXT NOT NULL DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 5) {
            try { db?.execSQL("DROP TABLE IF EXISTS DetalleSimulacion;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Simulacion;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Cuenta;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Item;") } catch (e: Exception) { e.printStackTrace() }
            try { db?.execSQL("DROP TABLE IF EXISTS Usuario;") } catch (e: Exception) { e.printStackTrace() }
        }
        if (oldVersion < 6) {
            try { db?.execSQL("ALTER TABLE Usuarios ADD COLUMN saltUsuario TEXT DEFAULT '';") } catch (e: Exception) { e.printStackTrace() }
        }
    }

    // MÉTODOS PARA USUARIOS
    fun registrarUsuario(nombre: String, clave: String): Boolean {
        if (existeUsuario(nombre)) return false

        val db = this.writableDatabase
        try {
            val cursor = db.rawQuery("SELECT COUNT(*) FROM Usuarios", null)
            val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
            cursor.close()

            // Si la base de datos está vacía (count == 0), el primer usuario registrado es el Administrador (esAdmin = 1)
            // Para los siguientes usuarios registrados, esAdmin = 0
            val esAdminVal = if (count == 0) 1 else 0
            val salt = HashUtils.generarSalt()
            val claveHashed = HashUtils.hashPassword(clave, salt)
            val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

            val values = ContentValues().apply {
                put("nombreUsuario", nombre.trim())
                put("claveUsuario", claveHashed)
                put("saltUsuario", salt)
                put("fechaHoraUsuario", fechaHoraActual)
                put("esAdmin", esAdminVal)
            }
            val id = db.insert("Usuarios", null, values)
            db.close()
            return id != -1L
        } catch (e: Exception) {
            e.printStackTrace()
            try { db.close() } catch (ex: Exception) { ex.printStackTrace() }
            return false
        }
    }

    fun validarUsuario(nombre: String, clave: String): Boolean {
        val db = this.readableDatabase
        var esValido = false
        try {
            val cursor = db.rawQuery(
                "SELECT claveUsuario, saltUsuario FROM Usuarios WHERE LOWER(nombreUsuario) = LOWER(?)",
                arrayOf(nombre.trim())
            )
            if (cursor.moveToFirst()) {
                val idxHash = cursor.getColumnIndex("claveUsuario")
                val idxSalt = cursor.getColumnIndex("saltUsuario")
                if (idxHash >= 0) {
                    val hashGuardado = cursor.getString(idxHash) ?: ""
                    val saltGuardado = if (idxSalt >= 0) cursor.getString(idxSalt) ?: "" else ""

                    val hashCalculado = HashUtils.hashPassword(clave, saltGuardado)
                    val hashSinSalt = HashUtils.hashPassword(clave, "")

                    if (hashGuardado == hashCalculado || hashGuardado == hashSinSalt || hashGuardado == clave) {
                        esValido = true
                    }
                }
            }
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { db.close() } catch (e: Exception) { e.printStackTrace() }
        }
        return esValido
    }

    fun verificarPasswordAdmin(password: String): Boolean {
        if (password.isBlank()) return false

        // 1. Validar contra el usuario activo en la sesión actual
        val uActivo = SesionUsuario.usuarioActivo
        if (uActivo.isNotBlank() && uActivo != "Usuario Activo") {
            if (validarUsuario(uActivo, password)) {
                return true
            }
        }

        // 2. Validar contra cualquier usuario Administrador en la base de datos
        var esValido = false
        val db = this.readableDatabase
        try {
            val cursor = db.rawQuery("SELECT claveUsuario, saltUsuario FROM Usuarios WHERE esAdmin = 1 OR esAdmin = '1'", null)
            while (cursor.moveToNext()) {
                val idxHash = cursor.getColumnIndex("claveUsuario")
                val idxSalt = cursor.getColumnIndex("saltUsuario")
                if (idxHash >= 0) {
                    val hashGuardado = cursor.getString(idxHash) ?: ""
                    val saltGuardado = if (idxSalt >= 0) cursor.getString(idxSalt) ?: "" else ""

                    val hashCalculado = HashUtils.hashPassword(password, saltGuardado)
                    val hashSinSalt = HashUtils.hashPassword(password, "")

                    if (hashGuardado == hashCalculado || hashGuardado == hashSinSalt || hashGuardado == password) {
                        esValido = true
                        break
                    }
                }
            }
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { db.close() } catch (e: Exception) { e.printStackTrace() }
        }

        if (esValido) return true

        // 3. Si no es el admin explícito, verificar si la contraseña pertenece a algún usuario registrado en la tabla
        try {
            val db2 = this.readableDatabase
            val cursor2 = db2.rawQuery("SELECT nombreUsuario FROM Usuarios", null)
            while (cursor2.moveToNext()) {
                val idx = cursor2.getColumnIndex("nombreUsuario")
                if (idx >= 0) {
                    val uNom = cursor2.getString(idx) ?: ""
                    if (uNom.isNotBlank() && validarUsuario(uNom, password)) {
                        esValido = true
                        break
                    }
                }
            }
            cursor2.close()
            db2.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return esValido
    }

    fun actualizarUsuario(nombreAnterior: String, nombreNuevo: String, claveNueva: String): Boolean {
        val db = this.writableDatabase
        val salt = HashUtils.generarSalt()
        val claveHashed = HashUtils.hashPassword(claveNueva, salt)
        val values = ContentValues().apply {
            put("nombreUsuario", nombreNuevo.trim())
            put("claveUsuario", claveHashed)
            put("saltUsuario", salt)
        }
        var filas = db.update("Usuarios", values, "LOWER(nombreUsuario) = LOWER(?)", arrayOf(nombreAnterior.trim()))
        if (filas == 0 && nombreNuevo.isNotBlank()) {
            filas = db.update("Usuarios", values, "LOWER(nombreUsuario) = LOWER(?)", arrayOf(nombreNuevo.trim()))
        }
        db.close()
        return filas > 0
    }

    fun existeUsuario(nombre: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT idUsuario FROM Usuarios WHERE LOWER(nombreUsuario) = LOWER(?)", arrayOf(nombre.trim()))
        val existe = cursor.moveToFirst()
        cursor.close()
        db.close()
        return existe
    }

    fun obtenerIdUsuarioActivo(nombreUsuario: String): Int {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT idUsuario FROM Usuarios WHERE LOWER(nombreUsuario) = LOWER(?)", arrayOf(nombreUsuario.trim()))
        val id = if (cursor.moveToFirst()) cursor.getInt(cursor.getColumnIndexOrThrow("idUsuario")) else 1
        cursor.close()
        db.close()
        return id
    }

    fun obtenerNombreUsuarioActivo(nombreActual: String = SesionUsuario.usuarioActivo): String {
        if (nombreActual.isNotBlank() && nombreActual != "Usuario Activo") {
            return nombreActual
        }
        var nombreEncontrado = ""
        try {
            val db = this.readableDatabase
            val cursor = db.query("Usuarios", arrayOf("nombreUsuario"), null, null, null, null, "idUsuario ASC", "1")
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex("nombreUsuario")
                if (idx >= 0) {
                    val nom = cursor.getString(idx)
                    if (!nom.isNullOrBlank()) {
                        nombreEncontrado = nom
                    }
                }
            }
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (nombreEncontrado.isNotBlank()) {
            SesionUsuario.usuarioActivo = nombreEncontrado
        }
        return nombreEncontrado
    }

    // MÉTODOS PARA CUENTAS
    fun obtenerCuentas(idUsuario: Int = 0): List<Cuenta> {
        val lista = mutableListOf<Cuenta>()
        val db = this.readableDatabase
        val cursor = if (idUsuario > 0) {
            db.query("Cuentas", null, "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, "nombreCuenta ASC")
        } else {
            db.query("Cuentas", null, null, null, null, null, "nombreCuenta ASC")
        }
        if (cursor.moveToFirst()) {
            val idCIndex = cursor.getColumnIndex("idCuenta")
            val idUIndex = cursor.getColumnIndex("idUsuario")
            val nomIndex = cursor.getColumnIndex("nombreCuenta")
            val totIndex = cursor.getColumnIndex("totalCuenta")
            val fecIndex = cursor.getColumnIndex("fechaHoraCuenta")
            do {
                val idC = if (idCIndex >= 0) cursor.getInt(idCIndex) else 0
                val idU = if (idUIndex >= 0) cursor.getInt(idUIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val tot = if (totIndex >= 0) cursor.getInt(totIndex) else 0
                val fec = if (fecIndex >= 0) cursor.getString(fecIndex) ?: "" else ""
                lista.add(Cuenta(idC, idU, nom, tot, fec))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    fun insertarCuenta(idUsuario: Int, nombre: String, total: Int): Boolean {
        val db = this.writableDatabase
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val values = ContentValues().apply {
            put("idUsuario", idUsuario)
            put("nombreCuenta", nombre)
            put("totalCuenta", total)
            put("fechaHoraCuenta", fechaHoraActual)
        }
        val id = db.insertWithOnConflict("Cuentas", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        db.close()
        return id != -1L
    }

    fun obtenerNombreCuentaPorId(idCuenta: Int): String {
        var nombre = ""
        try {
            val db = this.readableDatabase
            val cursor = db.query("Cuentas", arrayOf("nombreCuenta"), "idCuenta = ?", arrayOf(idCuenta.toString()), null, null, null)
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex("nombreCuenta")
                if (idx >= 0) {
                    nombre = cursor.getString(idx) ?: ""
                }
            }
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return nombre
    }

    fun actualizarCuenta(idCuenta: Int, nombre: String, total: Int): Boolean {
        val db = this.writableDatabase
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val values = ContentValues().apply {
            put("nombreCuenta", nombre)
            put("totalCuenta", total)
            put("fechaHoraCuenta", fechaHoraActual)
        }
        val filas = db.update("Cuentas", values, "idCuenta = ?", arrayOf(idCuenta.toString()))
        db.close()
        return filas > 0
    }

    fun eliminarCuenta(idCuenta: Int): Boolean {
        val db = this.writableDatabase
        db.beginTransaction()
        var filas = 0
        try {
            db.execSQL(
                "DELETE FROM DetallesSimulaciones WHERE idSim IN (SELECT idSim FROM Simulaciones WHERE idCuenta = ?)",
                arrayOf(idCuenta.toString())
            )
            db.delete("Simulaciones", "idCuenta = ?", arrayOf(idCuenta.toString()))
            filas = db.delete("Cuentas", "idCuenta = ?", arrayOf(idCuenta.toString()))
            db.setTransactionSuccessful()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { db.endTransaction() } catch (e: Exception) { e.printStackTrace() }
            db.close()
        }
        return filas > 0
    }

    fun cuentaOcupada(idCuenta: Int): String {
        var nombreSim = ""
        try {
            val db = this.readableDatabase
            val cursor = db.query("Simulaciones", arrayOf("nombreSim"), "idCuenta = ?", arrayOf(idCuenta.toString()), null, null, null, "1")
            if (cursor.moveToFirst()) {
                val colIndex = cursor.getColumnIndex("nombreSim")
                if (colIndex >= 0) {
                    nombreSim = cursor.getString(colIndex) ?: ""
                }
            }
            cursor.close()

            if (nombreSim.isEmpty()) {
                val cursorCta = db.query("Cuentas", arrayOf("nombreCuenta"), "idCuenta = ?", arrayOf(idCuenta.toString()), null, null, null)
                if (cursorCta.moveToFirst()) {
                    val nomIdx = cursorCta.getColumnIndex("nombreCuenta")
                    if (nomIdx >= 0) {
                        val nomCta = cursorCta.getString(nomIdx) ?: ""
                        if (nomCta.isNotEmpty()) {
                            val cursorSim = db.rawQuery(
                                "SELECT nombreSim FROM Simulaciones WHERE idCuenta = ? OR idCuenta IN (SELECT idCuenta FROM Cuentas WHERE nombreCuenta = ?) LIMIT 1",
                                arrayOf(idCuenta.toString(), nomCta)
                            )
                            if (cursorSim.moveToFirst()) {
                                val sIdx = cursorSim.getColumnIndex("nombreSim")
                                if (sIdx >= 0) {
                                    nombreSim = cursorSim.getString(sIdx) ?: ""
                                }
                            }
                            cursorSim.close()
                        }
                    }
                }
                cursorCta.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return nombreSim
    }

    // MÉTODOS PARA ITEMS
    fun obtenerItems(idUsuario: Int = 0): List<Item> {
        val lista = mutableListOf<Item>()
        val db = this.readableDatabase
        val cursor = if (idUsuario > 0) {
            db.query("Items", null, "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, "nombreItem ASC")
        } else {
            db.query("Items", null, null, null, null, null, "nombreItem ASC")
        }
        if (cursor.moveToFirst()) {
            val idIIndex = cursor.getColumnIndex("idItem")
            val idUIndex = cursor.getColumnIndex("idUsuario")
            val nomIndex = cursor.getColumnIndex("nombreItem")
            val valIndex = cursor.getColumnIndex("valorItem")
            do {
                val idI = if (idIIndex >= 0) cursor.getInt(idIIndex) else 0
                val idU = if (idUIndex >= 0) cursor.getInt(idUIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val vItem = if (valIndex >= 0) cursor.getInt(valIndex) else 0
                lista.add(Item(idI, idU, nom, vItem))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    fun insertarItem(idUsuario: Int, nombre: String, valor: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("idUsuario", idUsuario)
            put("nombreItem", nombre)
            put("valorItem", valor)
        }
        val id = db.insertWithOnConflict("Items", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        db.close()
        return id != -1L
    }

    fun actualizarItem(idItem: Int, nombre: String, valor: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("nombreItem", nombre)
            put("valorItem", valor)
        }
        val filas = db.update("Items", values, "idItem = ?", arrayOf(idItem.toString()))
        db.close()
        return filas > 0
    }

    fun eliminarItem(idItem: Int): Boolean {
        val db = this.writableDatabase
        val filas = db.delete("Items", "idItem = ?", arrayOf(idItem.toString()))
        db.close()
        return filas > 0
    }

    fun itemOcupado(idItem: Int): String {
        var nombreSim = ""
        try {
            val db = this.readableDatabase
            val query = """
                SELECT s.nombreSim 
                FROM DetallesSimulaciones d
                INNER JOIN Simulaciones s ON d.idSim = s.idSim
                WHERE d.idItem = ?
                LIMIT 1
            """.trimIndent()

            val cursor = db.rawQuery(query, arrayOf(idItem.toString()))
            if (cursor.moveToFirst()) {
                val colIndex = cursor.getColumnIndex("nombreSim")
                if (colIndex >= 0) {
                    nombreSim = cursor.getString(colIndex) ?: ""
                }
            }
            cursor.close()

            if (nombreSim.isEmpty()) {
                val cursorItem = db.query("Items", arrayOf("nombreItem"), "idItem = ?", arrayOf(idItem.toString()), null, null, null)
                if (cursorItem.moveToFirst()) {
                    val nomIdx = cursorItem.getColumnIndex("nombreItem")
                    if (nomIdx >= 0) {
                        val nom = cursorItem.getString(nomIdx) ?: ""
                        if (nom.isNotEmpty()) {
                            val cursorDet = db.rawQuery(
                                "SELECT s.nombreSim FROM DetallesSimulaciones d INNER JOIN Simulaciones s ON d.idSim = s.idSim WHERE d.nombreItem = ? LIMIT 1",
                                arrayOf(nom)
                            )
                            if (cursorDet.moveToFirst()) {
                                val colIdx = cursorDet.getColumnIndex("nombreSim")
                                if (colIdx >= 0) {
                                    nombreSim = cursorDet.getString(colIdx) ?: ""
                                }
                            }
                            cursorDet.close()
                        }
                    }
                }
                cursorItem.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return nombreSim
    }

    // MÉTODOS PARA SIMULACIONES
    fun obtenerSimulaciones(idUsuario: Int = 0): List<Simulacion> {
        val lista = mutableListOf<Simulacion>()
        val db = this.readableDatabase
        val cursor = if (idUsuario > 0) {
            db.query("Simulaciones", null, "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, "idSim DESC")
        } else {
            db.query("Simulaciones", null, null, null, null, null, "idSim DESC")
        }
        if (cursor.moveToFirst()) {
            val idSIndex = cursor.getColumnIndex("idSim")
            val idCIndex = cursor.getColumnIndex("idCuenta")
            val idUIndex = cursor.getColumnIndex("idUsuario")
            val nomIndex = cursor.getColumnIndex("nombreSim")
            val fecIndex = cursor.getColumnIndex("fechaHoraSim")
            val dispIndex = cursor.getColumnIndex("totalDisponible")
            val egrIndex = cursor.getColumnIndex("totalEgresos")
            val mesIndex = cursor.getColumnIndex("meses")
            val excIndex = cursor.getColumnIndex("excedente")
            do {
                val idS = if (idSIndex >= 0) cursor.getInt(idSIndex) else 0
                val idC = if (idCIndex >= 0) cursor.getInt(idCIndex) else 0
                val idU = if (idUIndex >= 0) cursor.getInt(idUIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val fec = if (fecIndex >= 0) cursor.getString(fecIndex) ?: "" else ""
                val disp = if (dispIndex >= 0) cursor.getInt(dispIndex) else 0
                val egr = if (egrIndex >= 0) cursor.getInt(egrIndex) else 0
                val mes = if (mesIndex >= 0) cursor.getInt(mesIndex) else 0
                val exc = if (excIndex >= 0) cursor.getInt(excIndex) else 0
                lista.add(Simulacion(idS, idC, idU, nom, fec, disp, egr, mes, exc))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    fun insertarSimulacion(idCuenta: Int, idUsuario: Int, nombreSim: String, totalDisponible: Int, totalEgresos: Int, meses: Int, excedente: Int): Long {
        return guardarOActualizarSimulacion(idCuenta, idUsuario, nombreSim, totalDisponible, totalEgresos, meses, excedente)
    }

    fun guardarOActualizarSimulacion(idCuenta: Int, idUsuario: Int, nombreSim: String, totalDisponible: Int, totalEgresos: Int, meses: Int, excedente: Int): Long {
        val db = this.writableDatabase
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        val cursor = db.query(
            "Simulaciones",
            arrayOf("idSim"),
            "idUsuario = ? AND nombreSim = ?",
            arrayOf(idUsuario.toString(), nombreSim),
            null, null, null
        )
        val existingIdSim = if (cursor.moveToFirst()) {
            val idx = cursor.getColumnIndex("idSim")
            if (idx >= 0) cursor.getInt(idx) else -1
        } else {
            -1
        }
        cursor.close()

        val values = ContentValues().apply {
            put("idCuenta", idCuenta)
            put("idUsuario", idUsuario)
            put("nombreSim", nombreSim)
            put("fechaHoraSim", fechaHoraActual)
            put("totalDisponible", totalDisponible)
            put("totalEgresos", totalEgresos)
            put("meses", meses)
            put("excedente", excedente)
        }
        val resultId = if (existingIdSim != -1) {
            val filas = db.update("Simulaciones", values, "idSim = ?", arrayOf(existingIdSim.toString()))
            if (filas > 0) existingIdSim.toLong() else -1L
        } else {
            db.insert("Simulaciones", null, values)
        }
        db.close()
        return resultId
    }

    fun insertarDetalleSimulacion(idSim: Long, idItem: Int, nombreItem: String, valorItem: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("idSim", idSim)
            if (idItem > 0) put("idItem", idItem)
            put("nombreItem", nombreItem)
            put("valorItem", valorItem)
        }
        val id = db.insert("DetallesSimulaciones", null, values)
        db.close()
        return id != -1L
    }

    fun reemplazarDetallesSimulacion(idSim: Long, listaDetalles: List<Pair<String, Int>>, idUsuario: Int): Boolean {
        var exito = false
        val db = this.writableDatabase
        try {
            db.beginTransaction()
            db.delete("DetallesSimulaciones", "idSim = ?", arrayOf(idSim.toString()))

            val mapaItemsBD = mutableMapOf<String, Int>()
            val cursorItems = if (idUsuario > 0) {
                db.query("Items", arrayOf("idItem", "nombreItem"), "idUsuario = ?", arrayOf(idUsuario.toString()), null, null, null)
            } else {
                db.query("Items", arrayOf("idItem", "nombreItem"), null, null, null, null, null)
            }
            if (cursorItems.moveToFirst()) {
                val idxId = cursorItems.getColumnIndex("idItem")
                val idxNom = cursorItems.getColumnIndex("nombreItem")
                do {
                    val idI = if (idxId >= 0) cursorItems.getInt(idxId) else 0
                    val nomI = if (idxNom >= 0) cursorItems.getString(idxNom) ?: "" else ""
                    if (nomI.isNotEmpty()) {
                        mapaItemsBD[nomI.lowercase(Locale.ROOT)] = idI
                    }
                } while (cursorItems.moveToNext())
            }
            cursorItems.close()

            for (det in listaDetalles) {
                val nombreItem = det.first
                val valorItem = det.second
                val idItem = mapaItemsBD[nombreItem.lowercase(Locale.ROOT)] ?: 0

                val values = ContentValues().apply {
                    put("idSim", idSim)
                    if (idItem > 0) put("idItem", idItem)
                    put("nombreItem", nombreItem)
                    put("valorItem", valorItem)
                }
                db.insert("DetallesSimulaciones", null, values)
            }

            db.setTransactionSuccessful()
            exito = true
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try {
                if (db.inTransaction()) {
                    db.endTransaction()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                db.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return exito
    }

    fun obtenerDetallesSimulacion(idSim: Int): List<DetalleSimulacion> {
        val lista = mutableListOf<DetalleSimulacion>()
        val db = this.readableDatabase
        val cursor = db.query("DetallesSimulaciones", null, "idSim = ?", arrayOf(idSim.toString()), null, null, null)
        if (cursor.moveToFirst()) {
            val idDIndex = cursor.getColumnIndex("idDetalle")
            val idSIndex = cursor.getColumnIndex("idSim")
            val idIIndex = cursor.getColumnIndex("idItem")
            val nomIndex = cursor.getColumnIndex("nombreItem")
            val valIndex = cursor.getColumnIndex("valorItem")
            do {
                val idD = if (idDIndex >= 0) cursor.getInt(idDIndex) else 0
                val idS = if (idSIndex >= 0) cursor.getInt(idSIndex) else 0
                val idI = if (idIIndex >= 0) cursor.getInt(idIIndex) else 0
                val nom = if (nomIndex >= 0) cursor.getString(nomIndex) else ""
                val vItem = if (valIndex >= 0) cursor.getInt(valIndex) else 0
                lista.add(DetalleSimulacion(idD, idS, idI, nom, vItem))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    fun simulacionConDetalle(idSim: Int): Boolean {
        var tieneDetalles = false
        try {
            val db = this.readableDatabase
            val cursor = db.query("DetallesSimulaciones", arrayOf("idDetalle"), "idSim = ?", arrayOf(idSim.toString()), null, null, null, "1")
            tieneDetalles = cursor.moveToFirst()
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return tieneDetalles
    }

    fun eliminarSimulacion(idsimulacion: Int): Boolean {
        val db = this.writableDatabase
        db.delete("DetallesSimulaciones", "idSim = ?", arrayOf(idsimulacion.toString()))
        val filas = db.delete("Simulaciones", "idSim = ?", arrayOf(idsimulacion.toString()))
        db.close()
        return filas > 0
    }

    /**
     * Genera y puebla automáticamente la base de datos 'baseParaAnalisis.db' con la cuenta Sercotec
     * de $10.222.333 y los tres escenarios de simulación y sus ítems específicos para el Análisis Comparativo.
     */
    fun generaBaseDatosParaAnalisis(): Boolean {
        return try {
            // Leer y respaldar los usuarios existentes de la BD activa para conservarlos intactos
            val usuariosExistentes = mutableListOf<ContentValues>()
            try {
                val dbActiva = this.readableDatabase
                val cursor = dbActiva.query("Usuarios", null, null, null, null, null, null)
                while (cursor.moveToNext()) {
                    val idxNom = cursor.getColumnIndex("nombreUsuario")
                    val idxHash = cursor.getColumnIndex("claveUsuario")
                    val idxSalt = cursor.getColumnIndex("saltUsuario")
                    val idxFecha = cursor.getColumnIndex("fechaHoraUsuario")
                    val idxAdmin = cursor.getColumnIndex("esAdmin")
                    val idxTema = cursor.getColumnIndex("preferenciaTema")

                    val cv = ContentValues().apply {
                        if (idxNom >= 0) put("nombreUsuario", cursor.getString(idxNom))
                        if (idxHash >= 0) put("claveUsuario", cursor.getString(idxHash))
                        if (idxSalt >= 0) put("saltUsuario", cursor.getString(idxSalt))
                        if (idxFecha >= 0) put("fechaHoraUsuario", cursor.getString(idxFecha))
                        if (idxAdmin >= 0) put("esAdmin", cursor.getInt(idxAdmin))
                        if (idxTema >= 0) put("preferenciaTema", cursor.getString(idxTema))
                    }
                    usuariosExistentes.add(cv)
                }
                cursor.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val dbFile = context.getDatabasePath("baseParaAnalisis.db")
            dbFile.parentFile?.mkdirs()
            if (dbFile.exists()) {
                dbFile.delete()
            }

            val db = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
            CreacionBaseDatosSimula(db)

            val idUsuario = 1
            val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

            // Preservar usuarios existentes intactos con sus contraseñas reales
            if (usuariosExistentes.isNotEmpty()) {
                for (cv in usuariosExistentes) {
                    db.insertWithOnConflict("Usuarios", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                }
            } else {
                val nombreUser = SesionUsuario.usuarioActivo.ifBlank { "Usuario" }
                val saltTest = HashUtils.generarSalt()
                val claveTestHashed = HashUtils.hashPassword("1234", saltTest)
                val cvUser = ContentValues().apply {
                    put("nombreUsuario", nombreUser)
                    put("claveUsuario", claveTestHashed)
                    put("saltUsuario", saltTest)
                    put("fechaHoraUsuario", fechaHoraActual)
                    put("esAdmin", 1)
                }
                db.insertWithOnConflict("Usuarios", null, cvUser, SQLiteDatabase.CONFLICT_IGNORE)
            }

            // Cuenta Base Sercotec: $10.222.333
            val montoCuenta = 10222333
            val nombreCuenta = "Cuenta Sercotec Fondo Fijo"

            val cvCta = ContentValues().apply {
                put("idUsuario", idUsuario)
                put("nombreCuenta", nombreCuenta)
                put("totalCuenta", montoCuenta)
                put("fechaHoraCuenta", fechaHoraActual)
            }
            val idCuenta = db.insertWithOnConflict("Cuentas", null, cvCta, SQLiteDatabase.CONFLICT_REPLACE)

            // --- SIMULACIÓN 1: Escenario Estándar ---
            val itemsSim1 = listOf(
                Pair("Arriendo", 450000),
                Pair("Movilización y Transporte", 150000),
                Pair("Internet y Celular", 80000),
                Pair("Sueldo Diseñador", 500000),
                Pair("Adicionales", 70000)
            )
            insertarSimulacionConItemsEnDb(db, idUsuario, idCuenta.toInt(), "sim1-1", montoCuenta, itemsSim1)

            // --- SIMULACIÓN 2: Escenario Intensivo ---
            val itemsSim2 = listOf(
                Pair("Arriendo", 450000),
                Pair("Movilización y Transporte", 200000),
                Pair("Internet y Celular", 100000),
                Pair("Sueldo Diseñador", 800000),
                Pair("Adicionales", 150000)
            )
            insertarSimulacionConItemsEnDb(db, idUsuario, idCuenta.toInt(), "sim1-2", montoCuenta, itemsSim2)

            // --- SIMULACIÓN 3: Escenario Ahorro ---
            val itemsSim3 = listOf(
                Pair("Arriendo", 350000),
                Pair("Movilización y Transporte", 100000),
                Pair("Internet y Celular", 60000),
                Pair("Sueldo Diseñador", 350000),
                Pair("Adicionales", 40000)
            )
            insertarSimulacionConItemsEnDb(db, idUsuario, idCuenta.toInt(), "sim1-3", montoCuenta, itemsSim3)

            db.close()

            // Cerrar conexiones abiertas a simulafin.db y eliminarla limpiamente antes de reemplazarla
            try {
                this.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            context.deleteDatabase(DATABASE_NAME)

            // Copiar baseParaAnalisis.db a la base de datos activa simulafin.db
            val dbActiva = context.getDatabasePath(DATABASE_NAME)
            dbActiva.parentFile?.mkdirs()
            dbFile.copyTo(dbActiva, overwrite = true)

            // Exportar copia a la carpeta Descargas
            try {
                copiarArchivoADescargas(dbFile, "baseParaAnalisis.db")
            } catch (e: Exception) {
                e.printStackTrace()
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun copiarArchivoADescargas(origen: File, nombreArchivo: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val downloadsUri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/"
            val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} = ? AND " +
                "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            val uriExistente = resolver.query(
                downloadsUri,
                arrayOf(MediaStore.MediaColumns._ID),
                selection,
                arrayOf(nombreArchivo, relativePath),
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    ContentUris.withAppendedId(downloadsUri, cursor.getLong(0))
                } else {
                    null
                }
            }

            val uriDestino = uriExistente ?: resolver.insert(
                downloadsUri,
                ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, nombreArchivo)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.sqlite3")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                }
            ) ?: throw IOException("No se pudo crear $nombreArchivo en Descargas")

            resolver.openOutputStream(uriDestino, "wt")?.use { output ->
                origen.inputStream().use { input -> input.copyTo(output) }
            } ?: throw IOException("No se pudo abrir $nombreArchivo en Descargas")
            return
        }

        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            ?: context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: throw IOException("No se encontró la carpeta Descargas")
        if (!downloadsDir.exists() && !downloadsDir.mkdirs()) {
            throw IOException("No se pudo crear la carpeta Descargas")
        }
        origen.copyTo(File(downloadsDir, nombreArchivo), overwrite = true)
    }

    private fun insertarSimulacionConItemsEnDb(
        db: SQLiteDatabase,
        idUsuario: Int,
        idCuenta: Int,
        nombreSim: String,
        montoDisponible: Int,
        items: List<Pair<String, Int>>
    ) {
        val fechaHoraActual = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val totalEgresos = items.sumOf { it.second }
        val meses = if (totalEgresos > 0) montoDisponible / totalEgresos else 0
        val excedente = if (totalEgresos > 0) montoDisponible - (meses * totalEgresos) else montoDisponible

        val cvSim = ContentValues().apply {
            put("idCuenta", idCuenta)
            put("idUsuario", idUsuario)
            put("nombreSim", nombreSim)
            put("fechaHoraSim", fechaHoraActual)
            put("totalDisponible", montoDisponible)
            put("totalEgresos", totalEgresos)
            put("meses", meses)
            put("excedente", excedente)
        }
        val idSim = db.insertWithOnConflict("Simulaciones", null, cvSim, SQLiteDatabase.CONFLICT_REPLACE)

        for (pair in items) {
            val cvItem = ContentValues().apply {
                put("idUsuario", idUsuario)
                put("nombreItem", pair.first)
                put("valorItem", pair.second)
            }
            val idItem = db.insertWithOnConflict("Items", null, cvItem, SQLiteDatabase.CONFLICT_REPLACE)

            val cvDet = ContentValues().apply {
                put("idSim", idSim)
                if (idItem > 0) put("idItem", idItem)
                put("nombreItem", pair.first)
                put("valorItem", pair.second)
            }
            db.insert("DetallesSimulaciones", null, cvDet)
        }
    }

    companion object {
        const val DATABASE_NAME = "simulafin.db"
        private const val DATABASE_VERSION = 6
    }
}