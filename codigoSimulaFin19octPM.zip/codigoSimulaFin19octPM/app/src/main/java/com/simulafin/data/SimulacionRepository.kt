package com.simulafin.data

import com.simulafin.clases.Cuenta
import com.simulafin.clases.DetalleSimulacion
import com.simulafin.clases.Item
import com.simulafin.clases.Simulacion
import com.simulafin.domain.DetalleSimulacionEntrada
import com.simulafin.domain.ResultadoCalculoSimulacion

interface SimulacionRepository {
    fun obtenerIdUsuarioActivo(nombreUsuario: String): Int
    fun obtenerNombreUsuarioActivo(nombreUsuario: String): String
    fun obtenerSimulaciones(idUsuario: Int): List<Simulacion>
    fun obtenerCuentas(idUsuario: Int): List<Cuenta>
    fun obtenerItems(idUsuario: Int): List<Item>
    fun obtenerDetallesSimulacion(idSimulacion: Int): List<DetalleSimulacion>
    fun eliminarSimulacion(idSimulacion: Int): Boolean
    fun actualizarCuenta(idCuenta: Int, nombre: String, total: Int): Boolean
    fun cuentaOcupada(idCuenta: Int): String
    fun eliminarCuenta(idCuenta: Int): Boolean
    fun itemOcupado(idItem: Int): String
    fun eliminarItem(idItem: Int): Boolean
    fun insertarSimulacion(
        idCuenta: Int,
        idUsuario: Int,
        nombre: String,
        totalDisponible: Int,
        totalEgresos: Int,
        meses: Int,
        excedente: Int
    ): Long
    fun insertarCuenta(idUsuario: Int, nombre: String, total: Int): Boolean
    fun insertarItem(idUsuario: Int, nombre: String, valor: Int): Boolean
    fun obtenerIdCuenta(idUsuario: Int, nombreCuenta: String): Int?
    fun obtenerSimulacionId(idUsuario: Int, nombreSimulacion: String): Int?
    fun tieneDetalles(idSimulacion: Int): Boolean
    fun guardarCompleta(
        idUsuario: Int,
        idCuenta: Int,
        nombreSimulacion: String,
        totalDisponible: Int,
        resultado: ResultadoCalculoSimulacion,
        detalles: List<DetalleSimulacionEntrada>
    ): Int
}
