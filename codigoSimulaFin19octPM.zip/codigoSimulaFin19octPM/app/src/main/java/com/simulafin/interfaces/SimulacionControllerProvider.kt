package com.simulafin.interfaces

import com.simulafin.controller.SimulacionController

interface SimulacionControllerProvider {
    fun getSimulacionController(): SimulacionController
}
