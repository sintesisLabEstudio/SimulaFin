package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaPie

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //PRESENTA GUIA AL PIE DE PAGINA
        presentaPie("Menú Principal: Seleccione una opción para gestionar Simulaciones, Cuentas, Ítems, Usuarios o Respaldos.")

        //COMPONENETES
        val txvUsuarioActivo = findViewById<TextView>(R.id.txvUsuarioActivo)
        txvUsuarioActivo?.text = "Usuario: ${SesionUsuario.usuarioActivo}"
        val btnSimulaciones = findViewById<Button>(R.id.btnSimulaciones)
        val btnCuentas = findViewById<Button>(R.id.btnCuentas)
        val btnItems = findViewById<Button>(R.id.btnItems)
        val btnRegistro = findViewById<Button>(R.id.btnRegistro)
        val btnRespaldo = findViewById<Button>(R.id.btnRespaldo)

        //CLIK BTON SIMULA
        btnSimulaciones.setOnClickListener {
            val intent = Intent(this, MenuSimActivity::class.java)
            startActivity(intent)
        }

        //CLICK BTN CUENTA
        btnCuentas.setOnClickListener {
            val intent = Intent(this, CuentasActivity::class.java)
            startActivity(intent)
        }

        //CLICK EN ITEMS a ItemsActivity
        btnItems.setOnClickListener {
            val intent = Intent(this, ItemsActivity::class.java)
            startActivity(intent)
        }

        //CLCIKC EN REGISTRO
        btnRegistro.setOnClickListener {
            val intent = Intent(this, RegistroActivity::class.java)
            startActivity(intent)
        }
        //CLICK EN RESPALDO
        btnRespaldo.setOnClickListener {
            val intent = Intent(this, RespaldoActivity::class.java)
            startActivity(intent)
        }
    }
}
