package com.simulafin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.SesionUsuario
import com.simulafin.clases.presentaClave
import com.simulafin.clases.presentaPie

class registroUsuarioNuevo : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_usuario_nuevo)

        //MENSAJE DE AYUDA CONTINUA
        presentaPie("Registro de nuevo usuario en el sistema. Ingrese su nombre, contraseña y confirmación de contraseña.")

        //ACTIVO BOTON HOME
        val btnHome = findViewById<ImageView>(R.id.btnHome)
        btnHome?.setOnClickListener {
            finish()
        }
        //INPUTS login
        val etNombreUsuario = findViewById<EditText>(R.id.etNombreUsuario)
        val etClaveUsuario = findViewById<EditText>(R.id.etClaveUsuario)
        val etConfirmarClave = findViewById<EditText>(R.id.etConfirmarClave)
        etClaveUsuario.presentaClave()
        etConfirmarClave.presentaClave()
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)
        //BASE DATOS open
        val dbHelper = BaseDatosHelper(this)
        //GRABA PRESENTA TOAST
        btnRegistrar.setOnClickListener {
            val nombre = etNombreUsuario.text.toString().trim()
            val clave = etClaveUsuario.text.toString().trim()
            val confirmacion = etConfirmarClave.text.toString().trim()

            if (nombre.isEmpty() || clave.isEmpty() || confirmacion.isEmpty()) {
                Toast.makeText(this, "Por favor complete todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (clave != confirmacion) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (dbHelper.existeUsuario(nombre)) {
                val exitoActualizar = dbHelper.actualizarUsuario(nombre, nombre, clave)
                if (exitoActualizar) {
                    SesionUsuario.usuarioActivo = nombre
                    Toast.makeText(this, "Contraseña actualizada con éxito para '$nombre'", Toast.LENGTH_LONG).show()
                    val intentMain = Intent(this, MainActivity::class.java)
                    startActivity(intentMain)
                    finish()
                } else {
                    Toast.makeText(this, "El usuario '$nombre' ya existe en la base de datos", Toast.LENGTH_SHORT).show()
                }
                return@setOnClickListener
            }

            // Guardar el nuevo usuario en la tabla Usuario de la base de datos
            val esPrimerUsuario = dbHelper.obtenerCantidadUsuarios() == 0
            val guardadoExitoso = dbHelper.registrarUsuario(nombre, clave)
            
            if (guardadoExitoso) {
                // Registrar y activar el nuevo usuario en la sesión local
                SesionUsuario.usuarioActivo = nombre
                val msge = if (esPrimerUsuario) {
                    "Usuario '$nombre' registrado con éxito como Administrador en la base de datos"
                } else {
                    "Usuario '$nombre' registrado con éxito en la base de datos"
                }
                Toast.makeText(this, msge, Toast.LENGTH_LONG).show()

                // Navegar al menú principal con el nuevo usuario activo
                val intentMain = Intent(this, MainActivity::class.java)
                startActivity(intentMain)
                finish()
            } else {
                Toast.makeText(this, "Error al guardar el usuario en la base de datos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
