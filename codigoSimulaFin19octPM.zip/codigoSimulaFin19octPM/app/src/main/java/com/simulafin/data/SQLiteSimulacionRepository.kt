package com.simulafin.data

import android.content.ContentValues
import android.database.sqlite.SQLiteException
import com.simulafin.clases.BaseDatosHelper
import com.simulafin.clases.Cuenta
import com.simulafin.clases.DetalleSimulacion
import com.simulafin.clases.Item
import com.simulafin.clases.Simulacion
import com.simulafin.domain.DetalleSimulacionEntrada
import com.simulafin.domain.ResultadoCalculoSimulacion
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SQLiteSimulacionRepository(
    private val dbHelper: BaseDatosHelper
) : SimulacionRepository {

    override fun obtenerIdUsuarioActivo(nombreUsuario: String): Int =
        dbHelper.obtenerIdUsuarioActivo(nombreUsuario)

    override fun obtenerNombreUsuarioActivo(nombreUsuario: String): String =
        dbHelper.obtenerNombreUsuarioActivo(nombreUsuario)

    override fun obtenerSimulaciones(idUsuario: Int): List<Simulacion> =
        dbHelper.obtenerSimulaciones(idUsuario)

    override fun obtenerCuentas(idUsuario: Int): List<Cuenta> =
        dbHelper.obtenerCuentas(idUsuario)

    override fun obtenerItems(idUsuario: Int): List<Item> =
        dbHelper.obtenerItems(idUsuario)

    override fun obtenerDetallesSimulacion(idSimulacion: Int): List<DetalleSimulacion> =
        dbHelper.obtenerDetallesSimulacion(idSimulacion)

    override fun eliminarSimulacion(idSimulacion: Int): Boolean =
        dbHelper.eliminarSimulacion(idSimulacion)

    override fun actualizarCuenta(idCuenta: Int, nombre: String, total: Int): Boolean =
        dbHelper.actualizarCuenta(idCuenta, nombre, total)

    override fun cuentaOcupada(idCuenta: Int): String =
        dbHelper.cuentaOcupada(idCuenta)

    override fun eliminarCuenta(idCuenta: Int): Boolean =
        dbHelper.eliminarCuenta(idCuenta)

    override fun itemOcupado(idItem: Int): String =
        dbHelper.itemOcupado(idItem)

    override fun eliminarItem(idItem: Int): Boolean =
        dbHelper.eliminarItem(idItem)

    override fun insertarSimulacion(
        idCuenta: Int,
        idUsuario: Int,
        nombre: String,
        totalDisponible: Int,
        totalEgresos: Int,
        meses: Int,
        excedente: Int
    ): Long = dbHelper.insertarSimulacion(
        idCuenta,
        idUsuario,
        nombre,
        totalDisponible,
        totalEgresos,
        meses,
        excedente
    )

    override fun insertarCuenta(idUsuario: Int, nombre: String, total: Int): Boolean =
        dbHelper.insertarCuenta(idUsuario, nombre, total)

    override fun insertarItem(idUsuario: Int, nombre: String, valor: Int): Boolean =
        dbHelper.insertarItem(idUsuario, nombre, valor)

    override fun obtenerIdCuenta(idUsuario: Int, nombreCuenta: String): Int? {
        return dbHelper.obtenerCuentas(idUsuario)
            .firstOrNull { it.nombreCuenta.equals(nombreCuenta, ignoreCase = true) }
            ?.idCuenta
    }

    override fun obtenerSimulacionId(idUsuario: Int, nombreSimulacion: String): Int? {
        return dbHelper.obtenerSimulaciones(idUsuario)
            .firstOrNull { it.nombreSim.equals(nombreSimulacion, ignoreCase = true) }
            ?.idSim
    }

    override fun tieneDetalles(idSimulacion: Int): Boolean {
        return dbHelper.simulacionConDetalle(idSimulacion)
    }

    override fun guardarCompleta(
        idUsuario: Int,
        idCuenta: Int,
        nombreSimulacion: String,
        totalDisponible: Int,
        resultado: ResultadoCalculoSimulacion,
        detalles: List<DetalleSimulacionEntrada>
    ): Int {
        val db = dbHelper.writableDatabase
        db.beginTransaction()
        try {
            val cursor = db.query(
                "Simulaciones",
                arrayOf("idSim"),
                "idUsuario = ? AND nombreSim = ? COLLATE NOCASE",
                arrayOf(idUsuario.toString(), nombreSimulacion),
                null,
                null,
                "idSim DESC",
                "1"
            )
            val idExistente = cursor.use {
                if (it.moveToFirst()) it.getInt(0) else null
            }

            val fechaHoraActual = SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss",
                Locale.getDefault()
            ).format(Date())
            val valoresSimulacion = ContentValues().apply {
                put("idCuenta", idCuenta)
                put("idUsuario", idUsuario)
                put("nombreSim", nombreSimulacion)
                put("fechaHoraSim", fechaHoraActual)
                put("totalDisponible", totalDisponible)
                put("totalEgresos", resultado.totalEgresos.toInt())
                put("meses", resultado.meses.toInt())
                put("excedente", resultado.excedente.toInt())
            }

            val idSimulacion = if (idExistente != null) {
                val filasActualizadas = db.update(
                    "Simulaciones",
                    valoresSimulacion,
                    "idSim = ?",
                    arrayOf(idExistente.toString())
                )
                if (filasActualizadas == 0) {
                    throw SQLiteException("No fue posible actualizar la simulación.")
                }
                idExistente
            } else {
                val nuevoId = db.insert("Simulaciones", null, valoresSimulacion)
                if (nuevoId <= 0L) {
                    throw SQLiteException("No fue posible crear la simulación.")
                }
                nuevoId.toInt()
            }

            db.delete(
                "DetallesSimulaciones",
                "idSim = ?",
                arrayOf(idSimulacion.toString())
            )

            val idsItems = obtenerIdsItems(db, idUsuario)
            detalles.forEach { detalle ->
                val valoresDetalle = ContentValues().apply {
                    put("idSim", idSimulacion)
                    idsItems[detalle.nombreItem.lowercase(Locale.ROOT)]?.let { put("idItem", it) }
                    put("nombreItem", detalle.nombreItem)
                    put("valorItem", detalle.valorItem)
                }
                val idDetalle = db.insert("DetallesSimulaciones", null, valoresDetalle)
                if (idDetalle <= 0L) {
                    throw SQLiteException("No fue posible guardar todos los detalles.")
                }
            }

            db.setTransactionSuccessful()
            return idSimulacion
        } finally {
            db.endTransaction()
        }
    }

    private fun obtenerIdsItems(
        db: android.database.sqlite.SQLiteDatabase,
        idUsuario: Int
    ): Map<String, Int> {
        val ids = mutableMapOf<String, Int>()
        val cursor = db.query(
            "Items",
            arrayOf("idItem", "nombreItem"),
            "idUsuario = ?",
            arrayOf(idUsuario.toString()),
            null,
            null,
            null
        )
        cursor.use {
            val idIndex = it.getColumnIndexOrThrow("idItem")
            val nombreIndex = it.getColumnIndexOrThrow("nombreItem")
            while (it.moveToNext()) {
                ids[it.getString(nombreIndex).lowercase(Locale.ROOT)] = it.getInt(idIndex)
            }
        }
        return ids
    }
}
