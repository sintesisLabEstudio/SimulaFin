package com.simulafin.interfaces

interface OnSimulacionDatosListener {
    fun onDatosSimulacionIngresados(totalGastos: Long, totalCuenta: Long = 0L)
    fun onSolicitarRecalcular()
    fun onSolicitarEliminarSimulacion()
    fun onSolicitarGuardarSimulacion()
    fun onSolicitarImprimirSimulacion()
    fun onSolicitarLimpiarSimulacion()
}
