package com.simulafin

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegistroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        val etNombreUsuario = findViewById<EditText>(R.id.etNombreUsuario)
        val etClaveUsuario = findViewById<EditText>(R.id.etClaveUsuario)
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)

        btnRegistrar.setOnClickListener {
            val nombre = etNombreUsuario.text.toString().trim()
            val clave = etClaveUsuario.text.toString().trim()

            if (nombre.isNotEmpty() && clave.isNotEmpty()) {
                Toast.makeText(this, "Usuario $nombre registrado con éxito", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Por favor complete todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
